"""Фоновый воркер: python worker.py  (генерация, публикация, уведомления, сверка оплат, плановые задачи).

Останавливается по SIGTERM/SIGINT после завершения текущей задачи.
"""
from __future__ import annotations

import logging
import signal
import threading

from app.config import get_settings
from app.jobs import worker_loop
from app.utils import setup_logging


def main() -> None:
    problems = get_settings().production_problems()
    if problems:
        raise SystemExit("Запуск в production невозможен, не настроено: " + ", ".join(problems))
    setup_logging()
    stop = threading.Event()
    for sig in (signal.SIGINT, signal.SIGTERM):
        signal.signal(sig, lambda *_: stop.set())
    logging.getLogger("salespage.worker").info("воркер запущен")
    worker_loop(stop)
    logging.getLogger("salespage.worker").info("воркер остановлен")


if __name__ == "__main__":
    main()
