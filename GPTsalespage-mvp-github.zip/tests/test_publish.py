"""Публикация: сбой проверки не ломает работающий сайт, обновление, приостановка, истечение и продление."""
from datetime import timedelta

import pytest
from fastapi.testclient import TestClient

from tests.conftest import login, ready_site, run_jobs, signed_webhook, site_row, start_payment


def _publish(c, csrf, site_id):
    pid = start_payment(c, csrf, site_id)
    signed_webhook(c, pid)
    run_jobs(); run_jobs()
    assert site_row(site_id).status == "live"


def test_update_and_failed_verification_keeps_old_version(app):
    from app import publishing
    c = TestClient(app)
    csrf, site_id = ready_site(c, "Публикация 1")
    _publish(c, csrf, site_id)
    host = {"Host": f"{site_row(site_id).slug}.sites.localhost"}
    old_html = c.get("/", headers=host).text
    h = {"X-CSRF-Token": csrf}
    assert c.post(f"/cabinet/sites/{site_id}/edit", data={"command": "Перепиши заголовок"}, headers=h).json()["ok"]
    assert c.post(f"/cabinet/sites/{site_id}/confirm", data={}, headers=h).json()["ok"]
    real = publishing.VERIFIER
    publishing.VERIFIER = lambda slug, rid: (False, "имитация: сайт не открылся")
    try:
        assert c.post(f"/cabinet/sites/{site_id}/republish", data={}, headers=h).json()["ok"]
        run_jobs()
    finally:
        publishing.VERIFIER = real
    assert c.get("/", headers=host).text == old_html  # откат: посетители видят прежнюю версию
    from app.db import system_session
    from app.models import Publication
    from sqlalchemy import select
    with system_session() as s:
        failed = s.scalars(select(Publication).where(Publication.site_id == site_id, Publication.status == "failed")).all()
    assert failed and "имитация" in failed[0].error
    # повтор задачи (очередь повторяет с задержкой) — запускаем вручную
    from app.publishing import run_publication
    assert run_publication(failed[0].id) == "live"
    new_html = c.get("/", headers=host).text
    assert new_html != old_html and site_row(site_id).published_version_id == site_row(site_id).current_version_id


def test_suspend_restore_expire_renew(app):
    from app.db import system_session
    from app.models import Site
    c = TestClient(app)
    csrf, site_id = ready_site(c, "Публикация 2")
    _publish(c, csrf, site_id)
    host = {"Host": f"{site_row(site_id).slug}.sites.localhost"}
    # жалоба посетителя не блокирует сайт сама
    r = c.post("/_abuse", data={"reason": "Подозрительные цены и чужие фото", "contact": ""}, headers=host)
    assert r.status_code == 200 and site_row(site_id).status == "live"
    admin = TestClient(app)
    acsrf = login(admin, "Оператор", "admin")
    from app.models import AbuseReport
    from sqlalchemy import select
    with system_session() as s:
        rep = s.scalar(select(AbuseReport).where(AbuseReport.site_id == site_id))
    assert admin.post("/admin/action", data={"csrf": acsrf, "action": "abuse_action", "id": str(rep.id), "reason": "проверено"},
                      follow_redirects=False).status_code == 303
    assert site_row(site_id).status == "suspended"
    assert "временно недоступен" in c.get("/", headers=host).text
    assert c.post("/_lead", data={"phone": "89210001122", "consent": "yes"}, headers=host).status_code == 400
    admin.post("/admin/action", data={"csrf": acsrf, "action": "restore", "id": site_id, "reason": "ошибка"})
    assert site_row(site_id).status == "live" and "временно недоступен" not in c.get("/", headers=host).text
    # истечение оплаченного периода
    with system_session() as s:
        s.get(Site, site_id).hosting_paid_until = s.get(Site, site_id).hosting_paid_until - timedelta(days=4000)
    from app.publishing import expire_sites
    expire_sites()
    assert site_row(site_id).status == "expired" and "закончился" in c.get("/", headers=host).text
    # продление: новый заказ, оплата, сайт снова доступен
    r = c.post(f"/cabinet/sites/{site_id}/pay", data={"csrf": csrf, "accept_terms": "yes", "kind": "renewal"}, follow_redirects=False)
    pid = r.headers["location"].rsplit("/", 1)[1]
    signed_webhook(c, pid)
    run_jobs(); run_jobs()
    assert site_row(site_id).status == "live" and "закончился" not in c.get("/", headers=host).text


def test_non_admin_cannot_use_admin(app):
    c = TestClient(app)
    csrf = login(c, "Обычный")
    assert c.get("/admin").status_code == 403
    assert c.post("/admin/action", data={"csrf": csrf, "action": "flag", "key": "pause_ai", "value": "on"}).status_code == 403
