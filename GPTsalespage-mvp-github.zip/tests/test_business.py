"""Коммерческая модель и агенты: тарифы из админки, экономика, состояние агентов, файлы агентов разработки."""
from pathlib import Path

from fastapi.testclient import TestClient

from tests.conftest import login, ready_site, run_jobs, signed_webhook, site_row, start_payment

ROOT = Path(__file__).resolve().parent.parent


def _plan(admin, csrf, code, price, purchasable=True, name=""):
    data = {"csrf": csrf, "action": "plan_update", "id": "00000000-0000-0000-0000-000000000000", "code": code,
            "price_rub": str(price), "reason": "проверка гипотезы", "name": name}
    if purchasable:
        data["purchasable"] = "on"
    return admin.post("/admin/action", data=data, follow_redirects=True)


def test_plans_economics_agents(app, monkeypatch):
    admin = TestClient(app)
    acsrf = login(admin, "Финансист", "admin")
    for sec in ("economics", "plans", "agents"):
        assert admin.get(f"/admin?section={sec}").status_code == 200, sec
    # цена тарифа меняется в админке и действует для новых заказов
    assert "999 ₽" in _plan(admin, acsrf, "page", 999).text
    c = TestClient(app)
    csrf, site_id = ready_site(c, "Цена 999")
    pid = start_payment(c, csrf, site_id)
    assert "999" in c.get(f"/test-checkout/{pid}").text and "1990" not in c.get(f"/test-checkout/{pid}").text
    signed_webhook(c, pid)
    run_jobs(); run_jobs()
    assert site_row(site_id).status == "live"
    _plan(admin, acsrf, "page", 1990)
    _plan(admin, acsrf, "care", 4990, purchasable=False)
    # экономика: оборот из подтверждённых оплат, прибыль — оценка с учётом комиссии из настроек
    from app.db import system_session
    from app.economics import compute
    monkeypatch.setenv("PAYMENT_FEE_PERCENT", "2")
    with system_session() as s:
        eco = compute(s, 30)
    assert eco["revenue"] >= 999 and eco["orders"] >= 1 and eco["fees_set"] and abs(eco["fees"] - eco["revenue"] * 0.02) < 0.01
    assert eco["target"] == 1_000_000 and eco["sales_needed"] > 0
    page = admin.get("/admin?section=economics").text
    assert "оборот" in page and "AI_COST_PER_CALL_RUB не задано" in page
    # агенты выполнения: публикатор и кассир реально отработали
    from app.agents import status
    with system_session() as s:
        st = {r["agent"].key: r for r in status(s)}
    assert st["publisher"]["done"] >= 1 and st["cashier"]["done"] >= 1 and st["copywriter"]["done"] >= 1
    owner = TestClient(app)
    login(owner, "Не админ")
    assert owner.get("/admin?section=economics").status_code == 403


def test_development_agents_files():
    agents = sorted((ROOT / ".claude" / "agents").glob("*.md"))
    assert len(agents) == 20
    assert (ROOT / "agents" / "upstream" / "LICENSE").read_text().startswith("MIT License")
    text = (ROOT / ".claude" / "agents" / "payments.md").read_text(encoding="utf-8")
    assert text.startswith("---\nname: payments\n") and "лицензия MIT" in text and "Не вставлять секреты" in text
    assert "в работающей платформе они не исполняются" in (ROOT / "docs" / "AGENTS.md").read_text(encoding="utf-8").lower()
