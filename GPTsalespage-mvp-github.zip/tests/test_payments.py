"""Платежи: подделка, повтор, несовпадение суммы, потерянный webhook, отмена (критерий 16)."""
from datetime import timedelta

from fastapi.testclient import TestClient
from sqlalchemy import func, select

from tests.conftest import ready_site, run_jobs, signed_webhook, site_row, start_payment


def _order_status(site_id):
    from app.db import system_session
    from app.models import Order
    with system_session() as s:
        return [o.status for o in s.scalars(select(Order).where(Order.site_id == site_id)).all()]


def test_forged_and_duplicate_webhooks(app):
    from app.db import system_session
    from app.models import AuditLog, PaymentEvent, Publication
    c = TestClient(app)
    csrf, site_id = ready_site(c, "Платёж 1")
    pid = start_payment(c, csrf, site_id)
    assert start_payment(c, csrf, site_id) == pid  # двойное нажатие «Оплатить» не создаёт второй платёж
    bad = c.post("/webhooks/payments/fake", content=b'{"event_id":"e1","payment_id":"%s"}' % pid.encode(),
                 headers={"x-fake-signature": "forged"})
    assert bad.status_code == 401
    run_jobs()
    assert site_row(site_id).status == "ready" and _order_status(site_id) == ["awaiting_payment"]
    r1, body = signed_webhook(c, pid)
    assert r1.status_code == 200
    from app.utils import hmac_hex
    r2 = c.post("/webhooks/payments/fake", content=body, headers={"x-fake-signature": hmac_hex("fake-webhook-secret", body)})
    assert r2.text == "duplicate"
    run_jobs(); run_jobs()
    assert site_row(site_id).status == "live" and _order_status(site_id) == ["paid"]
    with system_session() as s:
        assert s.scalar(select(func.count()).select_from(Publication).where(Publication.site_id == site_id)) == 1
        assert s.scalar(select(func.count()).select_from(AuditLog).where(AuditLog.action == "payment.succeeded",
                                                                        AuditLog.entity_type == "order")) >= 1
        assert s.scalar(select(func.count()).select_from(PaymentEvent).where(PaymentEvent.signature_ok.is_(False))) >= 1
    r = c.post(f"/cabinet/sites/{site_id}/pay", data={"csrf": csrf, "accept_terms": "yes"}, follow_redirects=False)
    assert "error=" in r.headers["location"]  # повторная оплата того же тарифа не создаётся


def test_amount_mismatch_and_cancel(app):
    c = TestClient(app)
    csrf, site_id = ready_site(c, "Платёж 2")
    pid = start_payment(c, csrf, site_id)
    signed_webhook(c, pid, "succeeded", amount_kop=100)  # провайдер сообщает другую сумму
    run_jobs(); run_jobs()
    assert site_row(site_id).status == "ready" and _order_status(site_id) == ["awaiting_payment"]
    csrf2, site2 = ready_site(c, "Платёж 3")
    pid2 = start_payment(c, csrf2, site2)
    signed_webhook(c, pid2, "canceled")
    run_jobs()
    assert site_row(site2).status == "ready" and _order_status(site2) == ["cancelled"]


def test_lost_webhook_reconciled(app):
    from app.billing import FakePaymentProvider
    from app.db import system_session
    from app.models import Payment
    c = TestClient(app)
    csrf, site_id = ready_site(c, "Платёж 4")
    pid = start_payment(c, csrf, site_id)
    FakePaymentProvider().simulate(pid, "succeeded")  # провайдер провёл платёж, но webhook не пришёл
    with system_session() as s:
        p = s.scalar(select(Payment).where(Payment.provider_payment_id == pid))
        p.created_at = p.created_at - timedelta(minutes=10)
    from app.jobs import enqueue
    with system_session() as s:
        enqueue(s, "reconcile_stale", {}, dedupe_key="test-stale")
    run_jobs(); run_jobs(); run_jobs()
    assert site_row(site_id).status == "live" and _order_status(site_id) == ["paid"]


def test_unpaid_publication_refused(app):
    from app.db import system_session
    from app.models import Site
    from app.publishing import queue_publication, run_publication
    c = TestClient(app)
    csrf, site_id = ready_site(c, "Без оплаты")
    with system_session() as s:
        site = s.get(Site, site_id)
        pub = queue_publication(s, site, site.current_version_id, None)
        pub_id = pub.id
    assert run_publication(pub_id) == "unpaid"
    assert c.get("/", headers={"Host": f"{site_row(site_id).slug}.sites.localhost"}).status_code == 404


def test_disabled_plan_cannot_be_paid(app):
    """Найдено тестом подписок: выключенный в админке тариф можно было оплатить."""
    from app.db import system_session
    from app.models import Plan
    c = TestClient(app)
    csrf, site_id = ready_site(c, "Выключенный тариф")
    with system_session() as s:
        s.get(Plan, "page").purchasable = False
    try:
        r = c.post(f"/cabinet/sites/{site_id}/pay", data={"csrf": csrf, "accept_terms": "yes"}, follow_redirects=False)
        assert "/test-checkout/" not in r.headers["location"] and "error=" in r.headers["location"]
    finally:
        with system_session() as s:
            s.get(Plan, "page").purchasable = True
