"""Месячная подписка: оплата по ссылке, продление от текущего срока, напоминание один раз, MRR и отток."""
from datetime import timedelta

from fastapi.testclient import TestClient
from sqlalchemy import func, select

from tests.conftest import login, ready_site, run_jobs, signed_webhook, site_row, start_payment


def _live(c, name):
    csrf, site_id = ready_site(c, name)
    pid = start_payment(c, csrf, site_id)
    signed_webhook(c, pid)
    run_jobs(); run_jobs()
    assert site_row(site_id).status == "live"
    return csrf, site_id


def _subscribe(c, csrf, site_id, plan="care"):
    r = c.post(f"/cabinet/sites/{site_id}/subscribe", data={"csrf": csrf, "plan_code": plan}, follow_redirects=False)
    assert "/test-checkout/" in r.headers["location"], r.headers["location"]
    return r.headers["location"].rsplit("/", 1)[1]


def test_subscription_flow(app):
    from app.db import system_session, utcnow
    from app.economics import compute
    from app.models import Order, Publication, Site
    from app.subscriptions import remind_expiring
    admin = TestClient(app)
    acsrf = login(admin, "Оператор подписок", "admin")
    c = TestClient(app)
    csrf, site_id = _live(c, "Подписка")
    # тариф выключен — подключить нельзя
    r = c.post(f"/cabinet/sites/{site_id}/subscribe", data={"csrf": csrf, "plan_code": "care"}, follow_redirects=True)
    assert "/test-checkout/" not in str(r.url)
    admin.post("/admin/action", data={"csrf": acsrf, "action": "plan_update", "id": "00000000-0000-0000-0000-000000000000",
                                      "code": "care", "price_rub": "4990", "purchasable": "on", "reason": "пилот"})
    assert "4990 ₽/мес" in c.get(f"/cabinet/promotion?site={site_id}").text
    with system_session() as s:
        pubs_before = s.scalar(select(func.count()).select_from(Publication).where(Publication.site_id == site_id))
    pid = _subscribe(c, csrf, site_id)
    assert "4990" in c.get(f"/test-checkout/{pid}").text
    signed_webhook(c, pid)
    run_jobs(); run_jobs()
    site = site_row(site_id)
    assert site.service_plan == "care" and abs((site.service_paid_until - utcnow()).days - 29) <= 1
    with system_session() as s:
        assert s.scalar(select(func.count()).select_from(Publication).where(Publication.site_id == site_id)) == pubs_before
        eco = compute(s, 30)
    assert eco["mrr"] >= 4990 and eco["active_subscriptions"] >= 1
    assert "действует до" in c.get(f"/cabinet/promotion?site={site_id}").text
    # напоминание за 3 дня: один раз на срок
    with system_session() as s:
        s.get(Site, site_id).service_paid_until = utcnow() + timedelta(days=2)
    assert remind_expiring() >= 1
    assert remind_expiring() == 0
    # продление: +30 дней от текущего срока, а не от сегодня
    before = site_row(site_id).service_paid_until
    with system_session() as s:  # разрешаем второй заказ в тот же день: снимаем ключ идемпотентности первого
        for o in s.scalars(select(Order).where(Order.site_id == site_id, Order.kind == "subscription")).all():
            o.idempotency_key = "used-" + str(o.id)[:50]
    pid2 = _subscribe(c, csrf, site_id)
    signed_webhook(c, pid2)
    run_jobs(); run_jobs()
    after = site_row(site_id).service_paid_until
    assert abs((after - before).days - 30) <= 1
    # подписка истекла: MRR её не учитывает, отток растёт
    with system_session() as s:
        s.get(Site, site_id).service_paid_until = utcnow() - timedelta(days=1)
        eco2 = compute(s, 30)
    assert eco2["lapsed_subscriptions"] >= 1 and eco2["mrr"] <= eco["mrr"] - 4990 + 0.01
    admin.post("/admin/action", data={"csrf": acsrf, "action": "plan_update", "id": "00000000-0000-0000-0000-000000000000",
                                      "code": "care", "price_rub": "4990", "reason": "выключить после теста"})


def test_subscription_needs_live_site(app):
    c = TestClient(app)
    csrf, site_id = ready_site(c, "Не опубликован, подписка")
    r = c.post(f"/cabinet/sites/{site_id}/subscribe", data={"csrf": csrf, "plan_code": "care"}, follow_redirects=False)
    assert "/test-checkout/" not in r.headers["location"]
