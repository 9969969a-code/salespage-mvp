"""Изоляция данных: пользователь B не видит и не меняет объекты пользователя A (критерий 15)."""
import uuid

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import func, select, text

from tests.conftest import create_site, login, run_jobs


def test_other_user_cannot_access(app):
    a, b = TestClient(app), TestClient(app)
    csrf_a = login(a, "Владелец А")
    site_a = create_site(a, csrf_a)
    a.post(f"/cabinet/sites/{site_a}/generate", data={}, headers={"X-CSRF-Token": csrf_a})
    run_jobs()
    csrf_b = login(b, "Владелец Б")
    hb = {"X-CSRF-Token": csrf_b}
    assert b.get(f"/cabinet/sites/{site_a}").status_code == 404
    assert b.get(f"/cabinet/sites/{site_a}/preview").status_code == 404
    assert b.get(f"/cabinet/sites/{site_a}/state").status_code == 404
    for path, data in [("edit", {"command": "Перепиши заголовок"}), ("confirm", {}), ("answer", {"text": "x"}),
                       ("hero", {"ref": "illustration:bouquet"}), ("generate", {}), ("republish", {}),
                       ("rollback", {"version_id": str(uuid.uuid4())}), ("facts", {"name": "Взлом"})]:
        r = b.post(f"/cabinet/sites/{site_a}/{path}", data=data, headers=hb)
        assert r.status_code in (400, 404) and not r.json().get("ok"), (path, r.text[:200])
    r = b.post(f"/cabinet/sites/{site_a}/pay", data={"csrf": csrf_b, "accept_terms": "yes"}, follow_redirects=False)
    assert r.status_code == 404
    assert "Владелец А" not in b.get("/cabinet").text
    assert a.get(f"/cabinet/sites/{site_a}/state").json()["version"] == 1  # у владельца ничего не изменилось


def test_rls_in_database():
    from app.db import anonymous_session, engine, system_session, user_session
    from app.models import Lead, Site
    with system_session() as s:
        site = s.scalars(select(Site)).first()
        owner = site.owner_id
    stranger = uuid.uuid4()
    with user_session(stranger) as s:
        assert s.get(Site, site.id) is None
        assert s.scalar(select(func.count()).select_from(Site)) == 0
    with anonymous_session() as s:
        assert s.scalar(select(func.count()).select_from(Site)) == 0
    with pytest.raises(Exception):  # WITH CHECK: нельзя записать строку от имени чужого владельца
        with user_session(stranger) as s:
            s.add(Lead(owner_id=owner, site_id=site.id, name="x", phone="79000000000", consent_version="t"))
            s.flush()
    with engine().connect() as c:
        role = c.execute(text("SELECT rolbypassrls, rolsuper FROM pg_roles WHERE rolname = current_user")).one()
        assert role == (False, False)
