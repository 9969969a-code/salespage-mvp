"""CSRF, XSS, обход путей, загрузки, секреты в публичной части, боевая конфигурация."""
import io

from fastapi.testclient import TestClient
from PIL import Image

from tests.conftest import create_site, login, ready_site, run_jobs, signed_webhook, site_row, start_payment


def test_csrf_required(app):
    c = TestClient(app)
    csrf = login(c, "CSRF")
    assert c.post("/cabinet/projects", data={}).status_code == 403
    assert c.post("/cabinet/projects", data={"csrf": "wrong"}).status_code == 403
    site_id = create_site(c, csrf)
    assert c.post(f"/cabinet/sites/{site_id}/generate", data={}).status_code == 403


def test_xss_blocked_and_escaped(app):
    c = TestClient(app)
    csrf = login(c, "XSS")
    r = c.post("/cabinet/projects", data={"csrf": csrf}, follow_redirects=False)
    sid = r.headers["location"].rsplit("/", 1)[1]
    res = c.post(f"/cabinet/sites/{sid}/answer", data={"text": "<script>alert(1)</script>"}, headers={"X-CSRF-Token": csrf}).json()
    assert not res["ok"]
    csrf2, site_id = ready_site(c, "XSS сайт")
    pid = start_payment(c, csrf2, site_id)
    signed_webhook(c, pid)
    run_jobs(); run_jobs()
    host = {"Host": f"{site_row(site_id).slug}.sites.localhost"}
    c.post("/_lead", data={"name": "<img src=x onerror=alert(1)>", "phone": "89210001133", "comment": "<script>x</script>",
                           "consent": "yes"}, headers=host)
    page = c.get("/cabinet/leads").text
    assert "<script>x</script>" not in page and "&lt;script&gt;" in page
    assert "<img src=x" not in page


def test_site_host_traversal_and_headers(app):
    c = TestClient(app)
    csrf, site_id = ready_site(c, "Пути")
    pid = start_payment(c, csrf, site_id)
    signed_webhook(c, pid)
    run_jobs(); run_jobs()
    host = {"Host": f"{site_row(site_id).slug}.sites.localhost"}
    for path in ["/../../../../etc/passwd", "/%2e%2e/%2e%2e/etc/passwd", "/..%2f..%2fapp/config.py"]:
        assert c.get(path, headers=host).status_code == 404, path
    r = c.get("/", headers=host)
    assert "default-src 'self'" in r.headers["content-security-policy"] and "set-cookie" not in r.headers
    assert c.get("/", headers={"Host": "bad_slug!.sites.localhost"}).status_code == 404
    assert c.get("/", headers={"Host": "no-such-site.sites.localhost"}).status_code == 404


def test_no_secrets_in_public_pages(app):
    from app.config import get_settings
    st = get_settings()
    c = TestClient(app)
    pages = [c.get("/").text, c.get("/example").text, c.get("/login").text, c.get("/legal/privacy").text]
    for secret in (st.SECRET_KEY, st.PAYMENT_WEBHOOK_SECRET, st.TELEGRAM_WEBHOOK_SECRET, "owner_dev_pw", "app_dev_pw"):
        assert all(secret not in p for p in pages), secret


def _png(w=800, h=600) -> bytes:
    buf = io.BytesIO()
    Image.new("RGB", (w, h), (200, 80, 120)).save(buf, "PNG")
    return buf.getvalue()


def test_uploads(app):
    c = TestClient(app)
    csrf = login(c, "Фото")
    site_id = create_site(c, csrf)
    h = {"X-CSRF-Token": csrf}
    ok = c.post(f"/cabinet/sites/{site_id}/photos", files={"photo": ("a.png", _png(), "image/png")}, headers=h).json()
    assert ok["ok"], ok
    img = c.get(f"/cabinet/assets/{ok['asset_id']}")
    assert img.status_code == 200 and img.headers["content-type"] == "image/webp"
    for name, data in [("x.jpg", b"<html><script>alert(1)</script></html>"),
                       ("x.svg", b'<svg xmlns="http://www.w3.org/2000/svg"><script>alert(1)</script></svg>'),
                       ("big.png", _png(9000, 9000))]:
        res = c.post(f"/cabinet/sites/{site_id}/photos", files={"photo": (name, data, "image/jpeg")}, headers=h).json()
        assert not res["ok"], name
    other = TestClient(app)
    login(other, "Чужой")
    assert other.get(f"/cabinet/assets/{ok['asset_id']}").status_code == 404


def test_production_refuses_test_adapters():
    from app.config import Settings
    p = Settings(APP_ENV="production").production_problems()
    for key in ("AI_PROVIDER", "PAYMENT_PROVIDER", "DEV_LOGIN_ENABLED", "SECRET_KEY", "HTTPS"):
        assert any(key in x for x in p), key


def test_production_refuses_mock_email_and_sources(monkeypatch):
    from app.config import Settings
    monkeypatch.setenv("EMAIL_MODE", "mock")
    monkeypatch.setenv("PROSPECT_SOURCE", "mock")
    p = " | ".join(Settings(APP_ENV="production").production_problems())
    assert "EMAIL_MODE" in p and "PROSPECT_SOURCE" in p
    monkeypatch.setenv("EMAIL_MODE", "off")
    monkeypatch.setenv("PROSPECT_SOURCE", "off")
    p = " | ".join(Settings(APP_ENV="production").production_problems())
    assert "EMAIL_MODE" not in p and "PROSPECT_SOURCE" not in p
