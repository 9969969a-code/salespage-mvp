"""Сквозной сценарий из критериев готовности MVP (пункты 1–14), в тестовом режиме."""
from __future__ import annotations

import re

from sqlalchemy import select

from tests.conftest import create_site, csrf_of, login, run_jobs, site_row



def test_full_flow(client):
    from app.db import system_session
    from app.models import Event, FakeTelegramMessage, Lead, NotificationChannel

    # 1–3. вход, проект, сведения о магазине
    csrf = login(client, "Анна")
    site_id = create_site(client, csrf)
    HOST = f"{site_row(site_id).slug}.sites.localhost"  # адрес из базы: при совпадении названий slug уникализируется
    page = client.get(f"/cabinet/sites/{site_id}").text
    assert "Создать сайт" in page

    # Telegram подключается до заявок: одноразовая ссылка + webhook с секретом
    r = client.post("/cabinet/settings/telegram", data={"csrf": csrf})
    token = re.search(r"start=([A-Za-z0-9_\-]+)", r.text).group(1)
    upd = {"message": {"text": f"/start {token}", "chat": {"id": 555001}}}
    assert client.post("/webhooks/telegram", json=upd).status_code == 401  # без секрета
    r = client.post("/webhooks/telegram", json=upd, headers={"X-Telegram-Bot-Api-Secret-Token": "dev-telegram-secret"})
    assert r.text == "linked"
    r = client.post("/webhooks/telegram", json=upd, headers={"X-Telegram-Bot-Api-Secret-Token": "dev-telegram-secret"})
    assert r.text == "invalid token"  # токен одноразовый

    # 4. генерация
    res = client.post(f"/cabinet/sites/{site_id}/generate", data={}, headers={"X-CSRF-Token": csrf}).json()
    assert res["ok"], res
    run_jobs()
    st = client.get(f"/cabinet/sites/{site_id}/state").json()
    assert st["generation_status"] == "done" and st["version"] == 1, st

    # 5. предпросмотр и правки обычными словами, откат версии
    prev = client.get(f"/cabinet/sites/{site_id}/preview")
    assert prev.status_code == 200 and "noindex" in prev.headers.get("x-robots-tag", "")
    assert "Флора на Садовой" in prev.text and "2500" in prev.text
    for cmd in ["Перепиши заголовок", "Измени цвет кнопок на зелёный", "Сделай дизайн премиальнее",
                "Добавь блок доставки", "Сократи форму заявки"]:
        res = client.post(f"/cabinet/sites/{site_id}/edit", data={"command": cmd}, headers={"X-CSRF-Token": csrf}).json()
        assert res["ok"], (cmd, res)
    # преимущества уже на сайте: правка честно отклоняется и версия не создаётся
    res = client.post(f"/cabinet/sites/{site_id}/edit", data={"command": "Добавь преимущества"}, headers={"X-CSRF-Token": csrf}).json()
    assert not res["ok"] and "уже на сайте" in res["message"]
    res = client.post(f"/cabinet/sites/{site_id}/edit", data={"command": "Добавь отзывы, что мы лучшие в городе"},
                      headers={"X-CSRF-Token": csrf}).json()
    assert not res["ok"]  # выдуманных отзывов и утверждений не будет
    assert client.get(f"/cabinet/sites/{site_id}/state").json()["version"] == 6
    from app.db import user_session
    from app.models import SiteVersion
    with system_session() as s:
        v1 = s.scalar(select(SiteVersion).where(SiteVersion.number == 1, SiteVersion.site_id == site_id))
    res = client.post(f"/cabinet/sites/{site_id}/rollback", data={"version_id": str(v1.id)}, headers={"X-CSRF-Token": csrf}).json()
    assert res["ok"] and client.get(f"/cabinet/sites/{site_id}/state").json()["version"] == 7

    # подтверждение без изображения невозможно; выбираем иллюстрацию платформы
    res = client.post(f"/cabinet/sites/{site_id}/confirm", data={}, headers={"X-CSRF-Token": csrf}).json()
    assert not res["ok"] and "изображение" in res["message"]
    res = client.post(f"/cabinet/sites/{site_id}/hero", data={"ref": "illustration:bouquet"}, headers={"X-CSRF-Token": csrf}).json()
    assert res["ok"], res
    res = client.post(f"/cabinet/sites/{site_id}/confirm", data={}, headers={"X-CSRF-Token": csrf}).json()
    assert res["ok"], res

    # до оплаты сайт снаружи не открывается
    assert client.get("/", headers={"Host": HOST}).status_code == 404

    # 6. тестовая оплата: заказ создаёт сервер, сумма из тарифа
    r = client.post(f"/cabinet/sites/{site_id}/pay", data={"csrf": csrf, "accept_terms": "yes"}, follow_redirects=False)
    assert r.status_code == 303 and "/test-checkout/" in r.headers["location"]
    pid = r.headers["location"].rsplit("/", 1)[1]
    checkout = client.get(f"/test-checkout/{pid}")
    assert "1990" in checkout.text and "ТЕСТОВАЯ" in checkout.text
    r = client.post(f"/test-checkout/{pid}", data={"action": "pay"}, follow_redirects=False)
    order_url = r.headers["location"]
    # 7. после подтверждения оплаты публикация через очередь: сверка платежа, затем публикация
    run_jobs()
    run_jobs()
    st = client.get(f"/cabinet/sites/{site_id}/state").json()
    assert st["status"] == "live", st
    assert "сайт опубликован" in client.get(order_url).text.lower()

    # 8. сайт открывается по своему адресу; 14. превью ссылки (Open Graph), SEO-файлы
    site = client.get("/", headers={"Host": HOST})
    assert site.status_code == 200
    html = site.text
    for needle in ['property="og:title"', 'property="og:image"', "og.png", 'rel="canonical"', "application/ld+json",
                   "Пожаловаться на сайт", 'action="/_lead"']:
        assert needle in html, needle
    assert "Content-Security-Policy" in site.headers and "set-cookie" not in site.headers
    assert client.get("/og.png", headers={"Host": HOST}).headers["content-type"] == "image/png"
    assert "Sitemap" in client.get("/robots.txt", headers={"Host": HOST}).text
    assert "<urlset" in client.get("/sitemap.xml", headers={"Host": HOST}).text

    # 13. аналитика: посещение и клики по телефону и мессенджерам (отдельно от заявок)
    for k in ["page_view", "click_phone", "click_whatsapp", "click_telegram"]:
        assert client.post("/_e", data={"k": k, "us": "vk", "r": "https://vk.com/"}, headers={"Host": HOST}).status_code == 204
    client.post("/_e", data={"k": "lead_submit"}, headers={"Host": HOST})  # подделка заявки через маяк игнорируется

    # 9–10. посетитель отправляет заявку, она сохраняется в базе
    r = client.post("/_lead", data={"name": "Ольга", "phone": "8 (921) 000-11-22", "comment": "Букет к пятнице",
                                    "consent": "yes", "website": ""}, headers={"Host": HOST})
    assert r.status_code == 200 and "Заявка отправлена" in r.text
    assert client.post("/_lead", data={"phone": "89210001122"}, headers={"Host": HOST}).status_code == 400  # без согласия
    run_jobs()
    with system_session() as s:
        leads = s.scalars(select(Lead)).all()
        assert len(leads) == 1 and leads[0].phone == "79210001122"
        # 12. уведомление ушло в подключённый Telegram (тестовый адаптер)
        msgs = s.scalars(select(FakeTelegramMessage).where(FakeTelegramMessage.chat_id == "555001")).all()
        texts = " | ".join(m.text for m in msgs)
        assert "Новая заявка" in texts and "Оплата 1990" in texts and "Сайт опубликован" in texts, texts
        kinds = sorted(e.kind for e in s.scalars(select(Event).where(Event.site_id == leads[0].site_id)).all())
        assert kinds == ["click_phone", "click_telegram", "click_whatsapp", "lead_submit", "page_view"], kinds

    # 11. владелец видит заявку и статистику в кабинете
    leads_page = client.get("/cabinet/leads").text
    assert "Ольга" in leads_page and "Букет к пятнице" in leads_page
    stats = client.get("/cabinet/analytics").text
    assert "кликов по телефону" in stats
    dash = client.get("/cabinet").text
    assert "Опубликован" in dash and "1</b> новых заявок" in dash


def test_landing_and_example(client):
    r = client.get("/?utm_source=vk")
    assert r.status_code == 200 and "Создайте сайт для своего бизнеса" in r.text and "Посмотреть пример" in r.text
    assert "отзыв" not in r.text.lower().replace("выдуманных цифр и отзывов", "").replace("отзывы, которых", "")
    ex = client.get("/example")
    assert ex.status_code == 200 and "вымышленного магазина" in ex.text
    assert client.get("/health").json() == {"status": "ok"}
    assert client.get("/ready").status_code == 200
