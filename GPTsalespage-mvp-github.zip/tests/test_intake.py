"""Короткий промт: сведения извлекаются из одного сообщения, спрашивается только недостающее."""
from fastapi.testclient import TestClient

from tests.conftest import login, run_jobs

PROMPT = ("Цветочная лавка «Ромашка», Санкт-Петербург. Авторские букеты, розы и пионы, цветы в коробках. "
          "Букеты от 2500 ₽. Доставка по городу за 2 часа. Оплата картой и по СБП. "
          "Работаем ежедневно с 9 до 21. Телефон +7 921 000-11-22, пишите в Telegram @romashka_spb.")


def test_extract_facts():
    from app.intake import extract_facts
    f = extract_facts(PROMPT)
    assert f["name"] == "Ромашка" and f["city"] == "Санкт-Петербург"
    assert "Розы" in f["assortment"] and "Пионы" in f["assortment"] and "Цветы в коробках" in f["assortment"]
    assert "2500" in f["prices"] and "Доставка" in f["delivery"] and "СБП" in f["payment"]
    assert f["telegram"] == "@romashka_spb" and f["phone"].startswith("+7 921")
    assert set(extract_facts("Просто цветы")) <= {"about"}  # только слова владельца, без выдуманных фактов


def _reply(msg: str) -> str:
    m = msg.lower()
    if "преимущ" in m or "отлича" in m:
        return "Свежие цветы каждый день; Фото букета перед отправкой"
    if "кто" in m or "покупател" in m or "аудитор" in m:
        return "Дарят цветы близким"
    if "стил" in m or "оформлен" in m:
        return "Нежный"
    if "действ" in m or "цель" in m:
        return "Оставить заявку"
    return "Цветочный магазин с доставкой букетов"


def test_prompt_flow_asks_only_missing(app):
    c = TestClient(app)
    csrf = login(c, "Промт")
    h = {"X-CSRF-Token": csrf}
    r = c.post("/cabinet/projects", data={"csrf": csrf}, follow_redirects=False)
    sid = r.headers["location"].rsplit("/", 1)[1]
    res = c.post(f"/cabinet/sites/{sid}/answer", data={"text": PROMPT}, headers=h).json()
    assert res["ok"] and res["message"].startswith("Понял:"), res
    asked = 0
    while not res.get("done"):
        asked += 1
        assert asked <= 8, "слишком много уточнений после промта"
        res = c.post(f"/cabinet/sites/{sid}/answer", data={"text": _reply(res["message"])}, headers=h).json()
        assert res["ok"], res
    assert asked <= 6, asked  # вместо 16 вопросов анкеты
    assert c.post(f"/cabinet/sites/{sid}/generate", data={}, headers=h).json()["ok"]
    run_jobs()
    prev = c.get(f"/cabinet/sites/{sid}/preview").text
    assert "Ромашка" in prev and "2500" in prev and "Пионы" in prev


def test_landing_shows_new_prices(client):
    t = client.get("/").text
    assert "1990 ₽" in t and "4990 ₽" in t


def test_city_declension_in_titles():
    from app.ai import _hero_titles
    t = " | ".join(_hero_titles({"name": "Ромашка", "city": "Санкт-Петербург", "delivery": "Доставка"}))
    assert "в Санкт-Петербурге" in t and "по Санкт-Петербургу" in t and "в Санкт-Петербург " not in t + " "
    t = " | ".join(_hero_titles({"name": "Лилия", "city": "Кировск", "delivery": "Доставка"}))
    assert "в городе Кировск" in t and "по городу Кировск" in t  # неизвестный город — без ошибочного склонения


def test_city_cases_and_clean_about():
    """Найдено в браузере: «Цветы и букеты в Санкт-Петербург», «Цветочный магазин , Санкт-Петербург»."""
    from app.ai import _hero_titles
    from app.intake import city_across, city_in, extract_facts
    assert city_in("Санкт-Петербург") == "в Санкт-Петербурге" and city_across("Москва") == "по Москве"
    assert city_in("Кировск") == "в городе Кировск"  # неизвестный город — без ошибочного склонения
    titles = " | ".join(_hero_titles({"name": "Ромашка", "city": "Санкт-Петербург", "delivery": "есть"}))
    assert "в Санкт-Петербурге" in titles and "по Санкт-Петербургу" in titles and "в Санкт-Петербург " not in titles + " "
    assert extract_facts("Цветочный магазин «Ромашка», Санкт-Петербург. Авторские букеты.")["about"] == "Цветочный магазин"
