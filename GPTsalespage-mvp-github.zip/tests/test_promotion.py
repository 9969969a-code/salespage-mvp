"""Продвижение сайтов клиентов: ссылки с метками, атрибуция заявок, посты из фактов, корпоративные клиенты с одобрением."""
import re

from fastapi.testclient import TestClient
from sqlalchemy import select

from tests.conftest import login, ready_site, run_jobs, signed_webhook, site_row, start_payment


def _live(c, name):
    csrf, site_id = ready_site(c, name)
    pid = start_payment(c, csrf, site_id)
    signed_webhook(c, pid)
    run_jobs(); run_jobs()
    assert site_row(site_id).status == "live"
    return csrf, site_id


def test_links_posts_and_attribution(app):
    c = TestClient(app)
    csrf, site_id = _live(c, "Продвижение 1")
    host = {"Host": f"{site_row(site_id).slug}.sites.localhost"}
    page = c.get(f"/cabinet/promotion?site={site_id}").text
    for src in ("utm_source=vk", "utm_source=telegram", "utm_source=avito", "utm_source=print"):
        assert src in page
    assert "Авторские букеты" in page and "2500" in page and "скидк" not in page.lower()
    ref = f"http://{host['Host']}/?utm_source=vk&utm_medium=social&utm_campaign=promo"
    c.post("/_e", data={"k": "page_view", "us": "vk", "um": "social", "uc": "promo"}, headers=host)
    c.post("/_lead", data={"name": "Из ВК", "phone": "89215550011", "consent": "yes"}, headers={**host, "Referer": ref})
    page = c.get(f"/cabinet/promotion?site={site_id}").text
    row = re.search(r"<tr><td>vk</td><td>(\d+)</td><td>(\d+)</td><td>(\d+)</td></tr>", page)
    assert row and row.groups() == ("1", "0", "1"), page[-1500:]   # заявка засчитана источнику ВК


def test_b2b_requires_owner_approval(app):
    from app.db import system_session
    from app.models import ClientOutreach, FakeEmail, SuppressionEntry
    c = TestClient(app)
    csrf, site_id = _live(c, "Продвижение 2")
    r = c.post(f"/cabinet/promotion/{site_id}/b2b", data={"csrf": csrf, "category": "office"}, follow_redirects=True)
    assert "писем на одобрение 2" in r.text
    with system_session() as s:
        msgs = s.scalars(select(ClientOutreach).where(ClientOutreach.site_id == site_id)).all()
        assert {m.status for m in msgs} == {"pending_review"}
        assert not s.scalars(select(FakeEmail).where(FakeEmail.to_address.in_([m.to_address for m in msgs]))).all()
    body = msgs[0].body
    assert "по поручению" in body and "/u/" in body and "utm_source=b2b" in body and "Санкт-Петербург" in body
    # чужой владелец не может одобрить
    other = TestClient(app)
    ocsrf = login(other, "Чужой владелец")
    other.post(f"/cabinet/promotion/outreach/{msgs[0].id}", data={"csrf": ocsrf, "decision": "approve"})
    with system_session() as s:
        assert s.get(ClientOutreach, msgs[0].id).status == "pending_review"
    assert "Северный офис" not in other.get("/cabinet/promotion").text
    # одобрение одного, отписка второго до отправки
    c.post(f"/cabinet/promotion/outreach/{msgs[0].id}", data={"csrf": csrf, "decision": "approve"})
    c.post(f"/cabinet/promotion/outreach/{msgs[1].id}", data={"csrf": csrf, "decision": "approve"})
    assert c.get(f"/u/{msgs[1].unsubscribe_token}").status_code == 200
    run_jobs()
    with system_session() as s:
        sent = s.scalars(select(FakeEmail).where(FakeEmail.to_address.in_([m.to_address for m in msgs]))).all()
        assert [e.to_address for e in sent] == [msgs[0].to_address]
        assert s.get(SuppressionEntry, msgs[1].to_address) is not None
    # повторный поиск не дублирует компании
    r = c.post(f"/cabinet/promotion/{site_id}/b2b", data={"csrf": csrf, "category": "office"}, follow_redirects=True)
    assert "писем на одобрение 0" in r.text and "уже были 2" in r.text


def test_promotion_needs_live_site(app):
    c = TestClient(app)
    csrf, site_id = ready_site(c, "Не опубликован")
    r = c.post(f"/cabinet/promotion/{site_id}/b2b", data={"csrf": csrf, "category": "office"}, follow_redirects=True)
    assert "опубликованного сайта" in r.text
