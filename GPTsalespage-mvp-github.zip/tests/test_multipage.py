"""Многостраничный сайт за 4990 ₽: выбор тарифа, предпросмотр страниц, оплата по тарифу, публикация страниц и меню."""
from fastapi.testclient import TestClient

from tests.conftest import ready_site, run_jobs, signed_webhook, site_row, start_payment


def test_multipage_site(app):
    c = TestClient(app)
    csrf, site_id = ready_site(c, "Многостраничный")
    h = {"X-CSRF-Token": csrf}
    editor = c.get(f"/cabinet/sites/{site_id}").text
    assert "Многостраничный сайт с ИИ — 4990 ₽" in editor and "Лендинг с ИИ — 1990 ₽" in editor
    assert c.post(f"/cabinet/sites/{site_id}/plan", data={"plan_code": "nope"}, headers=h).json()["ok"] is False
    r = c.post(f"/cabinet/sites/{site_id}/plan", data={"plan_code": "site"}, headers=h).json()
    assert r["ok"] and "4990" in r["message"]
    prev = c.get(f"/cabinet/sites/{site_id}/preview?page=catalog").text
    assert 'class="site-nav"' in prev and "<h1>Каталог и цены</h1>" in prev and "noindex" in c.get(f"/cabinet/sites/{site_id}/preview").headers["x-robots-tag"]
    pid = start_payment(c, csrf, site_id)
    assert "4990" in c.get(f"/test-checkout/{pid}").text                 # сумма по выбранному тарифу
    from app.db import system_session
    from app.models import FakeProviderPayment
    with system_session() as s:
        assert s.get(FakeProviderPayment, pid).amount_kop == 499000       # провайдеру ушла сумма тарифа 4990
    signed_webhook(c, pid)
    run_jobs(); run_jobs()
    assert site_row(site_id).status == "live"
    host = {"Host": f"{site_row(site_id).slug}.sites.localhost"}
    for path, title in [("/", None), ("/catalog/", "Каталог и цены"), ("/delivery/", "Доставка и оплата"), ("/contacts/", "Контакты")]:
        r = c.get(path, headers=host)
        assert r.status_code == 200, path
        assert 'class="site-nav"' in r.text and 'aria-current="page"' in r.text, path
        assert f'rel="canonical" href="http://{host["Host"]}{path}"' in r.text.replace("https://", "http://"), path
        if title:
            assert f"<h1>{title}</h1>" in r.text
    sm = c.get("/sitemap.xml", headers=host).text
    assert all(p in sm for p in ("/catalog/", "/delivery/", "/contacts/"))
    r = c.post(f"/cabinet/sites/{site_id}/plan", data={"plan_code": "page"}, headers=h).json()
    assert not r["ok"] and "поддержку" in r["message"]                  # после оплаты тариф не меняется сам


def test_landing_stays_single_page(app):
    c = TestClient(app)
    csrf, site_id = ready_site(c, "Одностраничный")
    pid = start_payment(c, csrf, site_id)
    assert "1990" in c.get(f"/test-checkout/{pid}").text
    signed_webhook(c, pid)
    run_jobs(); run_jobs()
    host = {"Host": f"{site_row(site_id).slug}.sites.localhost"}
    assert 'class="site-nav"' not in c.get("/", headers=host).text
    assert c.get("/catalog/", headers=host).status_code == 404
