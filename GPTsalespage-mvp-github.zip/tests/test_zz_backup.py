"""Резервная копия восстанавливается по процедуре (критерий 17). Запускается последним, когда в базе есть данные."""
import os
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def _counts(url: str) -> dict:
    out = {}
    for t in ("users", "sites", "site_versions", "orders", "payments", "publications", "leads"):
        out[t] = int(subprocess.run(["psql", url, "-qtAc", f"SELECT count(*) FROM {t}"], capture_output=True, text=True, check=True,
                                    env={**os.environ, "PGOPTIONS": "-c app.bypass=on"}).stdout.strip())
    return out


def test_backup_and_restore(tmp_path):
    src = "postgresql://sp_owner:owner_dev_pw@127.0.0.1:5432/salespage_test"
    env = {**os.environ, "DATABASE_BACKUP_URL": src, "BACKUP_DIR": str(tmp_path), "STORAGE_DIR": "/tmp/sp_test_storage"}
    dump = subprocess.run([str(ROOT / "scripts/backup.sh")], env=env, capture_output=True, text=True)
    assert dump.returncode == 0, dump.stderr
    dump_path = dump.stdout.strip().splitlines()[-1]
    env.update({"ADMIN_URL": "postgresql://postgres@/postgres?host=/var/run/postgresql",
                "RESTORE_URL_TEMPLATE": "postgresql://sp_owner:owner_dev_pw@127.0.0.1:5432/{db}"})
    res = subprocess.run([str(ROOT / "scripts/restore_check.sh"), dump_path], env=env, capture_output=True, text=True)
    assert res.returncode == 0, res.stderr
    report = dict(line.split("=", 1) for line in res.stdout.split() if "=" in line)
    assert report["restore_check"] == "ok" and report["alembic"] == subprocess.run(["psql", src, "-qtAc", "SELECT version_num FROM alembic_version"], capture_output=True, text=True).stdout.strip() and int(report["policies"]) >= 20
    assert {k: int(report[k]) for k in _counts(src)} == _counts(src)
    assert _counts(src)["leads"] >= 1 and _counts(src)["publications"] >= 1  # копировались реальные данные
