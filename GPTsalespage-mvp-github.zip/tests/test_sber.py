"""Адаптер Сбербанка на имитации банка: форма оплаты, callback с контрольной суммой, сверка статуса и суммы."""
import uuid
from urllib.parse import urlencode

import httpx
import pytest
from fastapi.testclient import TestClient

from tests.conftest import ready_site, run_jobs, site_row


class FakeBank:
    def __init__(self):
        self.orders, self.calls = {}, []

    def post(self, url, data=None, timeout=None):
        self.calls.append((url.rsplit("/", 1)[1], dict(data)))
        assert data["userName"] == "shop-api" and data["password"] == "secret"
        if url.endswith("register.do"):
            oid = str(uuid.uuid4())
            self.orders[oid] = {"orderNumber": data["orderNumber"], "amount": int(data["amount"]), "orderStatus": 0}
            body = {"orderId": oid, "formUrl": f"https://ecomtest.sberbank.ru/payment/merchants/test/payment_ru.html?mdOrder={oid}"}
        else:
            o = self.orders[data["orderId"]]
            body = {"errorCode": "0", "orderStatus": o["orderStatus"], "amount": o["amount"], "currency": "643",
                    "orderNumber": o["orderNumber"]}
        return httpx.Response(200, json=body, request=httpx.Request("POST", url))


@pytest.fixture()
def bank(monkeypatch):
    from app import billing
    from app.sber import SberProvider
    for k, v in {"SBER_USERNAME": "shop-api", "SBER_PASSWORD": "secret", "SBER_CALLBACK_TOKEN": "cb-token"}.items():
        monkeypatch.setenv(k, v)
    fb = FakeBank()
    monkeypatch.setattr(billing, "get_payment_provider", lambda: SberProvider(http_post=fb.post))
    return fb


def _callback(client, md, status="1", operation="deposited", token="cb-token", order_number=""):
    from app.sber import checksum
    params = {"mdOrder": md, "orderNumber": order_number, "operation": operation, "status": status}
    params["checksum"] = checksum(params, token)
    return client.get("/webhooks/payments/sber?" + urlencode(params))


def test_sber_full_payment(app, bank):
    c = TestClient(app)
    csrf, site_id = ready_site(c, "Сбер 1")
    r = c.post(f"/cabinet/sites/{site_id}/pay", data={"csrf": csrf, "accept_terms": "yes"}, follow_redirects=False)
    assert r.status_code == 303 and r.headers["location"].startswith("https://ecomtest.sberbank.ru/payment/")
    method, data = bank.calls[0]
    assert method == "register.do" and data["amount"] == 199000 and data["currency"] == "643"
    assert "/cabinet/orders/" in data["returnUrl"] and len(data["orderNumber"]) == 32
    md = next(iter(bank.orders))
    assert _callback(c, md, token="wrong").status_code == 401          # подделка отклонена
    assert _callback(c, md).status_code == 200                         # callback пришёл, но банк ещё не провёл оплату
    run_jobs(); run_jobs()
    assert site_row(site_id).status == "ready"                         # статус проверяется у банка, не по callback
    bank.orders[md]["orderStatus"] = 2                                 # банк провёл оплату
    assert _callback(c, md, status="1", operation="approved").status_code == 200
    run_jobs(); run_jobs()
    assert site_row(site_id).status == "live"
    assert any(m == "getOrderStatusExtended.do" for m, _ in bank.calls)


def test_sber_amount_mismatch_not_published(app, bank):
    c = TestClient(app)
    csrf, site_id = ready_site(c, "Сбер 2")
    c.post(f"/cabinet/sites/{site_id}/pay", data={"csrf": csrf, "accept_terms": "yes"}, follow_redirects=False)
    md = next(iter(bank.orders))
    bank.orders[md].update(orderStatus=2, amount=100)                  # банк сообщает другую сумму
    _callback(c, md)
    run_jobs(); run_jobs()
    assert site_row(site_id).status == "ready"


def test_sber_config_required_in_production(monkeypatch):
    from app.config import Settings
    for k in ("SBER_USERNAME", "SBER_PASSWORD", "SBER_CALLBACK_TOKEN"):
        monkeypatch.delenv(k, raising=False)
    problems = Settings(APP_ENV="production", PAYMENT_PROVIDER="sber").production_problems()
    assert any("SBER_CALLBACK_TOKEN" in p for p in problems)
