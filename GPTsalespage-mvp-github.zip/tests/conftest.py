"""Тесты работают с настоящим PostgreSQL: база пересоздаётся миграциями Alembic перед прогоном.

Подключение приложения идёт ролью sp_app (без BYPASSRLS), поэтому RLS проверяется по-настоящему.
"""
from __future__ import annotations

import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

import psycopg
import pytest

ROOT = Path(__file__).resolve().parent.parent
TEST_DB = "salespage_test"
STORAGE = Path("/tmp/sp_test_storage")

os.environ.update({
    "APP_ENV": "test",
    "DATABASE_URL": f"postgresql+psycopg://sp_app:app_dev_pw@127.0.0.1:5432/{TEST_DB}",
    "MIGRATIONS_DATABASE_URL": f"postgresql+psycopg://sp_owner:owner_dev_pw@127.0.0.1:5432/{TEST_DB}",
    "STORAGE_DIR": str(STORAGE), "PUBLIC_BASE_URL": "http://testserver", "SITES_DOMAIN": "sites.localhost",
    "TELEGRAM_MODE": "fake", "PAYMENT_PROVIDER": "fake", "AI_PROVIDER": "fake", "DEV_LOGIN_ENABLED": "true",
    "LEAD_RATE_LIMIT_PER_MIN": "1000", "LOGIN_RATE_LIMIT_PER_MIN": "1000",
})
sys.path.insert(0, str(ROOT))


def _recreate_db() -> None:
    with psycopg.connect("dbname=postgres user=postgres host=/var/run/postgresql", autocommit=True) as c:
        c.execute(f"SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname = '{TEST_DB}' AND pid <> pg_backend_pid()")
        c.execute(f"DROP DATABASE IF EXISTS {TEST_DB}")
        c.execute(f"CREATE DATABASE {TEST_DB} OWNER sp_owner")
    env = {**os.environ, "MIGRATIONS_DATABASE_URL_OVERRIDE": os.environ["MIGRATIONS_DATABASE_URL"]}
    res = subprocess.run([sys.executable, "-m", "alembic", "upgrade", "head"], cwd=ROOT, env=env, capture_output=True, text=True)
    assert res.returncode == 0, res.stderr[-2000:]


@pytest.fixture(scope="session", autouse=True)
def database():
    shutil.rmtree(STORAGE, ignore_errors=True)
    _recreate_db()
    yield


@pytest.fixture(scope="session")
def app(database):
    from app import publishing
    from app.web.main import app as fastapi_app
    from fastapi.testclient import TestClient

    checker = TestClient(fastapi_app)

    def verifier(slug: str, release_id: str):
        r = checker.get("/", headers={"Host": f"{slug}.sites.localhost"})
        ok = r.status_code == 200 and f'data-release="{release_id}"' in r.text
        return (ok, f"http://{slug}.sites.localhost/") if ok else (False, f"ответ {r.status_code}")

    publishing.VERIFIER = verifier  # в тестах сайт проверяется через приложение, без сетевого порта
    return fastapi_app


@pytest.fixture()
def client(app):
    from fastapi.testclient import TestClient
    return TestClient(app)


def csrf_of(html: str) -> str:
    m = re.search(r'<meta name="csrf" content="([^"]+)"', html)
    assert m, "csrf не найден"
    return m.group(1)


def login(client, name: str, role: str = "owner") -> str:
    r = client.post("/auth/dev", data={"name": name, "role": role}, follow_redirects=True)
    assert r.status_code == 200, r.text[:300]
    return csrf_of(r.text)


def run_jobs() -> list[str]:
    from app.jobs import run_pending
    return run_pending()


ANSWERS = [
    "Флора на Садовой", "Авторские букеты и доставка цветов", "Санкт-Петербург", "Авторские букеты; Розы",
    "Букеты от 2500 ₽", "Доставка по городу за 2 часа, 400 ₽", "Карта при получении; Перевод по СБП",
    "Собираем букет под повод; Фото букета перед отправкой", "Дарят цветы близким", "Оставить заявку",
    "+7 912 345-67-89", "+7 912 345-67-80, @flora_spb", "Садовая улица, 10", "ежедневно 9:00–21:00", "нет", "Нежный",
]


def create_site(client, csrf: str) -> str:
    r = client.post("/cabinet/projects", data={"csrf": csrf}, follow_redirects=False)
    assert r.status_code == 303
    site_id = r.headers["location"].rsplit("/", 1)[1]
    for a in ANSWERS:
        res = client.post(f"/cabinet/sites/{site_id}/answer", data={"text": a}, headers={"X-CSRF-Token": csrf}).json()
        assert res["ok"], (a, res)
    return site_id


def ready_site(client, name: str) -> tuple[str, str]:
    """Вход, диалог, генерация, иллюстрация, подтверждение: сайт готов к оплате."""
    csrf = login(client, name)
    site_id = create_site(client, csrf)
    h = {"X-CSRF-Token": csrf}
    assert client.post(f"/cabinet/sites/{site_id}/generate", data={}, headers=h).json()["ok"]
    run_jobs()
    assert client.post(f"/cabinet/sites/{site_id}/hero", data={"ref": "illustration:tulips"}, headers=h).json()["ok"]
    res = client.post(f"/cabinet/sites/{site_id}/confirm", data={}, headers=h).json()
    assert res["ok"], res
    return csrf, site_id


def start_payment(client, csrf: str, site_id: str) -> str:
    r = client.post(f"/cabinet/sites/{site_id}/pay", data={"csrf": csrf, "accept_terms": "yes"}, follow_redirects=False)
    assert r.status_code == 303 and "/test-checkout/" in r.headers["location"], r.headers.get("location")
    return r.headers["location"].rsplit("/", 1)[1]


def signed_webhook(client, pid: str, status: str = "succeeded", amount_kop=None):
    from app.billing import FakePaymentProvider
    from app.utils import hmac_hex
    body = FakePaymentProvider().simulate(pid, status, amount_kop)
    sig = hmac_hex(os.environ.get("PAYMENT_WEBHOOK_SECRET", "fake-webhook-secret"), body)
    return client.post("/webhooks/payments/fake", content=body, headers={"x-fake-signature": sig}), body


def site_row(site_id: str):
    from app.db import system_session
    from app.models import Site
    with system_session() as s:
        return s.get(Site, site_id)
