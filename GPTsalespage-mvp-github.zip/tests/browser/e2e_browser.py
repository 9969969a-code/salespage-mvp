"""Сквозная проверка в настоящем Chromium: пользователь кликает весь путь на компьютере и на телефоне."""
import asyncio
import json
import os
import re
import sys

from playwright.async_api import async_playwright

B = "http://127.0.0.1:8000"
SHOTS = "/tmp/shots"
os.makedirs(SHOTS, exist_ok=True)
MODE = sys.argv[1] if len(sys.argv) > 1 else "desktop"
REPORT = {"steps": [], "console_errors": [], "bad_responses": [], "overflow": {}}
PROMPT = ("Цветочный магазин «Ромашка», Санкт-Петербург. Авторские букеты, розы и пионы. Букеты от 2500 ₽. "
          "Доставка по городу за 2 часа. Оплата картой и по СБП. Телефон +7 921 000-11-22.")
REPLIES = [("преимущ", "Свежие цветы каждый день; Фото букета перед отправкой"), ("кто", "Дарят цветы близким"),
           ("покупател", "Дарят цветы близким"), ("стил", "Нежный"), ("оформлен", "Нежный"),
           ("действ", "Оставить заявку"), ("цель", "Оставить заявку")]


def step(name, ok=True, note=""):
    REPORT["steps"].append({"step": name, "ok": ok, "note": note})
    json.dump(REPORT, open(f"/tmp/shots/report_{MODE}.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(("OK   " if ok else "FAIL ") + name + (f" — {note}" if note else ""), flush=True)


def watch(page, tag):
    page.on("console", lambda m: m.type == "error" and REPORT["console_errors"].append(f"{tag}: {m.text[:200]}"))
    page.on("response", lambda r: r.status >= 400 and not r.url.endswith("/favicon.ico") and
            REPORT["bad_responses"].append(f"{tag}: {r.status} {r.url[:120]}"))


async def overflow(page, name):
    w = await page.evaluate("[document.documentElement.scrollWidth, window.innerWidth]")
    REPORT["overflow"][name] = w
    return w[0] > w[1] + 1


async def shot(page, name, full=False):
    await page.screenshot(path=f"{SHOTS}/{name}.png", full_page=full)
    if await overflow(page, name):
        step(f"горизонтальная прокрутка: {name}", False, f"ширина {REPORT['overflow'][name]}")


async def desktop_flow(browser):
    ctx = await browser.new_context(viewport={"width": 1366, "height": 900}, locale="ru-RU")
    page = await ctx.new_page()
    watch(page, "desktop")
    await page.goto(B + "/")
    await shot(page, "d01_landing", full=True)
    step("главная открылась", "Создайте сайт для своего бизнеса" in await page.content())
    await page.click("text=Войти")
    await page.fill("#n", "Анна")
    await page.click("button:has-text('Войти в тестовом режиме')")
    await page.wait_for_url("**/cabinet")
    await shot(page, "d02_dashboard")
    step("вход и кабинет")
    await page.click("button:has-text('Создать сайт с ИИ')")
    await page.wait_for_selector("#composer-input")
    await page.fill("#composer-input", PROMPT)
    await page.click("#composer-send")
    for _ in range(12):
        await page.wait_for_timeout(900)
        if await page.locator("#generate-btn").count():
            break
        msgs = page.locator(".msg.assistant, .msg.err")
        last = (await msgs.nth(await msgs.count() - 1).inner_text()).lower()
        if await page.locator("#composer-input").is_disabled():
            await page.wait_for_selector("#generate-btn", timeout=10000)
            break
        await page.fill("#composer-input", next((a for k, a in REPLIES if k in last), "Цветочный магазин с доставкой"))
        await page.click("#composer-send")
    await page.wait_for_selector("#generate-btn", timeout=15000)
    await shot(page, "d03_dialog_done")
    step("промт и уточнения в чате")
    await page.click("#generate-btn")
    await page.wait_for_selector("#preview-frame", timeout=90000)
    await page.wait_for_timeout(1500)
    await shot(page, "d04_editor_preview")
    frame = page.frame_locator("#preview-frame")
    step("сайт сгенерирован, предпросмотр показан", "Ромашка" in await frame.locator("body").inner_text())
    await page.fill("#composer-input", "Перепиши заголовок")
    await page.click("#composer-send")
    await page.wait_for_selector("#version-note:not([hidden])", timeout=15000)
    step("правка словами создала новую версию")
    await page.fill("#composer-input", "Расскажи анекдот")
    await page.click("#composer-send")
    await page.wait_for_timeout(1200)
    step("посторонний вопрос отклонён", "только" in (await page.locator(".msg").last.inner_text()).lower())
    await page.click("button[data-tab='t-photos']")
    await page.click("#t-photos form[action$='/hero'] button:has-text('Выбрать')")
    await page.wait_for_load_state("load")
    await page.wait_for_timeout(1500)
    await page.click("button[data-tab='t-publish']")
    await shot(page, "d05_publish_tab")
    await page.click("button:has-text('Всё верно, подтверждаю')")
    await page.wait_for_timeout(1500)
    await page.click("button[data-tab='t-publish']")
    await page.check("input[name=accept_terms]")
    await page.click("button:has-text('Оплатить')")
    await page.wait_for_url("**/test-checkout/**")
    await shot(page, "d06_checkout")
    step("переход к тестовой оплате", "1990" in await page.content())
    await page.click("button:has-text('Оплатить (тест)')")
    await page.wait_for_url("**/cabinet/orders/**")
    await page.wait_for_selector("text=сайт опубликован", timeout=90000)
    await shot(page, "d07_order_live")
    step("оплата подтверждена, сайт опубликован")
    site_url = await page.get_attribute("a:has-text('Открыть сайт')", "href")
    site = await ctx.new_page()
    watch(site, "site-desktop")
    await site.goto(site_url)
    await site.wait_for_timeout(800)
    await shot(site, "d08_client_site", full=True)
    step("сайт клиента открывается по поддомену", "Ромашка" in await site.content(), site_url)
    await site.fill("form[action='/_lead'] input[name=name]", "Ольга")
    await site.fill("form[action='/_lead'] input[name=phone]", "+7 921 555-44-33")
    await site.check("form[action='/_lead'] input[name=consent]")
    await site.click("form[action='/_lead'] button[type=submit]")
    await site.wait_for_load_state("load")
    step("заявка отправлена с сайта", "Заявка отправлена" in await site.content())
    await page.goto(B + "/cabinet/leads")
    await shot(page, "d09_leads")
    step("заявка видна в кабинете", "Ольга" in await page.content())
    await page.goto(B + "/cabinet/analytics")
    await shot(page, "d10_analytics")
    txt = await page.inner_text("main")
    step("аналитика показывает посещение и заявку", bool(re.search(r"\b1\b", txt)))
    await ctx.close()
    return site_url


async def mobile_flow(browser, site_url):
    ctx = await browser.new_context(viewport={"width": 390, "height": 844}, device_scale_factor=2, is_mobile=True,
                                    has_touch=True, locale="ru-RU",
                                    user_agent="Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 Mobile/15E148")
    page = await ctx.new_page()
    watch(page, "mobile")
    await page.goto(B + "/")
    await shot(page, "m01_landing", full=True)
    await page.goto(B + "/login")
    await page.fill("#n", "Анна")
    await page.click("button:has-text('Войти в тестовом режиме')")
    await page.wait_for_url("**/cabinet")
    await shot(page, "m02_dashboard", full=True)
    await page.click("text=Открыть редактор")
    await page.wait_for_selector("#composer-input")
    await shot(page, "m03_editor_chat")
    await page.click(".switcher button[data-view='preview']")
    await page.wait_for_timeout(1500)
    await shot(page, "m04_editor_preview")
    step("мобильный редактор: переключение чат/предпросмотр")
    for name, path in [("m05_leads", "/cabinet/leads"), ("m06_analytics", "/cabinet/analytics"), ("m07_promotion", "/cabinet/promotion")]:
        await page.goto(B + path)
        await shot(page, name, full=True)
    site = await ctx.new_page()
    watch(site, "site-mobile")
    await site.goto(site_url)
    await site.wait_for_timeout(800)
    await shot(site, "m08_client_site", full=True)
    step("мобильные страницы сняты")
    await ctx.close()


async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch(executable_path="/tmp/chr/run/chromium",
                                          env={**os.environ, "LD_LIBRARY_PATH": "/tmp/chr/run/al2023/lib:/tmp/chr/run"},
                                          args=["--no-sandbox", "--disable-gpu", "--single-process", "--no-zygote",
                                                "--use-gl=swiftshader", "--disable-dev-shm-usage"])
        try:
            if MODE == "desktop":
                url = await desktop_flow(browser)
                open("/tmp/shots/site_url.txt", "w").write(url)
            else:
                await mobile_flow(browser, open("/tmp/shots/site_url.txt").read().strip())
        except Exception as exc:  # noqa: BLE001
            step("сценарий прерван", False, f"{exc.__class__.__name__}: {str(exc)[:300]}")
        await browser.close()
    json.dump(REPORT, open(f"/tmp/shots/report_{MODE}.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print("ошибок консоли:", len(REPORT["console_errors"]), "| ответов ≥400:", len(REPORT["bad_responses"]))
    for e in REPORT["console_errors"][:8] + REPORT["bad_responses"][:8]:
        print("  ", e)


asyncio.run(main())
