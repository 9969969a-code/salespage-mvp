# Проверка в настоящем браузере

`e2e_browser.py` кликает весь путь в Chromium: вход → промт → генерация → правка → отказ на постороннюю тему →
тестовая оплата → публикация → сайт по поддомену → заявка → кабинет → аналитика; затем мобильные экраны 390×844.
Собирает ошибки консоли, ответы ≥400 и горизонтальную прокрутку, снимки кладёт в /tmp/shots.

Нужны запущенные приложение и воркер на 127.0.0.1:8000 и Chromium:
`pip install playwright && playwright install chromium`, затем в скрипте замените executable_path на путь Playwright
(в среде разработки использовался Chromium 131 из npm-пакета @sparticuz/chromium).
Запуск: `python tests/browser/e2e_browser.py desktop`, затем `python tests/browser/e2e_browser.py mobile`.
