"""Адаптер Claude (Anthropic Messages API) и ограничение общения темой сайта."""
import json

import httpx
import pytest
from fastapi.testclient import TestClient

from tests.conftest import create_site, login, run_jobs

FACTS = {"name": "Ромашка", "about": "Авторские букеты", "city": "Санкт-Петербург", "assortment": "Розы; Пионы",
         "phone": "79210001122", "address": "Садовая ул., 1", "style": "Нежный", "advantages": "Фото букета перед отправкой",
         "payment": "Карта", "audience": "Дарят цветы", "goal": "Оставить заявку"}


def _settings():
    from app.config import Settings
    return Settings(AI_PROVIDER="anthropic", AI_API_KEY="test-key", AI_MODEL="claude-sonnet-5-5")


def test_anthropic_request_and_parsing(monkeypatch):
    from app import ai
    seen = {}

    def fake_post(url, **kw):
        seen.update(url=url, **kw)
        site = kw["json"]["messages"][0]["content"]
        payload = json.loads(site)
        result = payload["site"]
        result["blocks"][0]["data"]["title"] = "Букеты в Санкт-Петербурге"
        body = {"content": [{"type": "text", "text": "```json\n" + json.dumps(result, ensure_ascii=False) + "\n```"}]}
        return httpx.Response(200, json=body, request=httpx.Request("POST", url))

    monkeypatch.setattr(ai.httpx, "post", fake_post)
    out = ai.get_provider(_settings()).generate(FACTS, "illustration:bouquet")
    assert seen["url"] == "https://api.anthropic.com/v1/messages"
    assert seen["headers"]["x-api-key"] == "test-key" and seen["headers"]["anthropic-version"] == "2023-06-01"
    assert seen["json"]["model"] == "claude-sonnet-5-5" and "ТОЛЬКО факты" in seen["json"]["system"]
    sent = seen["json"]["messages"][0]["content"]
    assert "79210001122" not in sent and "Садовая" not in sent  # телефон и адрес модели не передаются
    assert out["blocks"][0]["data"]["title"] == "Букеты в Санкт-Петербурге"


def test_anthropic_errors(monkeypatch):
    from app import ai
    monkeypatch.setattr(ai.httpx, "post", lambda url, **kw: httpx.Response(200, json={"content": [{"type": "text", "text": "не JSON"}]},
                                                                            request=httpx.Request("POST", url)))
    with pytest.raises(ai.AIError):
        ai.get_provider(_settings()).generate(FACTS, None)
    monkeypatch.setattr(ai.httpx, "post", lambda url, **kw: httpx.Response(401, json={}, request=httpx.Request("POST", url)))
    with pytest.raises(ai.AIError):
        ai.get_provider(_settings()).edit({"blocks": []}, "Перепиши заголовок", FACTS)
    from app.config import Settings
    assert any("AI_API_KEY" in x for x in Settings(APP_ENV="production", AI_PROVIDER="anthropic").production_problems())


def test_assistant_stays_on_topic(app):
    from app.assistant import classify
    assert classify("Расскажи анекдот") == "offtopic" and classify("Какая погода завтра?") == "offtopic"
    assert classify("Сколько стоит публикация?") == "question"
    assert classify("Перепиши заголовок") == "edit"
    c = TestClient(app)
    csrf = login(c, "Тема")
    sid = create_site(c, csrf)
    h = {"X-CSRF-Token": csrf}
    c.post(f"/cabinet/sites/{sid}/generate", data={}, headers=h)
    run_jobs()
    v = c.get(f"/cabinet/sites/{sid}/state").json()["version"]
    r = c.post(f"/cabinet/sites/{sid}/edit", data={"command": "Напиши мне стихотворение про осень"}, headers=h).json()
    assert not r["ok"] and r["kind"] == "offtopic" and "только" in r["message"]
    r = c.post(f"/cabinet/sites/{sid}/edit", data={"command": "Сколько стоит публикация?"}, headers=h).json()
    assert r["ok"] and r["kind"] == "answer" and "1990" in r["message"]
    assert c.get(f"/cabinet/sites/{sid}/state").json()["version"] == v  # вопросы и посторонние темы не создают версий
    assert c.post(f"/cabinet/sites/{sid}/edit", data={"command": "Перепиши заголовок"}, headers=h).json()["ok"]
