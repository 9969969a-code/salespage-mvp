"""Поиск клиентов: отбор, офферы на одобрение, без отправки до одобрения, отписка, стоп-лист, конверсия."""
import re

from fastapi.testclient import TestClient
from sqlalchemy import func, select

from tests.conftest import login, run_jobs


def _q(model, *where):
    from app.db import system_session
    with system_session() as s:
        return s.scalars(select(model).where(*where)).all()


def test_pipeline_review_send_unsubscribe(app):
    from app.models import FakeEmail, OutreachMessage, Prospect, SuppressionEntry
    admin = TestClient(app)
    csrf = login(admin, "Оператор поиска", "admin")
    assert admin.post("/admin/prospects/search", data={"csrf": csrf, "city": "Санкт-Петербург"}).status_code == 200
    run_jobs()
    by_name = {p.name.split(" (")[0]: p for p in _q(Prospect, Prospect.city == "Санкт-Петербург")}
    assert by_name["Цветочная лавка «Незабудка»"].status == "pending_review"   # нет сайта
    assert by_name["Флора-Студия"].site_status == "no_https"
    assert by_name["Букетная «Пион»"].site_status == "no_mobile"
    assert by_name["Розы и Ко"].status == "has_site"                          # хороший сайт — не пишем
    assert by_name["Тюльпан-маркет"].status == "call_list"                    # без email — только звонок
    assert by_name["Химчистка «Блеск»"].status == "disqualified"              # не наша ниша
    pending = _q(OutreachMessage, OutreachMessage.status == "pending_review")
    addrs = [m.to_address for m in pending]
    assert len(pending) == 3 and not _q(FakeEmail, FakeEmail.to_address.in_(addrs))  # до одобрения ничего не отправлено
    # повторный поиск не дублирует компании и письма
    admin.post("/admin/prospects/search", data={"csrf": csrf, "city": "Санкт-Петербург"})
    run_jobs()
    assert len(_q(Prospect, Prospect.city == "Санкт-Петербург")) == 6 and len(_q(OutreachMessage)) == 3
    page = admin.get("/admin?section=prospects").text
    assert "Ждут одобрения: 3" in page and "[MOCK]" in page
    m1, m2, m3 = sorted(pending, key=lambda m: m.to_address)
    # текст без ссылки отказа не принимается
    r = admin.post(f"/admin/outreach/{m1.id}", data={"csrf": csrf, "decision": "approve", "body": "Купите сайт"})
    assert "ссылка отказа" in r.text and _q(OutreachMessage, OutreachMessage.id == m1.id)[0].status == "pending_review"
    admin.post(f"/admin/outreach/{m1.id}", data={"csrf": csrf, "decision": "approve"})
    admin.post(f"/admin/outreach/{m2.id}", data={"csrf": csrf, "decision": "reject"})
    admin.post(f"/admin/outreach/{m3.id}", data={"csrf": csrf, "decision": "approve"})
    c = TestClient(app)
    assert c.get(f"/u/{m3.unsubscribe_token}").status_code == 200        # отписался до отправки
    run_jobs()
    emails = _q(FakeEmail, FakeEmail.to_address.in_(addrs))
    assert [e.to_address for e in emails] == [m1.to_address]              # ушло только одобренное и не отписавшееся
    body = emails[0].body
    assert "/u/" in body and "?ref=" in body and "справочнике" in body and "1990" in body
    assert _q(OutreachMessage, OutreachMessage.id == m2.id)[0].status == "rejected"
    assert _q(OutreachMessage, OutreachMessage.id == m3.id)[0].status == "blocked"
    assert _q(SuppressionEntry, SuppressionEntry.value == m3.to_address)
    assert c.get("/u/no-such-token").status_code == 404
    # переход по ссылке из письма и регистрация засчитываются компании
    ref = re.search(r"\?ref=([0-9a-f]+)", body).group(1)
    newbie = TestClient(app)
    newbie.get(f"/?ref={ref}")
    login(newbie, "Владелец из письма")
    assert _q(Prospect, Prospect.ref_token == ref)[0].status == "converted"


def test_prospecting_admin_only(app):
    c = TestClient(app)
    csrf = login(c, "Не оператор")
    assert c.get("/admin?section=prospects").status_code == 403
    assert c.post("/admin/prospects/search", data={"csrf": csrf, "city": "Москва"}).status_code == 403


def test_owner_cannot_see_prospects_in_db():
    from app.db import user_session
    from app.models import Prospect
    import uuid
    with user_session(uuid.uuid4()) as s:  # данные платформы закрыты RLS для сессий владельцев
        assert s.scalar(select(func.count()).select_from(Prospect)) == 0
