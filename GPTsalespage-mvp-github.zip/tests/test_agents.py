"""Агенты разработки: формат субагентов Claude Code и распознавание самим Claude Code (если он установлен)."""
import json
import re
import shutil
import subprocess
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
VALID_TOOLS = {"Read", "Grep", "Glob", "Edit", "Write", "Bash", "WebFetch", "WebSearch", "Task", "TodoWrite", "NotebookEdit"}
EXPECTED = {"coordinator", "architect", "backend", "frontend", "ai-engineer", "prompt-engineer", "ui-designer", "ux-architect",
            "offer-strategist", "outbound", "content", "seo", "reality-checker", "test-automation", "code-reviewer", "appsec",
            "secrets", "devops", "payments", "fpa"}


def _front(path: Path) -> dict:
    m = re.match(r"\A---\n(.*?)\n---\n", path.read_text(encoding="utf-8"), re.S)
    assert m, f"{path.name}: нет заголовка"
    return dict(line.split(": ", 1) for line in m.group(1).splitlines() if ": " in line)


def test_agent_files_valid():
    files = sorted((ROOT / ".claude" / "agents").glob("*.md"))
    names = set()
    for f in files:
        fm = _front(f)
        assert fm["name"] == f.stem and re.fullmatch(r"[a-z][a-z0-9-]+", fm["name"]), f.name
        assert len(fm.get("description", "")) > 20, f.name
        tools = {t.strip() for t in fm.get("tools", "").split(",")}
        assert tools <= VALID_TOOLS, (f.name, tools - VALID_TOOLS)
        names.add(fm["name"])
    assert names == EXPECTED
    assert (ROOT / "CLAUDE.md").exists() and "reality-checker" in (ROOT / "CLAUDE.md").read_text(encoding="utf-8")


@pytest.mark.skipif(shutil.which("claude") is None, reason="Claude Code не установлен")
def test_claude_code_recognizes_all_agents():
    p = subprocess.run(["claude", "-p", "ok", "--output-format", "stream-json", "--verbose"], cwd=ROOT, capture_output=True,
                       text=True, timeout=120, stdin=subprocess.DEVNULL)
    init = next(json.loads(l) for l in p.stdout.splitlines()
                if l.startswith("{") and json.loads(l).get("subtype") == "init")
    assert EXPECTED <= set(init.get("agents") or []), EXPECTED - set(init.get("agents") or [])
