(function () {
  "use strict";
  var csrfMeta = document.querySelector('meta[name="csrf"]');
  var CSRF = csrfMeta ? csrfMeta.content : "";

  function post(url, data) {
    var body = data instanceof FormData ? data : new FormData();
    if (!(data instanceof FormData) && data) Object.keys(data).forEach(function (k) { body.append(k, data[k]); });
    return fetch(url, { method: "POST", body: body, headers: { "X-CSRF-Token": CSRF }, credentials: "same-origin" })
      .then(function (r) { return r.json().catch(function () { return { ok: false, message: "Ошибка сервера (" + r.status + ")" }; }); })
      .catch(function () { return { ok: false, message: "Нет связи с сервером. Проверьте интернет." }; });
  }

  // Формы с data-ajax: ответ показывается рядом, при успехе страница может перезагрузиться
  document.querySelectorAll("form[data-ajax]").forEach(function (f) {
    f.addEventListener("submit", function (e) {
      e.preventDefault();
      var out = f.querySelector("[data-result]");
      var btn = f.querySelector("button[type=submit]");
      if (btn) btn.disabled = true;
      post(f.action, new FormData(f)).then(function (res) {
        if (btn) btn.disabled = false;
        if (out) { out.className = "notice " + (res.ok ? "notice-ok" : "notice-err"); out.textContent = res.message; out.hidden = false; }
        if (res.ok && f.hasAttribute("data-reload")) setTimeout(function () { location.reload(); }, 600);
      });
    });
  });

  // ---------------------------------------------------------------- редактор
  var ed = document.getElementById("editor");
  if (ed) {
    var siteId = ed.dataset.site;
    var mode = ed.dataset.mode; // dialog | generate | edit
    var chat = document.getElementById("chat");
    var input = document.getElementById("composer-input");
    var chipsBox = document.getElementById("chips");
    var frame = document.getElementById("preview-frame");
    var multi = ed.dataset.multi === "1";
    if (chat && chat.parentElement) chat.parentElement.scrollTop = chat.parentElement.scrollHeight;
    var picked = [];

    function addMsg(role, text) {
      var d = document.createElement("div");
      d.className = "msg " + role;
      d.textContent = text;
      chat.appendChild(d);
      chat.parentElement.scrollTop = chat.parentElement.scrollHeight;
    }
    function setChips(list, isMulti) {
      multi = !!isMulti; picked = [];
      chipsBox.innerHTML = "";
      (list || []).forEach(function (t) {
        var b = document.createElement("button");
        b.type = "button"; b.className = "chip"; b.textContent = t;
        chipsBox.appendChild(b);
      });
    }
    chipsBox && chipsBox.addEventListener("click", function (e) {
      var b = e.target.closest(".chip");
      if (!b) return;
      if (multi) {
        b.classList.toggle("on");
        var i = picked.indexOf(b.textContent);
        if (i >= 0) picked.splice(i, 1); else picked.push(b.textContent);
        input.value = picked.join("; ");
      } else {
        input.value = b.textContent;
        send();
      }
    });
    function refreshPreview() { if (frame) frame.src = frame.dataset.src + "?t=" + Date.now(); }
    function send() {
      var text = input.value.trim();
      if (!text) return;
      addMsg("user", text);
      input.value = "";
      var url = mode === "dialog" ? "answer" : "edit";
      var field = mode === "dialog" ? { text: text } : { command: text };
      var btn = document.getElementById("composer-send");
      btn.disabled = true;
      post("/cabinet/sites/" + siteId + "/" + url, field).then(function (res) {
        btn.disabled = false;
        addMsg(res.ok ? "assistant" : "err", res.message);
        if (mode === "dialog") {
          setChips(res.chips, res.multi);
          if (res.done) { setTimeout(function () { location.reload(); }, 700); }
        } else if (res.ok && res.kind !== "answer") {
          refreshPreview();
          var v = document.getElementById("version-note");
          if (v) v.hidden = false;
        }
      });
    }
    var form = document.getElementById("composer");
    form && form.addEventListener("submit", function (e) { e.preventDefault(); send(); });

    var gen = document.getElementById("generate-btn");
    function poll() {
      fetch("/cabinet/sites/" + siteId + "/state", { credentials: "same-origin" }).then(function (r) { return r.json(); }).then(function (st) {
        if (st.generation_status === "done") location.reload();
        else if (st.generation_status === "failed") { addMsg("err", "Не удалось создать сайт: " + (st.generation_error || "попробуйте ещё раз")); if (gen) gen.disabled = false; }
        else setTimeout(poll, 2000);
      }).catch(function () { setTimeout(poll, 4000); });
    }
    gen && gen.addEventListener("click", function () {
      gen.disabled = true;
      post("/cabinet/sites/" + siteId + "/generate", {}).then(function (res) {
        addMsg(res.ok ? "assistant" : "err", res.message);
        if (res.ok) poll(); else gen.disabled = false;
      });
    });
    if (ed.dataset.gen === "queued" || ed.dataset.gen === "running") poll();

    document.querySelectorAll(".tabs button").forEach(function (b) {
      b.addEventListener("click", function () {
        document.querySelectorAll(".tabs button").forEach(function (x) { x.classList.toggle("on", x === b); });
        document.querySelectorAll(".tab").forEach(function (t) { t.classList.toggle("on", t.id === b.dataset.tab); });
      });
    });
    document.querySelectorAll(".switcher button").forEach(function (b) {
      b.addEventListener("click", function () {
        document.querySelectorAll(".switcher button").forEach(function (x) { x.classList.toggle("on", x === b); });
        ed.dataset.view = b.dataset.view;
        if (b.dataset.view === "preview") refreshPreview();
      });
    });
    document.querySelectorAll("[data-device]").forEach(function (b) {
      b.addEventListener("click", function () {
        document.querySelector(".preview").classList.toggle("mobile", b.dataset.device === "mobile");
      });
    });
    document.querySelectorAll("[data-command]").forEach(function (b) {
      b.addEventListener("click", function () { input.value = b.dataset.command; send(); });
    });
    var up = document.getElementById("photo-form");
    up && up.addEventListener("submit", function (e) {
      e.preventDefault();
      var out = up.querySelector("[data-result]");
      post(up.action, new FormData(up)).then(function (res) {
        out.className = "notice " + (res.ok ? "notice-ok" : "notice-err"); out.textContent = res.message; out.hidden = false;
        if (res.ok) setTimeout(function () { location.reload(); }, 600);
      });
    });
  }

  // ---------------------------------------------------------------- страница заказа
  var ord = document.getElementById("order-status");
  if (ord) {
    var tries = 0;
    (function check() {
      fetch("/cabinet/orders/" + ord.dataset.order + "/status", { credentials: "same-origin" }).then(function (r) { return r.json(); }).then(function (st) {
        ord.dataset.state = st.site;
        if (st.site === "live" || st.order === "cancelled" || tries++ > 90) location.reload();
        else setTimeout(check, 2000);
      }).catch(function () { setTimeout(check, 4000); });
    })();
  }
})();
