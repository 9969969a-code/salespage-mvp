"""Alembic: миграции выполняются ролью-владельцем схемы (MIGRATIONS_DATABASE_URL)."""
import os
from logging.config import fileConfig

from alembic import context
from sqlalchemy import create_engine

from app.config import get_settings
from app.db import Base
import app.models  # noqa: F401  регистрация таблиц

config = context.config
if config.config_file_name:
    fileConfig(config.config_file_name)
target_metadata = Base.metadata


def run() -> None:
    url = os.getenv("MIGRATIONS_DATABASE_URL_OVERRIDE") or get_settings().MIGRATIONS_DATABASE_URL
    engine = create_engine(url)
    with engine.connect() as conn:
        context.configure(connection=conn, target_metadata=target_metadata, compare_type=True)
        with context.begin_transaction():
            context.run_migrations()


run()
