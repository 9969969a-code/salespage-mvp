"""Тарифы: лендинг 1 990 ₽, многостраничный сайт 4 990 ₽ (пока не продаётся: генератор в разработке).

Revision ID: 0003
Revises: 0002
"""
from alembic import op

revision = "0003"
down_revision = "0002"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute("UPDATE plans SET price_kop = 199000, name = 'Лендинг с ИИ' WHERE code = 'page'")
    op.execute("INSERT INTO plans (code, name, price_kop, period, purchasable, hosting_months) "
               "VALUES ('site', 'Многостраничный сайт с ИИ', 499000, 'one_time', false, 12) ON CONFLICT (code) DO NOTHING")


def downgrade() -> None:
    op.execute("DELETE FROM plans WHERE code = 'site'")
    op.execute("UPDATE plans SET price_kop = 99900, name = 'Сайт с ИИ' WHERE code = 'page'")
