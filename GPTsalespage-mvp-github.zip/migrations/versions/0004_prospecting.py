"""Поиск клиентов платформы: prospects, outreach_messages, suppression_list, fake_emails.

Это данные самой платформы: доступ только из системных сессий и админки (app.bypass), владельцам сайтов не виден.

Revision ID: 0004
Revises: 0003
"""
from alembic import op

revision = "0004"
down_revision = "0003"
branch_labels = None
depends_on = None
BYPASS = "current_setting('app.bypass', true) = 'on'"
TABLES = ("prospects", "outreach_messages", "suppression_list", "fake_emails")


def upgrade() -> None:
    op.execute("""
    CREATE TABLE prospects (
      id uuid PRIMARY KEY, source varchar(16) NOT NULL, external_id varchar(64) NOT NULL, name varchar(160) NOT NULL,
      niche varchar(32) NOT NULL DEFAULT '', city varchar(80) NOT NULL DEFAULT '', address varchar(200) NOT NULL DEFAULT '',
      phone varchar(20) NOT NULL DEFAULT '', email varchar(160) NOT NULL DEFAULT '', website varchar(300) NOT NULL DEFAULT '',
      site_status varchar(16) NOT NULL DEFAULT 'unknown', score integer NOT NULL DEFAULT 0, status varchar(20) NOT NULL DEFAULT 'new',
      ref_token varchar(32) NOT NULL UNIQUE, created_at timestamptz NOT NULL, updated_at timestamptz NOT NULL,
      CONSTRAINT uq_prospect_source_ext UNIQUE (source, external_id));
    CREATE INDEX ix_prospects_status ON prospects (status);
    CREATE TABLE outreach_messages (
      id uuid PRIMARY KEY, prospect_id uuid NOT NULL REFERENCES prospects(id) ON DELETE CASCADE, channel varchar(16) NOT NULL,
      to_address varchar(160) NOT NULL, subject varchar(200) NOT NULL, body text NOT NULL, status varchar(20) NOT NULL,
      unsubscribe_token varchar(48) NOT NULL UNIQUE, reviewed_by uuid, reviewed_at timestamptz, sent_at timestamptz,
      error text NOT NULL DEFAULT '', is_test boolean NOT NULL DEFAULT true, created_at timestamptz NOT NULL);
    CREATE INDEX ix_outreach_messages_prospect_id ON outreach_messages (prospect_id);
    CREATE TABLE suppression_list (value varchar(160) PRIMARY KEY, reason varchar(64) NOT NULL, created_at timestamptz NOT NULL);
    CREATE TABLE fake_emails (id uuid PRIMARY KEY, to_address varchar(160) NOT NULL, subject varchar(200) NOT NULL,
      body text NOT NULL, created_at timestamptz NOT NULL);
    """)
    for t in TABLES:
        op.execute(f"ALTER TABLE {t} ENABLE ROW LEVEL SECURITY")
        op.execute(f"ALTER TABLE {t} FORCE ROW LEVEL SECURITY")
        op.execute(f"CREATE POLICY {t}_system ON {t} USING ({BYPASS}) WITH CHECK ({BYPASS})")
        op.execute(f"GRANT SELECT, INSERT, UPDATE, DELETE ON {t} TO sp_app")


def downgrade() -> None:
    for t in reversed(TABLES):
        op.execute(f"DROP TABLE IF EXISTS {t}")
