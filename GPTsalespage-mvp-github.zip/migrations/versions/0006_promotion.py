"""Продвижение сайтов клиентов: корпоративные клиенты магазина и письма им (одобряет владелец).

Revision ID: 0006
Revises: 0005
"""
from alembic import op

revision = "0006"
down_revision = "0005"
branch_labels = None
depends_on = None
BYPASS = "current_setting('app.bypass', true) = 'on'"
ME = "NULLIF(current_setting('app.user_id', true), '')::uuid"


def upgrade() -> None:
    op.execute("""
    CREATE TABLE client_prospects (
      id uuid PRIMARY KEY, owner_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      site_id uuid NOT NULL REFERENCES sites(id) ON DELETE CASCADE, source varchar(16) NOT NULL, external_id varchar(64) NOT NULL,
      name varchar(160) NOT NULL, category varchar(32) NOT NULL, city varchar(80) NOT NULL DEFAULT '',
      email varchar(160) NOT NULL DEFAULT '', phone varchar(20) NOT NULL DEFAULT '', status varchar(20) NOT NULL,
      created_at timestamptz NOT NULL, CONSTRAINT uq_client_prospect UNIQUE (site_id, source, external_id));
    CREATE TABLE client_outreach (
      id uuid PRIMARY KEY, owner_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      site_id uuid NOT NULL REFERENCES sites(id) ON DELETE CASCADE,
      prospect_id uuid NOT NULL REFERENCES client_prospects(id) ON DELETE CASCADE, to_address varchar(160) NOT NULL,
      subject varchar(200) NOT NULL, body text NOT NULL, status varchar(20) NOT NULL, unsubscribe_token varchar(48) NOT NULL UNIQUE,
      sent_at timestamptz, created_at timestamptz NOT NULL);
    CREATE INDEX ix_client_outreach_site ON client_outreach (site_id, status);
    """)
    for t in ("client_prospects", "client_outreach"):
        cond = f"(owner_id = {ME} OR {BYPASS})"
        op.execute(f"ALTER TABLE {t} ENABLE ROW LEVEL SECURITY")
        op.execute(f"ALTER TABLE {t} FORCE ROW LEVEL SECURITY")
        op.execute(f"CREATE POLICY tenant_isolation ON {t} USING {cond} WITH CHECK {cond}")
        op.execute(f"GRANT SELECT, INSERT, UPDATE, DELETE ON {t} TO sp_app")


def downgrade() -> None:
    op.execute("DROP TABLE IF EXISTS client_outreach")
    op.execute("DROP TABLE IF EXISTS client_prospects")
