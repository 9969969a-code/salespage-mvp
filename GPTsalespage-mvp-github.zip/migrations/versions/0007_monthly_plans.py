"""Месячные тарифы (гипотезы цен из ТЗ). Не продаются, пока не подключены регулярные платежи.

Revision ID: 0007
Revises: 0006
"""
from alembic import op

revision = "0007"
down_revision = "0006"
branch_labels = None
depends_on = None
PLANS = [("care", "Обслуживание сайта", 499000), ("growth_m", "Расширенный", 999000), ("agency", "Агентский", 1999000)]


def upgrade() -> None:
    for code, name, price in PLANS:
        op.execute(f"INSERT INTO plans (code, name, price_kop, period, purchasable, hosting_months) "
                   f"VALUES ('{code}', '{name}', {price}, 'monthly', false, 1) ON CONFLICT (code) DO NOTHING")


def downgrade() -> None:
    op.execute("DELETE FROM plans WHERE code IN ('care', 'growth_m', 'agency')")
