"""RLS-политики, права роли приложения, журнал только на добавление, тарифы.

Revision ID: 0002
Revises: 0001
"""
from alembic import op

revision = "0002"
down_revision = "0001"
branch_labels = None
depends_on = None

APP_ROLE = "sp_app"
OWNER_TABLES = [
    "user_consents", "businesses", "business_facts", "projects", "conversations", "messages", "sites",
    "site_versions", "assets", "orders", "payments", "publications", "leads", "notification_channels",
    "telegram_link_tokens", "notifications", "ai_usage", "support_tickets", "upgrade_requests",
    "events", "audit_log",
]
USER_ID_TABLES = ["sessions", "auth_identities"]
BYPASS = "current_setting('app.bypass', true) = 'on'"
ME = "NULLIF(current_setting('app.user_id', true), '')::uuid"


def _policy(table: str, column: str) -> None:
    cond = f"({column} = {ME} OR {BYPASS})"
    op.execute(f"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY")
    op.execute(f"ALTER TABLE {table} FORCE ROW LEVEL SECURITY")
    op.execute(f"CREATE POLICY tenant_isolation ON {table} USING {cond} WITH CHECK {cond}")


def upgrade() -> None:
    for t in OWNER_TABLES:
        _policy(t, "owner_id")
    for t in USER_ID_TABLES:
        _policy(t, "user_id")
    _policy("users", "id")

    op.execute(f"GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO {APP_ROLE}")
    op.execute(f"REVOKE UPDATE, DELETE ON audit_log FROM {APP_ROLE}")
    op.execute(f"REVOKE DELETE ON payment_events FROM {APP_ROLE}")
    op.execute(f"REVOKE INSERT, UPDATE, DELETE ON alembic_version FROM {APP_ROLE}")

    op.execute(
        "INSERT INTO plans (code, name, price_kop, period, purchasable, hosting_months) VALUES "
        "('page', 'Сайт с ИИ', 99900, 'one_time', true, 12), "
        "('growth', 'Сайт и продвижение', 990000, 'monthly', false, 0), "
        "('pro', 'Расширенные продажи', 1499000, 'monthly', false, 0)"
    )
    op.execute("INSERT INTO system_flags (key, value) VALUES ('pause_ai', 'off'), ('pause_publishing', 'off')")


def downgrade() -> None:
    op.execute("DELETE FROM system_flags")
    op.execute("DELETE FROM plans")
    for t in OWNER_TABLES + USER_ID_TABLES + ["users"]:
        op.execute(f"DROP POLICY IF EXISTS tenant_isolation ON {t}")
        op.execute(f"ALTER TABLE {t} NO FORCE ROW LEVEL SECURITY")
        op.execute(f"ALTER TABLE {t} DISABLE ROW LEVEL SECURITY")
