"""Тариф сайта (лендинг или многостраничный) и включение продажи тарифа 4 990 ₽.

Revision ID: 0005
Revises: 0004
"""
from alembic import op

revision = "0005"
down_revision = "0004"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute("ALTER TABLE sites ADD COLUMN plan_code varchar(32) NOT NULL DEFAULT 'page' REFERENCES plans(code)")
    op.execute("UPDATE plans SET purchasable = true WHERE code = 'site'")


def downgrade() -> None:
    op.execute("UPDATE plans SET purchasable = false WHERE code = 'site'")
    op.execute("ALTER TABLE sites DROP COLUMN plan_code")
