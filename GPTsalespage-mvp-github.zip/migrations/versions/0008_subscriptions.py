"""Подписка на обслуживание сайта: ежемесячная оплата по ссылке (без автоплатежей).

Revision ID: 0008
Revises: 0007
"""
from alembic import op

revision = "0008"
down_revision = "0007"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute("ALTER TABLE sites ADD COLUMN service_plan varchar(32) REFERENCES plans(code)")
    op.execute("ALTER TABLE sites ADD COLUMN service_paid_until timestamptz")
    op.execute("ALTER TABLE sites ADD COLUMN service_reminded_for timestamptz")


def downgrade() -> None:
    for c in ("service_reminded_for", "service_paid_until", "service_plan"):
        op.execute(f"ALTER TABLE sites DROP COLUMN {c}")
