# Внешние сервисы

| Сервис | Где в коде | Статус | Что нужно для подключения |
|---|---|---|---|
| VK ID | `app/web/auth.py` | Код по документации (OAuth 2.1, PKCE, `id.vk.com/authorize`, `/oauth2/auth`, `/oauth2/user_info`); не проверено | Приложение в кабинете VK ID, доверенный адрес `https://<платформа>/auth/vk/callback`, `VK_CLIENT_ID`. Сверить параметры с актуальной документацией |
| Сбербанк: эквайринг, SberPay, СБП | `app/sber.py` | Адаптер написан: register.do, getOrderStatusExtended.do, callback с контрольной суммой; проверен на имитации банка, на тестовом контуре Сбера НЕ проверен | Договор интернет-эквайринга, логин `…-api`, пароль, токен callback, адрес уведомлений `https://<платформа>/webhooks/payments/sber`. Сверить формат запросов с документацией банка |
| Прочие провайдеры | `app/billing.py` (`PaymentProvider`) | Имитатор `fake` | Юридический статус, договор, тестовый магазин. Реализовать `create_payment`, `get_payment` (сверка через API), `verify_webhook` по правилам провайдера |
| Telegram Bot API | `app/notify.py` | Тестовый адаптер работает; боевой режим не проверен | Бот у @BotFather, `TELEGRAM_BOT_TOKEN`, `setWebhook` на `/webhooks/telegram` с `secret_token` = `TELEGRAM_WEBHOOK_SECRET` |
| ИИ | `app/ai.py` (`OpenAICompatProvider`) | Тестовый генератор работает; внешний не проверен | Выбрать провайдера с OpenAI-совместимым API, `AI_BASE_URL`, `AI_API_KEY`, `AI_MODEL`. Телефоны, адреса и реквизиты модели не передаются |
| Caddy, сертификаты | `deploy/Caddyfile`, `/internal/tls-allowed` | Конфигурация не проверена | Домены, DNS, проверить лимиты выпуска сертификатов |
| Шрифт Inter | `static/fonts` | Локально, лицензия OFL приложена | — |
