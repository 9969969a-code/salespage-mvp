# Эксплуатация

## Развёртывание (VPS Ubuntu 24.04, РФ) — не проверено на реальном сервере
1. Пакеты: `apt install postgresql-16 python3.12-venv caddy`.
2. Роли и база: `sudo -u postgres psql -f scripts/db_roles.sql` (замените пароли).
3. Код в `/opt/salespage`, пользователь `salespage`, `python3.12 -m venv venv && venv/bin/pip install -r requirements.txt`.
4. `.env` из `.env.example`: `APP_ENV=production`, секреты, домены, `DEV_LOGIN_ENABLED=False`. Приложение не запустится, пока в production остаются тестовые адаптеры.
5. Миграции: `venv/bin/alembic upgrade head` (выполняются ролью sp_owner).
6. `deploy/Caddyfile` → `/etc/caddy/Caddyfile`, `systemctl reload caddy`.
7. `deploy/systemd/*` → `/etc/systemd/system/`, `systemctl enable --now salespage-web salespage-worker salespage-backup.timer`.
8. Проверка: `curl https://platform.example.ru/ready`.

## Обновление и откат
- Перед выкладкой проходят тесты (`.github/workflows/ci.yml`).
- Выкладка: `git pull`, `pip install -r requirements.txt`, резервная копия, `alembic upgrade head`, `systemctl restart salespage-web salespage-worker`.
- Откат кода: предыдущий тег и перезапуск. Откат миграции: `alembic downgrade -1` только после резервной копии.
- Откат опубликованного сайта: в админке повторить публикацию нужной версии; владелец может вернуть версию в редакторе.

## Резервные копии
- Ежедневно в 03:30 (`salespage-backup.timer`): дамп базы, архив `storage/`, контрольные суммы, хранение 14 дней.
- Отправку во внешнее хранилище нужно настроить (rclone или s3cmd в S3-совместимое хранилище в РФ); сейчас копии остаются на том же сервере.
- Проверка восстановления: `scripts/restore_check.sh backups/db-<время>.dump` раз в неделю, а также автотест `tests/test_zz_backup.py`.
- Под принудительной RLS дамп и восстановление выполняются с `PGOPTIONS="-c app.bypass=on"`, это уже заложено в скрипты.

## Мониторинг
- `/health` — процесс жив; `/ready` — база доступна, очередь не отстаёт больше 10 минут.
- Админка, «Обзор»: задачи в очереди и без повторов, расход ИИ за сутки, аварийные флаги остановки ИИ и публикаций.
- Оповещения оператору уходят в Telegram (`OPERATOR_TELEGRAM_CHAT_ID`): сбой публикации, недоставленные уведомления, несовпадение суммы, жалобы, обращения.
- Внешнюю проверку доступности (`/ready` и один клиентский сайт) нужно подключить; сервис не выбран.

## Аварийные действия
- Остановить ИИ или публикации: админка → «Обзор» → флаги.
- Приостановить сайт: админка → «Сайты» или «Жалобы» (с причиной, пишется в журнал).
- Ограничители частоты хранятся в памяти одного процесса: запускайте веб-приложение одним процессом или перенесите лимиты в базу.
