# Агенты проекта

Есть два вида агентов, и их нельзя путать.

## 1. Агенты разработки (инструкции для ИИ-помощника)

Взяты из [Agency Agents](https://github.com/msitarzewski/agency-agents) (MIT), оригиналы без изменений в `agents/upstream/`, коммит источника в `agents/upstream/SOURCE_COMMIT`. Адаптация под проект собирается командой `python scripts/build_agents.py` в `.claude/agents/`. Их вызывает Claude Code при работе над кодом (`/agents` или упоминанием роли). В работающей платформе они не исполняются и доступа к серверу и данным клиентов не имеют.

| Агент | Роль | Оригинал | Инструменты |
|---|---|---|---|
| `coordinator` | Руководитель проекта и координатор | Senior Project Manager | Read, Grep, Glob |
| `architect` | Архитектор | Software Architect | Read, Grep, Glob |
| `backend` | Backend-разработчик | Backend Architect | Read, Grep, Glob, Edit, Write, Bash |
| `frontend` | Frontend-разработчик | Frontend Developer | Read, Grep, Glob, Edit, Write, Bash |
| `ai-engineer` | AI-инженер | AI Engineer | Read, Grep, Glob, Edit, Write, Bash |
| `prompt-engineer` | Промпт-инженер | Prompt Engineer | Read, Grep, Glob, Edit, Write, Bash |
| `ui-designer` | UI-дизайнер | UI Designer | Read, Grep, Glob, Edit, Write, Bash |
| `ux-architect` | UX-архитектор | UX Architect | Read, Grep, Glob |
| `offer-strategist` | Стратег офферов и лидогенерации | Offer & Lead Gen Strategist | Read, Grep, Glob |
| `outbound` | Специалист исходящих продаж | Outbound Strategist | Read, Grep, Glob |
| `content` | Контент-маркетолог | Content Creator | Read, Grep, Glob |
| `seo` | SEO-специалист | SEO Specialist | Read, Grep, Glob |
| `reality-checker` | Контролёр реальности (QA) | Reality Checker | Read, Grep, Glob, Bash |
| `test-automation` | Инженер автотестов | Test Automation Engineer | Read, Grep, Glob, Edit, Write, Bash |
| `code-reviewer` | Ревьюер кода | Code Reviewer | Read, Grep, Glob |
| `appsec` | Инженер безопасности приложений | Application Security Engineer | Read, Grep, Glob, Bash |
| `secrets` | Инженер по секретам | Secrets & Credential Hygiene Engineer | Read, Grep, Glob |
| `devops` | DevOps-инженер | DevOps Automator | Read, Grep, Glob, Edit, Write, Bash |
| `payments` | Инженер платежей | Payments & Billing Engineer | Read, Grep, Glob, Edit, Write, Bash |
| `fpa` | Финансовый аналитик | FP&A Analyst | Read, Grep, Glob |

Порядок работы: координатор планирует → архитектор проверяет решение → разработчики меняют код → автотесты и appsec проверяют → reality-checker выносит вердикт по доказательствам → владелец согласует.

## 2. Агенты выполнения (работают внутри платформы)

Это существующие модули, которые реально запускаются очередью задач (`app/jobs.py`). Их состояние, ошибки и повторы видны в админке, раздел «Агенты». Описание ролей: `app/agents.py`.
