#!/usr/bin/env bash
# Резервная копия: дамп PostgreSQL + архив файлов (загрузки и релизы сайтов) + контрольные суммы.
# Использование: DATABASE_BACKUP_URL=postgresql://sp_owner:...@127.0.0.1/salespage scripts/backup.sh
# Отправка копий во внешнее хранилище (S3-совместимое) настраивается отдельно, см. docs/RUNBOOK.md.
set -euo pipefail
: "${DATABASE_BACKUP_URL:?нужен DATABASE_BACKUP_URL}"
BACKUP_DIR="${BACKUP_DIR:-./backups}"
STORAGE_DIR="${STORAGE_DIR:-./storage}"
RETENTION_DAYS="${RETENTION_DAYS:-14}"
ts="$(date -u +%Y%m%dT%H%M%SZ)"
mkdir -p "$BACKUP_DIR"
# Таблицы под FORCE ROW LEVEL SECURITY: служебный режим app.bypass открывает все строки для дампа.
export PGOPTIONS="-c app.bypass=on"
pg_dump --enable-row-security --format=custom --no-owner --file "$BACKUP_DIR/db-$ts.dump" "$DATABASE_BACKUP_URL"
tar -czf "$BACKUP_DIR/storage-$ts.tar.gz" -C "$STORAGE_DIR" .
(cd "$BACKUP_DIR" && sha256sum "db-$ts.dump" "storage-$ts.tar.gz" > "sha256-$ts.txt")
find "$BACKUP_DIR" -type f -mtime +"$RETENTION_DAYS" -delete
echo "$BACKUP_DIR/db-$ts.dump"
