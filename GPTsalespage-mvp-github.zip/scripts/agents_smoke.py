"""Фактическая проверка 20 агентов разработки через Claude Code (штатный механизм субагентов).

1) Распознавание: Claude Code при старте сессии в папке проекта перечисляет загруженных агентов (событие init).
2) Вызов: каждый агент запускается как агент сессии (`claude -p ... --agent <имя>`) с профильной задачей,
   только чтение (--permission-mode plan, инструменты Read/Grep/Glob). Ответ сохраняется в
   agents/verification/<имя>.json — это доказательство вызова. Агент считается проверенным, если is_error=false
   и ответ не пустой.
Нужен вход в Claude Code (claude /login или ANTHROPIC_API_KEY). Запуск: python scripts/agents_smoke.py [имя ...]
"""
from __future__ import annotations

import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "agents" / "verification"
TASKS = {
    "coordinator": "Составь план из 3 шагов для проверки сценария оплаты и назначь каждому шагу агента проекта.",
    "architect": "Проверь, обращается ли веб-слой app/web к базе в обход user_session/system_session. Вердикт с файлами и строками.",
    "backend": "Опиши в 3 пунктах, как reconcile_payment в app/billing.py защищает от повторной обработки платежа.",
    "frontend": "Проверь templates/platform/editor.html: у всех полей ввода есть подписи, у изображений есть alt? Дай 3 замечания или подтверди.",
    "ai-engineer": "Проверь app/ai.py: передаются ли модели телефон, адрес или ИНН владельца? Ответь да/нет со ссылками на строки.",
    "prompt-engineer": "Оцени SYSTEM_PROMPT в app/ai.py: запрещает ли он выдуманные факты? Предложи 3 улучшения.",
    "ui-designer": "Выпиши цветовые токены из static/app.css и сверь с палитрой #635BFF, #111827, #F8FAFC, #64748B.",
    "ux-architect": "По templates/platform/editor.html опиши путь владельца от промта до оплаты в 5 шагах и назови одно узкое место.",
    "offer-strategist": "Проверь текст письма в build_offer (app/prospecting.py): нет ли обещаний результата? Предложи 3 правки.",
    "outbound": "Проверь в app/prospecting.py соблюдение стоп-листа и дневного лимита при отправке. Ответь со ссылками на строки.",
    "content": "Проверь posts() в app/promotion.py: используются ли только факты владельца? Приведи 2 примера из кода.",
    "seo": "Проверь templates/sites/site.html: title, description, canonical, og:image, разметка. Чего не хватает?",
    "reality-checker": "Проверь по README и коду утверждение «вход VK ID работает». Подтверждено ли оно доказательствами? Вердикт.",
    "test-automation": "Найди в tests/ тесты на повторный и поддельный webhook оплаты. Назови файлы и функции.",
    "code-reviewer": "Проверь app/web/sites_host.py на обход пути к файлам (path traversal). Вердикт со строками.",
    "appsec": "Проверь app/web/payments.py и app/billing.py: проверяется ли подпись до обработки уведомления? Вердикт.",
    "secrets": "Найди в репозитории значения, похожие на настоящие ключи, токены или пароли (кроме .env.example и тестовых значений).",
    "devops": "Опиши по deploy/install.sh, что происходит при MODE=production, если ключи в .env не заполнены.",
    "payments": "Объясни в 3 пунктах, как app/sber.py проверяет callback и почему callback сам по себе не подтверждает оплату.",
    "fpa": "По app/economics.py объясни разницу между оборотом и прибылью-оценкой и какие настройки на неё влияют.",
}


def recognized() -> list[str]:
    """Агенты, которые Claude Code загрузил при старте сессии (событие init)."""
    p = subprocess.run(["claude", "-p", "ok", "--output-format", "stream-json", "--verbose"], cwd=ROOT,
                       capture_output=True, text=True, timeout=120, stdin=subprocess.DEVNULL)
    for line in p.stdout.splitlines():
        if line.startswith("{"):
            d = json.loads(line)
            if d.get("type") == "system" and d.get("subtype") == "init":
                return list(d.get("agents") or [])
    return []


def run(name: str) -> dict:
    cmd = ["claude", "-p", TASKS[name], "--agent", name, "--permission-mode", "plan",
           "--allowedTools", "Read,Grep,Glob", "--output-format", "json"]
    p = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True, timeout=600, stdin=subprocess.DEVNULL)
    try:
        res = json.loads(p.stdout.strip().splitlines()[-1])
    except (ValueError, IndexError):
        res = {"is_error": True, "result": (p.stderr or p.stdout)[-500:]}
    ok = not res.get("is_error") and len(str(res.get("result", "")).strip()) > 40
    rec = {"agent": name, "task": TASKS[name], "ok": ok, "is_error": res.get("is_error"),
           "session_id": res.get("session_id"), "cost_usd": res.get("total_cost_usd"), "duration_ms": res.get("duration_ms"),
           "result": str(res.get("result", ""))[:4000], "checked_at": datetime.now(timezone.utc).isoformat(timespec="seconds")}
    (OUT / f"{name}.json").write_text(json.dumps(rec, ensure_ascii=False, indent=1), encoding="utf-8")
    return rec


def main() -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    names = sys.argv[1:] or list(TASKS)
    loaded = recognized()
    missing = [n for n in TASKS if n not in loaded]
    print(f"Claude Code загрузил агентов: {len(loaded)}; агентов проекта распознано: {len(TASKS) - len(missing)} из {len(TASKS)}"
          + (f"; не распознаны: {missing}" if missing else ""))
    results = [run(n) for n in names]
    passed = [r["agent"] for r in results if r["ok"]]
    summary = {"recognized": len(TASKS) - len(missing), "missing": missing, "invoked_ok": passed,
               "failed": {r["agent"]: r["result"][:200] for r in results if not r["ok"]},
               "checked_at": datetime.now(timezone.utc).isoformat(timespec="seconds")}
    (OUT / "SUMMARY.json").write_text(json.dumps(summary, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"вызвано успешно: {len(passed)} из {len(results)}")
    for a, err in summary["failed"].items():
        print(f"  {a}: {err}")
    return 0 if len(passed) == len(results) and not missing else 1


if __name__ == "__main__":
    sys.exit(main())
