#!/usr/bin/env bash
# Проверка восстановления: разворачивает дамп во временную базу, сверяет схему и данные, удаляет базу.
# Использование: ADMIN_URL=postgresql://postgres@/postgres?host=/var/run/postgresql \
#                RESTORE_OWNER=sp_owner RESTORE_URL_TEMPLATE='postgresql://sp_owner:PW@127.0.0.1/{db}' \
#                scripts/restore_check.sh backups/db-....dump
set -euo pipefail
DUMP="${1:?путь к дампу}"
: "${ADMIN_URL:?}" "${RESTORE_URL_TEMPLATE:?}"
OWNER="${RESTORE_OWNER:-sp_owner}"
DB="restore_check_$(date -u +%s)"
URL="${RESTORE_URL_TEMPLATE/\{db\}/$DB}"
cleanup() { psql "$ADMIN_URL" -qtAc "DROP DATABASE IF EXISTS $DB" >/dev/null 2>&1 || true; }
trap cleanup EXIT
psql "$ADMIN_URL" -qtAc "CREATE DATABASE $DB OWNER $OWNER"
PGOPTIONS="-c app.bypass=on" pg_restore --no-owner --exit-on-error -d "$URL" "$DUMP"
export PGOPTIONS="-c app.bypass=on"  # подсчёт строк тоже под RLS
echo "alembic=$(psql "$URL" -qtAc 'SELECT version_num FROM alembic_version')"
echo "policies=$(psql "$URL" -qtAc 'SELECT count(*) FROM pg_policies')"
for t in users sites site_versions orders payments publications leads; do
  echo "$t=$(psql "$URL" -qtAc "SELECT count(*) FROM $t")"
done
echo "restore_check=ok"
