"""Демо-данные стенда: владелец «Демо» и опубликованный многостраничный сайт «Ромашка» с заявками.

Запускается установщиком после старта служб (нужны работающие приложение и воркер). Повторный запуск ничего не дублирует.
Вход: «Тестовый вход», имя «Демо», роль «Владелец бизнеса».
"""
import os
import re
import sys
import time

import httpx

B = "http://127.0.0.1:8000"
SITES = os.environ.get("SITES_DOMAIN", "sites.localhost:8000")
PROMPT = ("Цветочный магазин «Ромашка», Санкт-Петербург. Авторские букеты, розы и пионы, цветы в коробках. "
          "Букеты от 2500 ₽. Доставка по городу за 2 часа. Оплата картой и по СБП. "
          "Работаем ежедневно с 9 до 21. Телефон +7 921 000-11-22, пишите в Telegram @romashka_spb.")
REPLIES = [("преимущ", "Свежие цветы каждый день; Фото букета перед отправкой"), ("кто", "Дарят цветы близким и коллегам"),
           ("покупател", "Дарят цветы близким и коллегам"), ("стил", "Нежный"), ("оформлен", "Нежный"),
           ("действ", "Оставить заявку"), ("цель", "Оставить заявку")]


def wait(check, seconds=120):
    for _ in range(seconds):
        if check():
            return
        time.sleep(1)
    sys.exit("демо: не дождались ответа воркера")


def main() -> None:
    c = httpx.Client(base_url=B, follow_redirects=True, timeout=30)
    r = c.post("/auth/dev", data={"name": "Демо", "role": "owner"})
    csrf = re.search(r'name="csrf" content="([^"]+)"', r.text).group(1)
    if "romashka" in c.get("/cabinet").text:
        print("демо уже создано")
        return
    h = {"X-CSRF-Token": csrf}
    sid = c.post("/cabinet/projects", data={"csrf": csrf}, follow_redirects=False).headers["location"].rsplit("/", 1)[1]
    res = c.post(f"/cabinet/sites/{sid}/answer", data={"text": PROMPT}, headers=h).json()
    for _ in range(10):
        if res.get("done"):
            break
        msg = res["message"].lower()
        res = c.post(f"/cabinet/sites/{sid}/answer", headers=h,
                     data={"text": next((a for k, a in REPLIES if k in msg), "Цветочный магазин с доставкой")}).json()
    c.post(f"/cabinet/sites/{sid}/generate", headers=h)
    wait(lambda: c.get(f"/cabinet/sites/{sid}/state").json()["generation_status"] == "done")
    c.post(f"/cabinet/sites/{sid}/hero", data={"ref": "illustration:bouquet"}, headers=h)
    c.post(f"/cabinet/sites/{sid}/plan", data={"plan_code": "site"}, headers=h)
    c.post(f"/cabinet/sites/{sid}/confirm", headers=h)
    pid = c.post(f"/cabinet/sites/{sid}/pay", data={"csrf": csrf, "accept_terms": "yes"},
                 follow_redirects=False).headers["location"].rsplit("/", 1)[1]
    c.post(f"/test-checkout/{pid}", data={"action": "pay"}, follow_redirects=False)
    wait(lambda: c.get(f"/cabinet/sites/{sid}/state").json()["status"] == "live")
    slug = re.search(r"https?://([a-z0-9-]+)\." + re.escape(SITES), c.get("/cabinet").text).group(1)
    host = {"Host": f"{slug}.{SITES}"}
    for us, n in [("vk", 12), ("telegram", 5), ("", 7)]:
        for i in range(n):
            httpx.post(B + "/_e", data={"k": "page_view", "us": us}, headers={**host, "User-Agent": f"demo{us}{i}"})
    for k in ["click_phone"] * 3 + ["click_whatsapp", "click_telegram"]:
        httpx.post(B + "/_e", data={"k": k, "us": "vk"}, headers=host)
    for name, phone, comment, us in [("Марина", "+7 921 100-20-30", "Букет пионов на день рождения", "vk"),
                                     ("Сергей", "+7 911 222-33-44", "25 роз, доставка в офис завтра", "telegram"),
                                     ("Ирина", "+7 905 300-40-50", "Свадебный букет, хочу обсудить", "vk")]:
        httpx.post(B + "/_lead", data={"name": name, "phone": phone, "comment": comment, "consent": "yes"},
                   headers={**host, "Referer": f"https://{slug}.{SITES}/?utm_source={us}&utm_medium=social"})
    c.post(f"/cabinet/promotion/{sid}/b2b", data={"csrf": csrf, "category": "office"})
    print(f"демо готово: https://{slug}.{SITES}")


if __name__ == "__main__":
    main()
