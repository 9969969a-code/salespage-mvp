-- Роли базы данных (выполняет администратор PostgreSQL один раз). Пароли замените.
-- sp_owner — владелец схемы, выполняет миграции; sp_app — приложение, без BYPASSRLS.
DO $$ BEGIN
  IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'sp_owner') THEN CREATE ROLE sp_owner LOGIN PASSWORD 'owner_dev_pw'; END IF;
  IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'sp_app') THEN CREATE ROLE sp_app LOGIN PASSWORD 'app_dev_pw' NOBYPASSRLS; END IF;
END $$;
SELECT 'CREATE DATABASE salespage OWNER sp_owner' WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = 'salespage')\gexec
