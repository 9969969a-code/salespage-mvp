"""Настройки платформы из окружения (.env). Секретов в коде нет."""
from __future__ import annotations

import os
from functools import lru_cache
from pathlib import Path

from dotenv import load_dotenv
from pydantic import BaseModel, ConfigDict

BASE_DIR = Path(__file__).resolve().parent.parent
load_dotenv(BASE_DIR / ".env")

_TRUE = {"1", "true", "yes", "on", "да"}


def _s(name: str, default: str = "") -> str:
    return os.getenv(name, default).strip()


def _b(name: str, default: bool) -> bool:
    v = os.getenv(name)
    return default if v is None or not v.strip() else v.strip().lower() in _TRUE


def _i(name: str, default: int) -> int:
    v = os.getenv(name)
    return default if v is None or not v.strip() else int(v)


class Settings(BaseModel):
    model_config = ConfigDict(frozen=True)

    APP_ENV: str = "test"  # test | staging | production
    SECRET_KEY: str = "dev-secret-change-me-dev-secret-change-me"
    DATABASE_URL: str = "postgresql+psycopg://sp_app:app_dev_pw@127.0.0.1:5432/salespage"
    MIGRATIONS_DATABASE_URL: str = "postgresql+psycopg://sp_owner:owner_dev_pw@127.0.0.1:5432/salespage"
    PUBLIC_BASE_URL: str = "http://127.0.0.1:8000"
    SITES_DOMAIN: str = "sites.localhost:8000"  # хост клиентских сайтов: <slug>.<SITES_DOMAIN>
    SITES_SCHEME: str = "http"
    SITE_CHECK_VIA_LOOPBACK: bool = True  # проверка доступности через 127.0.0.1 с заголовком Host
    LOCAL_PORT: int = 8000
    STORAGE_DIR: str = str(BASE_DIR / "storage")

    DEV_LOGIN_ENABLED: bool = True  # тестовый вход без VK; в production запрещён
    VK_CLIENT_ID: str = ""
    VK_REDIRECT_URI: str = ""
    ADMIN_VK_IDS: str = ""

    AI_PROVIDER: str = "fake"  # fake | anthropic | openai_compat
    AI_BASE_URL: str = ""
    AI_API_KEY: str = ""
    AI_MODEL: str = ""
    AI_LIMIT_GENERATIONS_PER_DAY: int = 5
    AI_LIMIT_EDITS_PER_DAY: int = 40
    AI_LIMIT_TOTAL_CALLS_PER_DAY: int = 500

    PAYMENT_PROVIDER: str = "fake"  # fake | (реальный адаптер не утверждён)
    PAYMENT_WEBHOOK_SECRET: str = "fake-webhook-secret"
    HOSTING_MONTHS: int = 12  # ТРЕБУЕТ ВАШЕГО УТВЕРЖДЕНИЯ
    RENEWAL_PRICE_RUB: int = 999  # ТРЕБУЕТ ВАШЕГО УТВЕРЖДЕНИЯ

    TELEGRAM_MODE: str = "fake"  # fake | live
    TELEGRAM_BOT_TOKEN: str = ""
    TELEGRAM_BOT_USERNAME: str = "your_bot"
    TELEGRAM_WEBHOOK_SECRET: str = "dev-telegram-secret"
    OPERATOR_TELEGRAM_CHAT_ID: str = ""

    LEAD_RATE_LIMIT_PER_MIN: int = 5
    LOGIN_RATE_LIMIT_PER_MIN: int = 10
    EVENTS_RETENTION_DAYS: int = 180
    OPERATOR_NAME: str = ""
    OPERATOR_INN: str = ""
    OPERATOR_EMAIL: str = ""

    @property
    def is_production(self) -> bool:
        return self.APP_ENV == "production"

    @property
    def storage(self) -> Path:
        return Path(self.STORAGE_DIR)

    @property
    def sites_root(self) -> Path:
        return self.storage / "sites"

    @property
    def uploads_root(self) -> Path:
        return self.storage / "uploads"

    @property
    def sites_host_suffix(self) -> str:
        return "." + self.SITES_DOMAIN.split(":")[0]

    @property
    def admin_vk_ids(self) -> set[str]:
        return {x.strip() for x in self.ADMIN_VK_IDS.split(",") if x.strip()}

    def site_url(self, slug: str) -> str:
        return f"{self.SITES_SCHEME}://{slug}.{self.SITES_DOMAIN}"

    def production_problems(self) -> list[str]:
        """Что мешает запуску в production. Тестовые адаптеры там запрещены."""
        if not self.is_production:
            return []
        p = []
        if len(self.SECRET_KEY) < 32 or "dev-secret" in self.SECRET_KEY:
            p.append("SECRET_KEY")
        if self.DEV_LOGIN_ENABLED:
            p.append("DEV_LOGIN_ENABLED должен быть False")
        if not (self.VK_CLIENT_ID and self.VK_REDIRECT_URI):
            p.append("VK_CLIENT_ID / VK_REDIRECT_URI")
        if self.AI_PROVIDER == "fake":
            p.append("AI_PROVIDER не может быть fake")
        elif not (self.AI_API_KEY and self.AI_MODEL):
            p.append("AI_API_KEY и AI_MODEL обязательны для ИИ-провайдера")
        if self.PAYMENT_PROVIDER == "sber":
            from app.sber import config_problems
            p.extend(f"Сбербанк: {x}" for x in config_problems())
        if self.PAYMENT_PROVIDER == "fake":
            p.append("PAYMENT_PROVIDER не может быть fake")
        if self.TELEGRAM_MODE != "live" or not self.TELEGRAM_BOT_TOKEN:
            p.append("TELEGRAM_MODE=live и TELEGRAM_BOT_TOKEN")
        import os
        if os.getenv("EMAIL_MODE", "mock") not in ("smtp", "off"):
            p.append("EMAIL_MODE: в production только smtp или off (тестовая почта запрещена)")
        if os.getenv("PROSPECT_SOURCE", "mock") not in ("2gis", "off"):
            p.append("PROSPECT_SOURCE: в production только 2gis или off (тестовые компании запрещены)")
        if not self.PUBLIC_BASE_URL.startswith("https://") or self.SITES_SCHEME != "https":
            p.append("HTTPS для обоих доменов")
        return p


def load_settings() -> Settings:
    d = Settings()
    vals = {}
    for name, field in Settings.model_fields.items():
        default = getattr(d, name)
        if isinstance(default, bool):
            vals[name] = _b(name, default)
        elif isinstance(default, int):
            vals[name] = _i(name, default)
        else:
            vals[name] = _s(name, default)
    return Settings(**vals)


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return load_settings()
