"""Адаптер интернет-эквайринга Сбербанка (оплата картой, SberPay и СБП на платёжной форме банка).

Схема: register.do создаёт заказ и даёт formUrl (форма банка, где покупатель выбирает карту, SberPay или СБП) →
банк присылает callback (GET: mdOrder, orderNumber, operation, status, checksum) → мы НЕ верим callback,
а запрашиваем getOrderStatusExtended.do и сверяем статус и сумму.

Способы оплаты на форме (SberPay, СБП) включает банк по договору, кодом не настраиваются.
НЕ ПРОВЕРЕН на реальном контуре: нужен тестовый договор (логин «...-api», пароль) и токен callback.
Формат запросов (form-urlencoded) и адреса сверить с документацией банка для вашего договора.
"""
from __future__ import annotations

import hashlib
import hmac
import os
import uuid
from urllib.parse import parse_qsl

import httpx

from app.config import get_settings

TEST_URL = "https://ecomtest.sberbank.ru/ecomm/gw/partner/api/v1/"
STATUS_MAP = {2: "succeeded", 3: "canceled", 4: "canceled", 6: "canceled"}  # 0,1,5 — ещё не оплачен


def _env(name: str, default: str = "") -> str:
    return os.getenv(name, default).strip()


def config_problems() -> list[str]:
    return [f"{k} не задан" for k in ("SBER_USERNAME", "SBER_PASSWORD", "SBER_CALLBACK_TOKEN") if not _env(k)]


def checksum(params: dict[str, str], token: str) -> str:
    """Контрольная сумма callback: пары «имя;значение;» по алфавиту без checksum и sign_alias, HMAC-SHA256, верхний регистр."""
    data = "".join(f"{k};{v};" for k, v in sorted(params.items()) if k not in ("checksum", "sign_alias"))
    return hmac.new(token.encode(), data.encode(), hashlib.sha256).hexdigest().upper()


class SberProvider:
    name = "sber"

    def __init__(self, http_post=None) -> None:
        self.base = _env("SBER_API_URL", TEST_URL).rstrip("/") + "/"
        self.is_test = "ecomtest" in self.base
        self._post = http_post or httpx.post

    def _call(self, method: str, params: dict) -> dict:
        from app.billing import BillingError
        data = {"userName": _env("SBER_USERNAME"), "password": _env("SBER_PASSWORD"), **params}
        try:
            r = self._post(self.base + method, data=data, timeout=30)
            r.raise_for_status()
            res = r.json()
        except (httpx.HTTPError, ValueError) as exc:
            raise BillingError(f"Сбербанк недоступен: {exc.__class__.__name__}") from exc
        if str(res.get("errorCode", "0")) not in ("0", ""):
            raise BillingError(f"Сбербанк: ошибка {res.get('errorCode')}: {res.get('errorMessage', '')}"[:200])
        return res

    def create_payment(self, order) -> tuple[str, str]:
        st = get_settings()
        back = f"{st.PUBLIC_BASE_URL}/cabinet/orders/{order.id}"
        res = self._call("register.do", {"orderNumber": order.id.hex, "amount": order.amount_kop, "currency": "643",
                                         "returnUrl": back, "failUrl": back, "language": "ru",
                                         "description": "Публикация сайта"[:99], "sessionTimeoutSecs": 1200})
        if not res.get("orderId") or not res.get("formUrl"):
            from app.billing import BillingError
            raise BillingError("Сбербанк не вернул orderId или formUrl")
        return str(res["orderId"]), str(res["formUrl"])

    def get_payment(self, provider_payment_id: str):
        from app.billing import ProviderPayment
        res = self._call("getOrderStatusExtended.do", {"orderId": provider_payment_id})
        status = STATUS_MAP.get(int(res.get("orderStatus", 0)), "pending")
        number = str(res.get("orderNumber", ""))
        try:
            order_ref = str(uuid.UUID(hex=number))
        except ValueError:
            order_ref = number
        currency = "RUB" if str(res.get("currency", "643")) == "643" else str(res.get("currency"))
        return ProviderPayment(status=status, amount_kop=int(res.get("amount", 0)), currency=currency, order_ref=order_ref)

    def verify_webhook(self, headers: dict, body: bytes) -> tuple[bool, str, str]:
        params = dict(parse_qsl(body.decode(errors="replace"), keep_blank_values=True))
        md, op, status = params.get("mdOrder", ""), params.get("operation", ""), params.get("status", "")
        if not md or not op:
            return False, "", ""
        token = _env("SBER_CALLBACK_TOKEN")
        if not token:  # без токена callback нельзя проверить; в production это запрещено проверкой конфигурации
            return False, "", ""
        if not hmac.compare_digest(checksum(params, token), params.get("checksum", "").upper()):
            return False, "", ""
        return True, f"{md}:{op}:{status}", md
