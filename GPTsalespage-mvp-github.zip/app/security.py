"""Сессии на сервере, CSRF, текущий пользователь, журнал действий."""
from __future__ import annotations

import hmac
import uuid
from dataclasses import dataclass
from datetime import timedelta
from typing import Any, Optional

from fastapi import Request
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.config import get_settings
from app.db import system_session, utcnow
from app.models import AuditLog, User, UserSession
from app.utils import sha256, token

SESSION_COOKIE = "sp_session"
SESSION_DAYS = 14


class LoginRequired(Exception):
    pass


class Forbidden(Exception):
    pass


class CsrfFailed(Exception):
    pass


@dataclass(frozen=True)
class Actor:
    user_id: uuid.UUID
    role: str
    display_name: str
    csrf: str
    session_hash: str

    @property
    def is_admin(self) -> bool:
        return self.role == "admin"


def _hash(raw: str) -> str:
    return sha256(get_settings().SECRET_KEY + raw)


def create_session(user_id: uuid.UUID) -> str:
    raw = token()
    with system_session() as s:
        s.add(UserSession(user_id=user_id, token_hash=_hash(raw), csrf_token=token(),
                          expires_at=utcnow() + timedelta(days=SESSION_DAYS)))
    return raw


def set_session_cookie(response: Any, raw: str) -> None:
    response.set_cookie(SESSION_COOKIE, raw, max_age=SESSION_DAYS * 86400, httponly=True, samesite="lax",
                        secure=get_settings().PUBLIC_BASE_URL.startswith("https://"), path="/")


def load_actor(request: Request) -> Optional[Actor]:
    raw = request.cookies.get(SESSION_COOKIE)
    if not raw or len(raw) > 200:
        return None
    h = _hash(raw)
    with system_session() as s:
        row = s.execute(select(UserSession, User).join(User, User.id == UserSession.user_id)
                        .where(UserSession.token_hash == h)).first()
        if not row:
            return None
        sess, user = row
        if sess.revoked_at or sess.expires_at <= utcnow() or user.status != "active":
            return None
        return Actor(user.id, user.role, user.display_name, sess.csrf_token, h)


def revoke(actor: Actor) -> None:
    with system_session() as s:
        sess = s.scalar(select(UserSession).where(UserSession.token_hash == actor.session_hash))
        if sess:
            sess.revoked_at = utcnow()


def require_user(request: Request) -> Actor:
    actor = load_actor(request)
    if actor is None:
        raise LoginRequired()
    return actor


def require_admin(request: Request) -> Actor:
    actor = require_user(request)
    if not actor.is_admin:
        raise Forbidden()
    return actor


def check_csrf(actor: Actor, supplied: Optional[str]) -> None:
    if not supplied or not hmac.compare_digest(supplied, actor.csrf):
        raise CsrfFailed()


def audit(s: Session, action: str, *, actor_kind: str, actor_id: Optional[uuid.UUID] = None,
          owner_id: Optional[uuid.UUID] = None, entity_type: str = "", entity_id: Any = "",
          details: Optional[dict] = None) -> None:
    s.add(AuditLog(action=action, actor_kind=actor_kind, actor_user_id=actor_id, owner_id=owner_id,
                   entity_type=entity_type, entity_id=str(entity_id), details=details or {}))
