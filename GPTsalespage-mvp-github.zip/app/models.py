"""Модель данных. Каждая клиентская таблица несёт owner_id; дочерние таблицы ссылаются
на родителя составным ключом (parent_id, owner_id), поэтому база не даёт привязать объект
к чужому родителю. Политики RLS создаются миграцией."""
from __future__ import annotations

import uuid
from datetime import datetime
from typing import Any, Optional

from sqlalchemy import (Boolean, DateTime, ForeignKey, ForeignKeyConstraint, Integer, String, Text,
                        UniqueConstraint)
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.db import Base, new_id, utcnow

TS = DateTime(timezone=True)


def pk() -> Mapped[uuid.UUID]:
    return mapped_column(UUID(as_uuid=True), primary_key=True, default=new_id)


def owner() -> Mapped[uuid.UUID]:
    return mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)


def created() -> Mapped[datetime]:
    return mapped_column(TS, default=utcnow, nullable=False)


# ------------------------------------------------------------------ доступ
class User(Base):
    __tablename__ = "users"
    id: Mapped[uuid.UUID] = pk()
    display_name: Mapped[str] = mapped_column(String(120))
    role: Mapped[str] = mapped_column(String(16), default="owner")  # owner | admin
    status: Mapped[str] = mapped_column(String(24), default="active")  # active | blocked | deletion_requested
    signup_source: Mapped[dict] = mapped_column(JSONB, default=dict)
    created_at: Mapped[datetime] = created()


class AuthIdentity(Base):
    __tablename__ = "auth_identities"
    __table_args__ = (UniqueConstraint("provider", "provider_user_id"),)
    id: Mapped[uuid.UUID] = pk()
    user_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"))
    provider: Mapped[str] = mapped_column(String(16))  # vk | dev
    provider_user_id: Mapped[str] = mapped_column(String(64))
    created_at: Mapped[datetime] = created()


class UserSession(Base):
    __tablename__ = "sessions"
    id: Mapped[uuid.UUID] = pk()
    user_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), index=True)
    token_hash: Mapped[str] = mapped_column(String(64), unique=True)
    csrf_token: Mapped[str] = mapped_column(String(64))
    created_at: Mapped[datetime] = created()
    expires_at: Mapped[datetime] = mapped_column(TS)
    revoked_at: Mapped[Optional[datetime]] = mapped_column(TS, nullable=True)


class OAuthState(Base):
    __tablename__ = "oauth_states"
    state: Mapped[str] = mapped_column(String(64), primary_key=True)
    code_verifier: Mapped[str] = mapped_column(String(128))
    created_at: Mapped[datetime] = created()


class UserConsent(Base):
    __tablename__ = "user_consents"
    id: Mapped[uuid.UUID] = pk()
    owner_id: Mapped[uuid.UUID] = owner()
    doc_kind: Mapped[str] = mapped_column(String(32))
    doc_version: Mapped[str] = mapped_column(String(32))
    accepted_at: Mapped[datetime] = created()


# ------------------------------------------------------------------ бизнес и диалог
class Business(Base):
    __tablename__ = "businesses"
    __table_args__ = (UniqueConstraint("id", "owner_id"),)
    id: Mapped[uuid.UUID] = pk()
    owner_id: Mapped[uuid.UUID] = owner()
    name: Mapped[str] = mapped_column(String(120), default="")
    niche: Mapped[str] = mapped_column(String(32), default="flowers")
    created_at: Mapped[datetime] = created()


class BusinessFact(Base):
    __tablename__ = "business_facts"
    __table_args__ = (
        UniqueConstraint("business_id", "key"),
        ForeignKeyConstraint(["business_id", "owner_id"], ["businesses.id", "businesses.owner_id"], ondelete="CASCADE"),
    )
    id: Mapped[uuid.UUID] = pk()
    owner_id: Mapped[uuid.UUID] = owner()
    business_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True))
    key: Mapped[str] = mapped_column(String(48))
    value: Mapped[str] = mapped_column(Text)
    source: Mapped[str] = mapped_column(String(24), default="user_message")
    confirmed_at: Mapped[Optional[datetime]] = mapped_column(TS, nullable=True)
    created_at: Mapped[datetime] = created()


class Project(Base):
    __tablename__ = "projects"
    __table_args__ = (
        UniqueConstraint("id", "owner_id"),
        ForeignKeyConstraint(["business_id", "owner_id"], ["businesses.id", "businesses.owner_id"], ondelete="CASCADE"),
    )
    id: Mapped[uuid.UUID] = pk()
    owner_id: Mapped[uuid.UUID] = owner()
    business_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True))
    title: Mapped[str] = mapped_column(String(120))
    status: Mapped[str] = mapped_column(String(16), default="active")
    created_at: Mapped[datetime] = created()


class Conversation(Base):
    __tablename__ = "conversations"
    __table_args__ = (
        UniqueConstraint("id", "owner_id"),
        ForeignKeyConstraint(["project_id", "owner_id"], ["projects.id", "projects.owner_id"], ondelete="CASCADE"),
    )
    id: Mapped[uuid.UUID] = pk()
    owner_id: Mapped[uuid.UUID] = owner()
    project_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True))
    step: Mapped[int] = mapped_column(Integer, default=0)
    status: Mapped[str] = mapped_column(String(16), default="open")  # open | completed
    prompt_version: Mapped[str] = mapped_column(String(16), default="v1")
    created_at: Mapped[datetime] = created()


class Message(Base):
    __tablename__ = "messages"
    __table_args__ = (
        ForeignKeyConstraint(["conversation_id", "owner_id"], ["conversations.id", "conversations.owner_id"], ondelete="CASCADE"),
    )
    id: Mapped[uuid.UUID] = pk()
    owner_id: Mapped[uuid.UUID] = owner()
    conversation_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), index=True)
    role: Mapped[str] = mapped_column(String(16))  # user | assistant
    content: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime] = created()


# ------------------------------------------------------------------ сайт
class Site(Base):
    __tablename__ = "sites"
    __table_args__ = (
        UniqueConstraint("id", "owner_id"),
        ForeignKeyConstraint(["project_id", "owner_id"], ["projects.id", "projects.owner_id"], ondelete="CASCADE"),
    )
    id: Mapped[uuid.UUID] = pk()
    owner_id: Mapped[uuid.UUID] = owner()
    project_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True))
    slug: Mapped[str] = mapped_column(String(40), unique=True)
    status: Mapped[str] = mapped_column(String(16), default="draft")
    generation_status: Mapped[str] = mapped_column(String(16), default="idle")  # idle|queued|running|done|failed
    generation_error: Mapped[str] = mapped_column(Text, default="")
    current_version_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), nullable=True)
    published_version_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), nullable=True)
    hosting_paid_until: Mapped[Optional[datetime]] = mapped_column(TS, nullable=True)
    plan_code: Mapped[str] = mapped_column(String(32), ForeignKey("plans.code"), default="page")  # page | site
    service_plan: Mapped[Optional[str]] = mapped_column(String(32), ForeignKey("plans.code"), nullable=True)  # месячная подписка
    service_paid_until: Mapped[Optional[datetime]] = mapped_column(TS, nullable=True)
    service_reminded_for: Mapped[Optional[datetime]] = mapped_column(TS, nullable=True)
    created_at: Mapped[datetime] = created()


class SiteVersion(Base):
    __tablename__ = "site_versions"
    __table_args__ = (
        UniqueConstraint("site_id", "number"),
        UniqueConstraint("id", "owner_id"),
        ForeignKeyConstraint(["site_id", "owner_id"], ["sites.id", "sites.owner_id"], ondelete="CASCADE"),
    )
    id: Mapped[uuid.UUID] = pk()
    owner_id: Mapped[uuid.UUID] = owner()
    site_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), index=True)
    number: Mapped[int] = mapped_column(Integer)
    content: Mapped[dict] = mapped_column(JSONB)
    source: Mapped[str] = mapped_column(String(24))  # generation | edit | rollback | fallback
    note: Mapped[str] = mapped_column(Text, default="")
    validation: Mapped[dict] = mapped_column(JSONB, default=dict)
    owner_confirmed_at: Mapped[Optional[datetime]] = mapped_column(TS, nullable=True)
    created_at: Mapped[datetime] = created()


class Asset(Base):
    __tablename__ = "assets"
    __table_args__ = (
        ForeignKeyConstraint(["site_id", "owner_id"], ["sites.id", "sites.owner_id"], ondelete="CASCADE"),
    )
    id: Mapped[uuid.UUID] = pk()
    owner_id: Mapped[uuid.UUID] = owner()
    site_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), index=True)
    storage_path: Mapped[str] = mapped_column(String(255))
    width: Mapped[int] = mapped_column(Integer)
    height: Mapped[int] = mapped_column(Integer)
    bytes: Mapped[int] = mapped_column(Integer)
    sha256: Mapped[str] = mapped_column(String(64))
    created_at: Mapped[datetime] = created()


# ------------------------------------------------------------------ деньги
class Plan(Base):
    __tablename__ = "plans"
    code: Mapped[str] = mapped_column(String(32), primary_key=True)
    name: Mapped[str] = mapped_column(String(64))
    price_kop: Mapped[int] = mapped_column(Integer)
    period: Mapped[str] = mapped_column(String(16))  # one_time | monthly
    purchasable: Mapped[bool] = mapped_column(Boolean, default=False)  # False = только заявка на подключение
    hosting_months: Mapped[int] = mapped_column(Integer, default=0)


class Order(Base):
    __tablename__ = "orders"
    __table_args__ = (
        UniqueConstraint("id", "owner_id"),
        ForeignKeyConstraint(["site_id", "owner_id"], ["sites.id", "sites.owner_id"], ondelete="CASCADE"),
    )
    id: Mapped[uuid.UUID] = pk()
    owner_id: Mapped[uuid.UUID] = owner()
    site_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), index=True)
    plan_code: Mapped[str] = mapped_column(String(32), ForeignKey("plans.code"))
    version_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True))
    kind: Mapped[str] = mapped_column(String(16), default="initial")  # initial | renewal
    amount_kop: Mapped[int] = mapped_column(Integer)
    currency: Mapped[str] = mapped_column(String(3), default="RUB")
    status: Mapped[str] = mapped_column(String(16), default="created")  # created|awaiting_payment|paid|cancelled|refunded
    idempotency_key: Mapped[str] = mapped_column(String(64), unique=True)
    created_at: Mapped[datetime] = created()
    paid_at: Mapped[Optional[datetime]] = mapped_column(TS, nullable=True)


class Payment(Base):
    __tablename__ = "payments"
    __table_args__ = (
        UniqueConstraint("provider", "provider_payment_id"),
        ForeignKeyConstraint(["order_id", "owner_id"], ["orders.id", "orders.owner_id"], ondelete="CASCADE"),
    )
    id: Mapped[uuid.UUID] = pk()
    owner_id: Mapped[uuid.UUID] = owner()
    order_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), index=True)
    provider: Mapped[str] = mapped_column(String(24))
    provider_payment_id: Mapped[str] = mapped_column(String(64))
    status: Mapped[str] = mapped_column(String(16), default="pending")  # pending|succeeded|failed|refunded
    amount_kop: Mapped[int] = mapped_column(Integer)
    currency: Mapped[str] = mapped_column(String(3))
    confirmation_url: Mapped[str] = mapped_column(Text, default="")
    is_test: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = created()
    updated_at: Mapped[datetime] = created()


class PaymentEvent(Base):
    __tablename__ = "payment_events"
    __table_args__ = (UniqueConstraint("provider", "event_id"),)
    id: Mapped[uuid.UUID] = pk()
    provider: Mapped[str] = mapped_column(String(24))
    event_id: Mapped[str] = mapped_column(String(128))
    payload: Mapped[dict] = mapped_column(JSONB)
    signature_ok: Mapped[bool] = mapped_column(Boolean)
    result: Mapped[str] = mapped_column(String(64), default="")
    received_at: Mapped[datetime] = created()


class FakeProviderPayment(Base):
    """Состояние тестового платёжного провайдера (имитатор). Только для APP_ENV != production."""
    __tablename__ = "fake_provider_payments"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    order_ref: Mapped[str] = mapped_column(String(64))
    amount_kop: Mapped[int] = mapped_column(Integer)
    currency: Mapped[str] = mapped_column(String(3))
    status: Mapped[str] = mapped_column(String(16), default="pending")
    created_at: Mapped[datetime] = created()


class Publication(Base):
    __tablename__ = "publications"
    __table_args__ = (
        ForeignKeyConstraint(["site_id", "owner_id"], ["sites.id", "sites.owner_id"], ondelete="CASCADE"),
    )
    id: Mapped[uuid.UUID] = pk()
    owner_id: Mapped[uuid.UUID] = owner()
    site_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), index=True)
    version_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True))
    order_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), nullable=True)
    status: Mapped[str] = mapped_column(String(16), default="queued")  # queued|building|live|failed|superseded
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    error: Mapped[str] = mapped_column(Text, default="")
    release_dir: Mapped[str] = mapped_column(String(255), default="")
    verified_at: Mapped[Optional[datetime]] = mapped_column(TS, nullable=True)
    created_at: Mapped[datetime] = created()
    finished_at: Mapped[Optional[datetime]] = mapped_column(TS, nullable=True)


# ------------------------------------------------------------------ заявки, события, уведомления
class Lead(Base):
    __tablename__ = "leads"
    __table_args__ = (
        ForeignKeyConstraint(["site_id", "owner_id"], ["sites.id", "sites.owner_id"], ondelete="CASCADE"),
    )
    id: Mapped[uuid.UUID] = pk()
    owner_id: Mapped[uuid.UUID] = owner()
    site_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), index=True)
    name: Mapped[str] = mapped_column(String(80))
    phone: Mapped[str] = mapped_column(String(20))
    comment: Mapped[str] = mapped_column(Text, default="")
    wanted_date: Mapped[str] = mapped_column(String(32), default="")
    consent_version: Mapped[str] = mapped_column(String(32))
    status: Mapped[str] = mapped_column(String(16), default="new")  # new | read | processed
    created_at: Mapped[datetime] = created()


class Event(Base):
    """Аналитика без cookie: visitor_hash = хеш(IP+UA+соль дня), сырой IP не хранится."""
    __tablename__ = "events"
    id: Mapped[uuid.UUID] = pk()
    owner_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=True, index=True)
    site_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), nullable=True, index=True)
    kind: Mapped[str] = mapped_column(String(32), index=True)
    source: Mapped[str] = mapped_column(String(32), default="direct")
    utm_source: Mapped[str] = mapped_column(String(64), default="")
    utm_medium: Mapped[str] = mapped_column(String(64), default="")
    utm_campaign: Mapped[str] = mapped_column(String(64), default="")
    referrer_host: Mapped[str] = mapped_column(String(128), default="")
    visitor_hash: Mapped[str] = mapped_column(String(32), default="")
    created_at: Mapped[datetime] = mapped_column(TS, default=utcnow, index=True)


class NotificationChannel(Base):
    __tablename__ = "notification_channels"
    id: Mapped[uuid.UUID] = pk()
    owner_id: Mapped[uuid.UUID] = owner()
    kind: Mapped[str] = mapped_column(String(16))  # telegram
    address: Mapped[str] = mapped_column(String(64))
    status: Mapped[str] = mapped_column(String(16), default="verified")  # verified | unreachable | removed
    verified_at: Mapped[datetime] = created()


class TelegramLinkToken(Base):
    __tablename__ = "telegram_link_tokens"
    id: Mapped[uuid.UUID] = pk()
    owner_id: Mapped[uuid.UUID] = owner()
    token_hash: Mapped[str] = mapped_column(String(64), unique=True)
    expires_at: Mapped[datetime] = mapped_column(TS)
    used_at: Mapped[Optional[datetime]] = mapped_column(TS, nullable=True)


class Notification(Base):
    __tablename__ = "notifications"
    id: Mapped[uuid.UUID] = pk()
    owner_id: Mapped[uuid.UUID] = owner()
    kind: Mapped[str] = mapped_column(String(32))  # lead | payment | published | publish_failed | status
    channel_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), nullable=True)
    payload: Mapped[dict] = mapped_column(JSONB)
    status: Mapped[str] = mapped_column(String(16), default="pending")  # pending|sent|dead|skipped
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    last_error: Mapped[str] = mapped_column(Text, default="")
    dedupe_key: Mapped[str] = mapped_column(String(128), unique=True)
    created_at: Mapped[datetime] = created()
    sent_at: Mapped[Optional[datetime]] = mapped_column(TS, nullable=True)


class FakeTelegramMessage(Base):
    """Сообщения тестового Telegram-адаптера. Реальной отправки нет."""
    __tablename__ = "fake_telegram_messages"
    id: Mapped[uuid.UUID] = pk()
    chat_id: Mapped[str] = mapped_column(String(64))
    text: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime] = created()


# ------------------------------------------------------------------ эксплуатация
class Job(Base):
    __tablename__ = "jobs"
    id: Mapped[uuid.UUID] = pk()
    kind: Mapped[str] = mapped_column(String(48), index=True)
    payload: Mapped[dict] = mapped_column(JSONB, default=dict)
    status: Mapped[str] = mapped_column(String(16), default="queued", index=True)  # queued|running|done|dead
    run_at: Mapped[datetime] = mapped_column(TS, default=utcnow, index=True)
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    max_attempts: Mapped[int] = mapped_column(Integer, default=6)
    locked_until: Mapped[Optional[datetime]] = mapped_column(TS, nullable=True)
    last_error: Mapped[str] = mapped_column(Text, default="")
    dedupe_key: Mapped[Optional[str]] = mapped_column(String(128), unique=True, nullable=True)
    created_at: Mapped[datetime] = created()
    finished_at: Mapped[Optional[datetime]] = mapped_column(TS, nullable=True)


class AuditLog(Base):
    __tablename__ = "audit_log"
    id: Mapped[uuid.UUID] = pk()
    owner_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True)
    actor_kind: Mapped[str] = mapped_column(String(16))  # user | admin | system | webhook
    actor_user_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), nullable=True)
    action: Mapped[str] = mapped_column(String(64))
    entity_type: Mapped[str] = mapped_column(String(32), default="")
    entity_id: Mapped[str] = mapped_column(String(64), default="")
    details: Mapped[dict] = mapped_column(JSONB, default=dict)
    created_at: Mapped[datetime] = created()


class AIUsage(Base):
    __tablename__ = "ai_usage"
    id: Mapped[uuid.UUID] = pk()
    owner_id: Mapped[uuid.UUID] = owner()
    kind: Mapped[str] = mapped_column(String(16))  # generate | edit
    provider: Mapped[str] = mapped_column(String(32))
    status: Mapped[str] = mapped_column(String(16))  # ok | error | blocked
    units: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(TS, default=utcnow, index=True)


class SystemFlag(Base):
    __tablename__ = "system_flags"
    key: Mapped[str] = mapped_column(String(32), primary_key=True)
    value: Mapped[str] = mapped_column(String(64))


class SupportTicket(Base):
    __tablename__ = "support_tickets"
    id: Mapped[uuid.UUID] = pk()
    owner_id: Mapped[uuid.UUID] = owner()
    subject: Mapped[str] = mapped_column(String(160))
    body: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(16), default="new")  # new | in_progress | closed
    admin_reply: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = created()


class AbuseReport(Base):
    __tablename__ = "abuse_reports"
    id: Mapped[uuid.UUID] = pk()
    site_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), index=True)
    reporter_contact: Mapped[str] = mapped_column(String(120), default="")
    reason: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(16), default="new")  # new | actioned | rejected
    admin_note: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = created()


class UpgradeRequest(Base):
    __tablename__ = "upgrade_requests"
    id: Mapped[uuid.UUID] = pk()
    owner_id: Mapped[uuid.UUID] = owner()
    plan_code: Mapped[str] = mapped_column(String(32))
    contact: Mapped[str] = mapped_column(String(120))
    comment: Mapped[str] = mapped_column(Text, default="")
    status: Mapped[str] = mapped_column(String(16), default="new")
    created_at: Mapped[datetime] = created()


OWNER_TABLES = [
    "user_consents", "businesses", "business_facts", "projects", "conversations", "messages", "sites",
    "site_versions", "assets", "orders", "payments", "publications", "leads", "notification_channels",
    "telegram_link_tokens", "notifications", "ai_usage", "support_tickets", "upgrade_requests",
]
# events и audit_log: owner_id может быть NULL (события платформы) — видны только системе
NULLABLE_OWNER_TABLES = ["events", "audit_log"]


def as_dict(obj: Any) -> dict:
    return {c.name: getattr(obj, c.name) for c in obj.__table__.columns}


# ------------------------------------------------------------------ поиск клиентов для самой платформы
class Prospect(Base):
    """Потенциальный клиент платформы (компания). Данные платформы, не владельцев сайтов."""
    __tablename__ = "prospects"
    __table_args__ = (UniqueConstraint("source", "external_id", name="uq_prospect_source_ext"),)
    id: Mapped[uuid.UUID] = pk()
    source: Mapped[str] = mapped_column(String(16))          # mock | 2gis
    external_id: Mapped[str] = mapped_column(String(64))
    name: Mapped[str] = mapped_column(String(160))
    niche: Mapped[str] = mapped_column(String(32), default="")
    city: Mapped[str] = mapped_column(String(80), default="")
    address: Mapped[str] = mapped_column(String(200), default="")
    phone: Mapped[str] = mapped_column(String(20), default="")
    email: Mapped[str] = mapped_column(String(160), default="")
    website: Mapped[str] = mapped_column(String(300), default="")
    site_status: Mapped[str] = mapped_column(String(16), default="unknown")  # none|no_https|no_mobile|unreachable|ok
    score: Mapped[int] = mapped_column(Integer, default=0)
    status: Mapped[str] = mapped_column(String(20), default="new")
    ref_token: Mapped[str] = mapped_column(String(32), unique=True)
    created_at: Mapped[datetime] = created()
    updated_at: Mapped[datetime] = created()


class OutreachMessage(Base):
    """Персональное предложение. Отправляется только после одобрения оператором."""
    __tablename__ = "outreach_messages"
    id: Mapped[uuid.UUID] = pk()
    prospect_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("prospects.id", ondelete="CASCADE"), index=True)
    channel: Mapped[str] = mapped_column(String(16), default="email")
    to_address: Mapped[str] = mapped_column(String(160))
    subject: Mapped[str] = mapped_column(String(200))
    body: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(20), default="pending_review")  # pending_review|approved|sent|rejected|failed|blocked
    unsubscribe_token: Mapped[str] = mapped_column(String(48), unique=True)
    reviewed_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), nullable=True)
    reviewed_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    sent_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    error: Mapped[str] = mapped_column(Text, default="")
    is_test: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = created()


class SuppressionEntry(Base):
    """Адреса и телефоны, которым писать нельзя (отказ, жалоба, ручной запрет)."""
    __tablename__ = "suppression_list"
    value: Mapped[str] = mapped_column(String(160), primary_key=True)  # email в нижнем регистре или телефон 7XXXXXXXXXX
    reason: Mapped[str] = mapped_column(String(64))
    created_at: Mapped[datetime] = created()


class FakeEmail(Base):
    """Письма тестового почтового адаптера [MOCK]. Реальной отправки нет."""
    __tablename__ = "fake_emails"
    id: Mapped[uuid.UUID] = pk()
    to_address: Mapped[str] = mapped_column(String(160))
    subject: Mapped[str] = mapped_column(String(200))
    body: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime] = created()


# ------------------------------------------------------------------ продвижение сайтов клиентов
class ClientProspect(Base):
    """Корпоративный клиент для магазина владельца (офис, ресторан и т. п.). Данные владельца, под RLS."""
    __tablename__ = "client_prospects"
    __table_args__ = (UniqueConstraint("site_id", "source", "external_id", name="uq_client_prospect"),)
    id: Mapped[uuid.UUID] = pk()
    owner_id: Mapped[uuid.UUID] = owner()
    site_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("sites.id", ondelete="CASCADE"))
    source: Mapped[str] = mapped_column(String(16))
    external_id: Mapped[str] = mapped_column(String(64))
    name: Mapped[str] = mapped_column(String(160))
    category: Mapped[str] = mapped_column(String(32))
    city: Mapped[str] = mapped_column(String(80), default="")
    email: Mapped[str] = mapped_column(String(160), default="")
    phone: Mapped[str] = mapped_column(String(20), default="")
    status: Mapped[str] = mapped_column(String(20), default="new")
    created_at: Mapped[datetime] = created()


class ClientOutreach(Base):
    """Письмо от имени магазина владельца. Уходит только после одобрения владельцем."""
    __tablename__ = "client_outreach"
    id: Mapped[uuid.UUID] = pk()
    owner_id: Mapped[uuid.UUID] = owner()
    site_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("sites.id", ondelete="CASCADE"))
    prospect_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("client_prospects.id", ondelete="CASCADE"))
    to_address: Mapped[str] = mapped_column(String(160))
    subject: Mapped[str] = mapped_column(String(200))
    body: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(20), default="pending_review")
    unsubscribe_token: Mapped[str] = mapped_column(String(48), unique=True)
    sent_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = created()
