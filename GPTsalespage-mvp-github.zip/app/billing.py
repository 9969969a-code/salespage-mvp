"""Заказы и оплата.

Истина об оплате — только ответ провайдера на запрос статуса (get_payment), полученный сервером.
Webhook лишь ставит задачу сверки. Повторы и гонки закрыты уникальными ключами и блокировкой строк.
Реальный провайдер НЕ подключён: доступен только тестовый (FakePaymentProvider), он явно помечен
как тестовый и запрещён в production.
"""
from __future__ import annotations

import hashlib
import json
import logging
import uuid
from dataclasses import dataclass
from datetime import timedelta
from typing import Optional, Protocol

from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.config import get_settings
from app.db import system_session, utcnow
from app.models import FakeProviderPayment, Order, Payment, PaymentEvent, Plan, Site, SiteVersion
from app.security import audit
from app.utils import hmac_hex, token

log = logging.getLogger("billing")


class BillingError(Exception):
    pass


@dataclass
class ProviderPayment:
    status: str  # pending | succeeded | canceled
    amount_kop: int
    currency: str
    order_ref: str


class PaymentProvider(Protocol):
    name: str
    is_test: bool

    def create_payment(self, order: Order) -> tuple[str, str]: ...

    def get_payment(self, provider_payment_id: str) -> ProviderPayment: ...

    def verify_webhook(self, headers: dict, body: bytes) -> tuple[bool, str, str]: ...


class FakePaymentProvider:
    """Имитатор провайдера. Денег не списывает. Только для разработки и тестов."""
    name = "fake"
    is_test = True

    def create_payment(self, order: Order) -> tuple[str, str]:
        pid = f"fake_{token()[:24]}"
        with system_session() as s:
            s.add(FakeProviderPayment(id=pid, order_ref=str(order.id), amount_kop=order.amount_kop, currency=order.currency))
        return pid, f"{get_settings().PUBLIC_BASE_URL}/test-checkout/{pid}"

    def get_payment(self, provider_payment_id: str) -> ProviderPayment:
        with system_session() as s:
            p = s.get(FakeProviderPayment, provider_payment_id)
            if p is None:
                raise BillingError("платёж не найден у провайдера")
            return ProviderPayment(p.status, p.amount_kop, p.currency, p.order_ref)

    def verify_webhook(self, headers: dict, body: bytes) -> tuple[bool, str, str]:
        sig = headers.get("x-fake-signature", "")
        ok = sig == hmac_hex(get_settings().PAYMENT_WEBHOOK_SECRET, body)
        try:
            data = json.loads(body)
            return ok, str(data["event_id"]), str(data["payment_id"])
        except (ValueError, KeyError, TypeError):
            return False, "", ""

    # методы имитатора (на реальном провайдере их нет)
    def simulate(self, provider_payment_id: str, status: str, amount_kop: Optional[int] = None) -> bytes:
        with system_session() as s:
            p = s.get(FakeProviderPayment, provider_payment_id)
            if p is None:
                raise BillingError("платёж не найден")
            p.status = status
            if amount_kop is not None:
                p.amount_kop = amount_kop
        return json.dumps({"event_id": f"evt_{token()[:16]}", "payment_id": provider_payment_id, "status": status}).encode()


def get_payment_provider() -> PaymentProvider:
    st = get_settings()
    if st.PAYMENT_PROVIDER == "fake" and not st.is_production:
        return FakePaymentProvider()
    if st.PAYMENT_PROVIDER == "sber":
        from app.sber import SberProvider, config_problems
        if config_problems():
            raise BillingError("Эквайринг Сбербанка не настроен: " + ", ".join(config_problems()))
        return SberProvider()
    raise BillingError("Реальный платёжный провайдер не подключён. См. docs/API_REFERENCES.md")


def plan(s: Session, code: str) -> Plan:
    p = s.get(Plan, code)
    if p is None:
        raise BillingError("тариф не найден")
    return p


def create_order(s: Session, site: Site, kind: str = "initial", plan_code: Optional[str] = None) -> tuple[Order, Payment]:
    """s — сессия владельца. Сумма берётся из тарифа на сервере."""
    st = get_settings()
    page = plan(s, site.plan_code or "page")  # тариф выбран владельцем: лендинг или многостраничный
    if kind == "initial":
        if not page.purchasable:
            raise BillingError("Этот тариф сейчас не продаётся. Выберите другой тариф.")
        if site.status not in ("ready",):
            raise BillingError("Сначала подтвердите содержимое сайта.")
        version = s.get(SiteVersion, site.current_version_id)
        if version is None or version.owner_confirmed_at is None:
            raise BillingError("Текущая версия не подтверждена.")
        if s.scalar(select(Order).where(Order.site_id == site.id, Order.status == "paid", Order.kind == "initial")):
            raise BillingError("Тариф уже оплачен: обновления публикуются без новой оплаты.")
        amount, version_id = page.price_kop, version.id
    elif kind == "renewal":
        if site.published_version_id is None:
            raise BillingError("Сайт ещё не публиковался.")
        amount, version_id = st.RENEWAL_PRICE_RUB * 100, site.published_version_id
    elif kind == "subscription":
        if site.status != "live":
            raise BillingError("Подписка подключается к опубликованному сайту.")
        page = plan(s, plan_code or "")
        if page.period != "monthly":
            raise BillingError("Это не месячный тариф.")
        if not page.purchasable:
            raise BillingError("Этот тариф сейчас не продаётся.")
        amount, version_id = page.price_kop, site.published_version_id
    else:
        raise BillingError("неизвестный тип заказа")
    # хеш фиксированной длины (64 символа): исходная строка длиннее поля idempotency_key
    key = hashlib.sha256(f"{site.id}:{kind}:{page.code}:{version_id}:{utcnow():%Y%m%d}".encode()).hexdigest()
    existing = s.scalar(select(Order).where(Order.idempotency_key == key))
    if existing and existing.status in ("created", "awaiting_payment"):
        pay = s.scalar(select(Payment).where(Payment.order_id == existing.id).order_by(Payment.created_at.desc()))
        if pay is not None:
            return existing, pay
    if existing and existing.status == "paid":
        raise BillingError("Этот заказ уже оплачен.")
    order = existing or Order(owner_id=site.owner_id, site_id=site.id, plan_code=page.code, version_id=version_id,
                              kind=kind, amount_kop=amount, currency="RUB", idempotency_key=key)
    if existing is None:
        s.add(order)
        s.flush()
    provider = get_payment_provider()
    pid, url = provider.create_payment(order)
    pay = Payment(owner_id=site.owner_id, order_id=order.id, provider=provider.name, provider_payment_id=pid,
                  amount_kop=order.amount_kop, currency=order.currency, confirmation_url=url, is_test=provider.is_test)
    s.add(pay)
    order.status = "awaiting_payment"
    audit(s, "order.created", actor_kind="user", actor_id=site.owner_id, owner_id=site.owner_id, entity_type="order",
          entity_id=order.id, details={"amount_kop": order.amount_kop, "kind": kind, "test": provider.is_test})
    return order, pay


def handle_webhook(provider_name: str, headers: dict, body: bytes) -> tuple[int, str]:
    from app.jobs import enqueue
    try:
        provider = get_payment_provider()
    except BillingError:
        return 503, "provider not configured"
    if provider.name != provider_name:
        return 404, "unknown provider"
    ok, event_id, pid = provider.verify_webhook({k.lower(): v for k, v in headers.items()}, body)
    try:
        payload = json.loads(body) if body else {}
    except ValueError:
        payload = {"raw": body[:500].decode(errors="replace")}
    with system_session() as s:
        if not ok or not event_id:
            s.add(PaymentEvent(provider=provider_name, event_id=f"invalid_{token()[:12]}", payload=payload,
                               signature_ok=False, result="rejected"))
            return 401, "bad signature"
    try:
        with system_session() as s:
            s.add(PaymentEvent(provider=provider_name, event_id=event_id, payload=payload, signature_ok=True, result="queued"))
            enqueue(s, "reconcile_payment", {"provider": provider_name, "payment_id": pid}, dedupe_key=f"reconcile:{event_id}")
    except IntegrityError:
        return 200, "duplicate"
    return 200, "ok"


def reconcile_payment(provider_name: str, provider_payment_id: str) -> str:
    from app.analytics import platform_event
    from app.notify import notify_operator, notify_owner
    from app.publishing import extend_hosting, queue_publication
    provider = get_payment_provider()
    info = provider.get_payment(provider_payment_id)
    with system_session() as s:
        pay = s.scalar(select(Payment).where(Payment.provider == provider_name, Payment.provider_payment_id == provider_payment_id).with_for_update())
        if pay is None:
            return "unknown payment"
        order = s.scalar(select(Order).where(Order.id == pay.order_id).with_for_update())
        if info.status == "succeeded":
            if info.amount_kop != order.amount_kop or info.currency != order.currency or info.order_ref != str(order.id):
                audit(s, "payment.mismatch", actor_kind="system", owner_id=order.owner_id, entity_type="order", entity_id=order.id,
                      details={"expected": order.amount_kop, "got": info.amount_kop})
                notify_operator(s, f"Несовпадение суммы по заказу {order.id}", f"mismatch:{pay.id}")
                return "mismatch"
            if order.status == "paid":
                return "already paid"
            pay.status, pay.updated_at = "succeeded", utcnow()
            order.status, order.paid_at = "paid", utcnow()
            site = s.get(Site, order.site_id)
            if order.kind == "subscription":  # продлевает обслуживание, сайт не перепубликуется
                from app.subscriptions import extend_service
                extend_service(site, order.plan_code)
                audit(s, "payment.succeeded", actor_kind="system", owner_id=order.owner_id, entity_type="order", entity_id=order.id,
                      details={"provider": provider_name, "test": pay.is_test, "kind": "subscription"})
                notify_owner(s, order.owner_id, "subscription", {"amount": order.amount_kop // 100, "test": pay.is_test,
                             "until": f"{site.service_paid_until:%d.%m.%Y}"}, f"payment:{order.id}")
                platform_event(s, "subscription_paid", owner_id=order.owner_id)
                return "paid"
            extend_hosting(site, plan(s, order.plan_code).hosting_months if order.kind == "initial" else 12)
            if order.kind == "renewal" and site.status == "expired":
                site.status = "publishing"
            queue_publication(s, site, order.version_id, order.id)
            audit(s, "payment.succeeded", actor_kind="system", owner_id=order.owner_id, entity_type="order", entity_id=order.id,
                  details={"provider": provider_name, "test": pay.is_test})
            notify_owner(s, order.owner_id, "payment", {"amount": order.amount_kop // 100, "test": pay.is_test}, f"payment:{order.id}")
            platform_event(s, "order_paid", owner_id=order.owner_id)
            return "paid"
        if info.status in ("canceled", "failed") and order.status != "paid":
            pay.status, order.status = "failed", "cancelled"
            return "cancelled"
    return "pending"


def stale_pending_payments(older_than_minutes: int = 2) -> list[tuple[str, str]]:
    with system_session() as s:
        rows = s.execute(select(Payment.provider, Payment.provider_payment_id).where(
            Payment.status == "pending", Payment.created_at < utcnow() - timedelta(minutes=older_than_minutes))).all()
    return [(r[0], r[1]) for r in rows]
