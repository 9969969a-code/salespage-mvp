"""Агенты выполнения: роли, которые реально работают внутри платформы.

Каждая роль — это существующий модуль и тип задачи в очереди (app/jobs.py). Координатор — сама очередь:
она запускает задачи, повторяет при сбое с задержкой и помечает безнадёжные как dead. Результаты хранятся в базе,
решения людей (одобрение писем, подтверждение текстов, жалобы) — в журнале действий.
Агенты разработки из Agency Agents описаны в docs/AGENTS.md и здесь не исполняются.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import timedelta

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.db import utcnow
from app.models import Job


@dataclass(frozen=True)
class RuntimeAgent:
    key: str
    title: str
    kind: str          # ai | code | human
    jobs: tuple[str, ...]
    module: str
    does: str
    checks: str


AGENTS = (
    RuntimeAgent("copywriter", "Копирайтер сайта", "ai", ("generate_site",), "app/ai.py, app/sitegen.py",
                 "Собирает блоки сайта из фактов владельца (тестовый генератор или Claude).",
                 "Схема блоков и проверка фактов: выдуманные цены, сроки и отзывы отклоняются."),
    RuntimeAgent("editor", "Редактор по командам", "ai", (), "app/ai.py, app/assistant.py",
                 "Выполняет правки словами в редакторе; отвечает только по теме сайта.",
                 "Разрешённые операции, проверка фактов, версия на каждую правку."),
    RuntimeAgent("publisher", "Публикатор", "code", ("publish", "expire_sites"), "app/publishing.py",
                 "Собирает релиз, переключает его атомарно, проверяет доступность страницы, снимает просроченные сайты.",
                 "Публикация только оплаченного сайта; при сбое проверки — откат на прежний релиз."),
    RuntimeAgent("cashier", "Кассир", "code", ("reconcile_payment", "reconcile_stale"), "app/billing.py, app/sber.py",
                 "Сверяет платежи с провайдером после уведомления и по расписанию.",
                 "Подпись уведомления, сверка суммы и статуса у провайдера, идемпотентность."),
    RuntimeAgent("notifier", "Курьер уведомлений", "code", ("send_notification", "operator_alert"), "app/notify.py",
                 "Доставляет заявки и события владельцу и оператору в Telegram.",
                 "Заявка сохраняется до отправки; повторы с задержкой; недоставленное видно здесь."),
    RuntimeAgent("lead-analyst", "Аналитик лидов", "code", ("prospect_search",), "app/prospecting.py",
                 "Находит компании, проверяет их сайты, отсеивает чужую нишу и дубли, оценивает.",
                 "Только разрешённые источники; стоп-лист; без выдуманных данных."),
    RuntimeAgent("offer-writer", "Автор предложений", "human", ("prospect_send", "client_outreach_send"),
                 "app/prospecting.py, app/promotion.py",
                 "Готовит персональные письма; отправляет только одобренные человеком.",
                 "Одобрение оператором или владельцем, ссылка отказа, дневные лимиты."),
    RuntimeAgent("janitor", "Уборщик", "code", ("purge_events",), "app/analytics.py",
                 "Удаляет события аналитики старше срока хранения.", "Срок из EVENTS_RETENTION_DAYS."),
)


def status(s: Session, days: int = 7) -> list[dict]:
    """Сводка по каждому агенту за период: выполнено, в очереди, ошибки, последняя ошибка."""
    since = utcnow() - timedelta(days=days)
    rows = s.execute(select(Job.kind, Job.status, func.count()).where(Job.created_at >= since)
                     .group_by(Job.kind, Job.status)).all()
    counts: dict[str, dict[str, int]] = {}
    for kind, st, n in rows:
        counts.setdefault(kind, {})[st] = n
    out = []
    for a in AGENTS:
        c: dict[str, int] = {}
        for kind in a.jobs:
            for st, n in counts.get(kind, {}).items():
                c[st] = c.get(st, 0) + n
        last_error = ""
        if a.jobs:
            last_error = s.scalar(select(Job.last_error).where(Job.kind.in_(a.jobs), Job.last_error != "")
                                  .order_by(Job.created_at.desc()).limit(1)) or ""
        health = "ошибки" if c.get("dead") else ("повторы" if c.get("failed") else ("работает" if c.get("done") else "нет запусков"))
        out.append({"agent": a, "done": c.get("done", 0), "queued": c.get("queued", 0) + c.get("running", 0),
                    "failed": c.get("failed", 0), "dead": c.get("dead", 0), "last_error": last_error[:300], "health": health})
    return out
