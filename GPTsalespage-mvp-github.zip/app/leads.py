"""Заявки и жалобы с опубликованных сайтов.

Заявка сохраняется в базе и в той же транзакции создаются событие аналитики и уведомление
владельцу (outbox). Доставка в Telegram идёт отдельно, поэтому заявка не теряется при его сбое.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Optional

from sqlalchemy import select

from app.analytics import classify_source
from app.config import get_settings
from app.db import system_session
from app.models import AbuseReport, Event, Lead, Site
from app.notify import notify_operator, notify_owner
from app.render import CONSENT_VERSION
from app.security import audit
from app.utils import mask_phone, normalize_phone, visitor_hash

_CTRL = re.compile(r"[\x00-\x08\x0b-\x1f\x7f]")


@dataclass
class LeadResult:
    ok: bool
    message: str
    lead_id: Optional[str] = None
    spam: bool = False


def _clean(value: Optional[str], limit: int) -> str:
    return _CTRL.sub(" ", value or "").strip()[:limit]


def create_lead(slug: str, form: dict, ip: str, ua: str) -> LeadResult:
    if _clean(form.get("website"), 200):  # скрытое поле заполняют только боты
        return LeadResult(True, "Заявка отправлена.", spam=True)
    if form.get("consent") not in ("yes", "on", "1", "true"):
        return LeadResult(False, "Нужно согласие на обработку персональных данных.")
    phone = normalize_phone(_clean(form.get("phone"), 30))
    if not phone:
        return LeadResult(False, "Укажите телефон полностью, например +7 912 345-67-89.")
    name, comment, wanted = _clean(form.get("name"), 80), _clean(form.get("comment"), 500), _clean(form.get("wanted_date"), 40)
    with system_session() as s:
        site = s.scalar(select(Site).where(Site.slug == slug, Site.status == "live"))
        if site is None:
            return LeadResult(False, "Сайт сейчас не принимает заявки.")
        lead = Lead(owner_id=site.owner_id, site_id=site.id, name=name, phone=phone, comment=comment,
                    wanted_date=wanted, consent_version=_clean(form.get("consent_version"), 60) or CONSENT_VERSION)
        s.add(lead)
        s.flush()
        from urllib.parse import parse_qs, urlparse
        q = parse_qs(urlparse(form.get("_referrer", "")).query)  # метки UTM страницы, с которой отправлена заявка
        utm = {k: (q.get(f"utm_{k}") or [""])[0][:64] for k in ("source", "medium", "campaign")}
        s.add(Event(owner_id=site.owner_id, site_id=site.id, kind="lead_submit",
                    source=classify_source(form.get("_referrer", ""), utm["source"]),
                    utm_source=utm["source"], utm_medium=utm["medium"], utm_campaign=utm["campaign"],
                    visitor_hash=visitor_hash(get_settings().SECRET_KEY, ip, ua)))
        notify_owner(s, site.owner_id, "lead", {"site": site.slug, "name": name, "phone": phone, "comment": comment,
                                                 "wanted_date": wanted}, f"lead:{lead.id}")
        audit(s, "lead.created", actor_kind="visitor", owner_id=site.owner_id, entity_type="lead", entity_id=lead.id,
              details={"phone": mask_phone(phone)})
        return LeadResult(True, "Спасибо! Заявка отправлена, с вами свяжутся.", str(lead.id))


def create_abuse_report(slug: str, reason: str, contact: str, honeypot: str) -> tuple[bool, str]:
    if _clean(honeypot, 200):
        return True, "Жалоба отправлена."
    reason = _clean(reason, 2000)
    if len(reason) < 10:
        return False, "Опишите проблему подробнее (от 10 символов)."
    with system_session() as s:
        site = s.scalar(select(Site).where(Site.slug == slug))
        if site is None:
            return False, "Сайт не найден."
        report = AbuseReport(site_id=site.id, reporter_contact=_clean(contact, 120), reason=reason)
        s.add(report)
        s.flush()
        notify_operator(s, f"Жалоба на сайт {slug}: {reason[:200]}", f"abuse:{report.id}")
    return True, "Жалоба отправлена. Её проверит администратор; сайт не блокируется без проверки."
