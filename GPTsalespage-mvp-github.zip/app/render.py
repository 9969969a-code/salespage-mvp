"""Сборка HTML клиентского сайта из блоков. Только шаблоны с экранированием, без кода от ИИ."""
from __future__ import annotations

import io
import json
from pathlib import Path
from typing import Callable, Optional

from jinja2 import Environment, FileSystemLoader
from markupsafe import Markup
from PIL import Image, ImageDraw, ImageFont

from app.config import BASE_DIR
from app.content import PALETTES
from app.utils import format_phone

ENV = Environment(loader=FileSystemLoader(str(BASE_DIR / "templates" / "sites")), autoescape=True,
                  trim_blocks=True, lstrip_blocks=True)
FONT_STACKS = {
    "sans": "Inter, system-ui, -apple-system, 'Segoe UI', Roboto, Arial, sans-serif",
    "serif": "Georgia, 'PT Serif', 'Times New Roman', serif",
    "rounded": "'Nunito', 'Trebuchet MS', system-ui, sans-serif",
}
CONSENT_VERSION = "lead-consent-2026-10"
DEJAVU = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"


def contacts_from(facts: dict[str, str]) -> dict:
    phone = facts.get("phone", "")
    return {
        "phone": format_phone(phone) if phone else "",
        "phone_href": f"tel:+{phone}" if phone else "",
        "whatsapp_href": f"https://wa.me/{facts['whatsapp']}" if facts.get("whatsapp") else "",
        "telegram_href": f"https://t.me/{facts['telegram']}" if facts.get("telegram") else "",
        "address": facts.get("address", ""),
        "hours": facts.get("hours", ""),
    }


def jsonld(facts: dict[str, str], url: str, image_url: str) -> Markup:
    data = {"@context": "https://schema.org", "@type": "Florist", "name": facts.get("name", ""), "url": url}
    if facts.get("phone"):
        data["telephone"] = "+" + facts["phone"]
    if facts.get("address"):
        data["address"] = {"@type": "PostalAddress", "streetAddress": facts["address"], "addressLocality": facts.get("city", "")}
    if image_url:
        data["image"] = image_url
    return Markup(json.dumps(data, ensure_ascii=False).replace("</", "<\\/"))


# Многостраничный сайт (тариф 4 990 ₽): те же блоки, разложенные по страницам. Пустые страницы не создаются.
PAGES = [("index", "Главная", "/", ("hero", "benefits", "catalog", "reviews", "lead_form")),
         ("catalog", "Каталог и цены", "/catalog/", ("catalog", "lead_form")),
         ("delivery", "Доставка и оплата", "/delivery/", ("delivery", "payment", "faq")),
         ("contacts", "Контакты", "/contacts/", ("contacts", "lead_form"))]


def site_pages(content: dict) -> list[tuple[str, str, str]]:
    visible = {b["type"] for b in content["blocks"] if b.get("visible", True)}
    out = []
    for key, label, path, types in PAGES:
        main = [t for t in types if t != "lead_form"]
        if key == "index" or any(t in visible for t in main):
            out.append((key, label, path))
    return out


def render_site(content: dict, facts: dict[str, str], *, mode: str, image_url: Callable[[str], str],
                base_url: str, asset_prefix: str, css_url: str, operator: dict, multipage: bool = False,
                page: str = "index", nav_href: Optional[Callable[[str, str], str]] = None) -> tuple[str, str, str]:
    """Возвращает (index.html, site.css, privacy.html). mode: preview | publish."""
    theme = content["theme"]
    pal = PALETTES[theme["palette"]]
    ctx = {
        "c": content, "facts": facts, "mode": mode, "theme": theme, "pal": pal,
        "button": theme.get("button_color") or pal["accent"], "font": FONT_STACKS[theme["font"]],
        "contacts": contacts_from(facts), "img": image_url, "base_url": base_url, "asset_prefix": asset_prefix,
        "css_url": css_url, "consent_version": CONSENT_VERSION, "operator": operator,
        "blocks": [b for b in content["blocks"] if b.get("visible", True)],
        "nav": [], "page_title": "", "page_path": "/",
    }
    if multipage:
        pages = site_pages(content)
        spec = next((p for p in PAGES if p[0] == page), PAGES[0])
        if page not in {k for k, _, _ in pages}:
            spec = PAGES[0]
        ctx["blocks"] = [b for b in ctx["blocks"] if b["type"] in spec[3]]
        href = nav_href or (lambda key, path: path)
        ctx["nav"] = [(label, href(key, path), key == spec[0]) for key, label, path in pages]
        ctx["page_title"] = "" if spec[0] == "index" else spec[1]
        ctx["page_path"] = spec[2]
    hero = next(b for b in content["blocks"] if b["type"] == "hero")
    hero_img = hero["data"].get("image")
    ctx["og_image"] = f"{base_url}/og.png" if mode == "publish" else ""
    ctx["jsonld"] = jsonld(facts, base_url + "/", image_url(hero_img) if (hero_img and mode == "publish") else "")
    return (ENV.get_template("site.html").render(**ctx), ENV.get_template("site.css.j2").render(**ctx),
            ENV.get_template("privacy.html").render(**ctx))


def favicon_svg(name: str, accent: str) -> str:
    letter = (name.strip()[:1] or "Ц").upper().replace("<", "").replace("&", "")
    return (f"<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'><rect width='64' height='64' rx='14' fill='{accent}'/>"
            f"<text x='32' y='43' font-family='Arial' font-size='34' font-weight='700' fill='#fff' text-anchor='middle'>{letter}</text></svg>")


def og_image(name: str, city: str, palette: str, photo: Optional[bytes]) -> bytes:
    pal = PALETTES[palette]
    img = Image.new("RGB", (1200, 630), pal["soft"])
    if photo:
        with Image.open(io.BytesIO(photo)) as ph:
            ph = ph.convert("RGB")
            ratio = max(1200 / ph.width, 630 / ph.height)
            ph = ph.resize((int(ph.width * ratio) + 1, int(ph.height * ratio) + 1))
            left, top = (ph.width - 1200) // 2, (ph.height - 630) // 2
            img.paste(ph.crop((left, top, left + 1200, top + 630)))
    draw = ImageDraw.Draw(img)
    draw.rectangle([0, 470, 1200, 630], fill=pal["accent"])
    try:
        big, small = ImageFont.truetype(DEJAVU, 56), ImageFont.truetype(DEJAVU, 30)
    except OSError:
        big = small = ImageFont.load_default()
    draw.text((48, 490), name[:34], font=big, fill=pal["on_accent"])
    if city:
        draw.text((50, 568), city[:50], font=small, fill=pal["on_accent"])
    out = io.BytesIO()
    img.save(out, "PNG", optimize=True)
    return out.getvalue()


def robots_txt(base_url: str, indexable: bool) -> str:
    if not indexable:
        return "User-agent: *\nDisallow: /\n"
    return f"User-agent: *\nAllow: /\nDisallow: /_lead\nDisallow: /_e\nSitemap: {base_url}/sitemap.xml\n"


def sitemap_xml(base_url: str, lastmod: str, paths: tuple[str, ...] = ("/",)) -> str:
    urls = "".join(f"<url><loc>{base_url}{p}</loc><lastmod>{lastmod}</lastmod></url>" for p in paths)
    return ("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">"
            f"{urls}</urlset>\n")


def stub_html(title: str, text: str) -> str:
    return ENV.get_template("stub.html").render(title=title, text=text)


def tracker_js() -> bytes:
    return (BASE_DIR / "static" / "t.js").read_bytes()


def illustration_bytes(name: str) -> bytes:
    p = BASE_DIR / "static" / "illustrations" / f"{name}.svg"
    return p.read_bytes()


def illustration_path(name: str) -> Path:
    return BASE_DIR / "static" / "illustrations" / f"{name}.svg"
