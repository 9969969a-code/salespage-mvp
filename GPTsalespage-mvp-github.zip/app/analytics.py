"""Собственная аналитика: таблица событий и простые отчёты.

Клики по телефону и мессенджерам — это клики, а не заявки; заявки — это отправленные формы;
оплаты — подтверждённые платежи. В отчётах они разделены.
"""
from __future__ import annotations

import uuid
from datetime import timedelta
from typing import Optional
from urllib.parse import urlparse

from sqlalchemy import delete, func, select
from sqlalchemy.orm import Session

from app.config import get_settings
from app.db import system_session, utcnow
from app.models import Event, Lead, Site, User
from app.utils import visitor_hash

SITE_EVENTS = {"page_view", "click_phone", "click_whatsapp", "click_telegram", "lead_submit"}
PLATFORM_EVENTS = {"platform_visit", "signup", "project_created", "generation_done", "order_paid", "published"}


def classify_source(referrer: str, utm_source: str) -> str:
    u = (utm_source or "").lower()
    host = (urlparse(referrer).hostname or "").lower() if referrer else ""
    if u in ("vk", "vkontakte") or host.endswith(("vk.com", "vk.ru", "vk.me")):
        return "vk"
    if u in ("telegram", "tg") or host.endswith(("t.me", "telegram.org")):
        return "telegram"
    if any(x in host for x in ("yandex.", "google.", "bing.", "mail.ru")):
        return "search"
    if u:
        return "utm"
    return "direct" if not host else "other"


def _clip(v: Optional[str], n: int) -> str:
    return (v or "")[:n]


def record_site_event(slug: str, kind: str, ip: str, ua: str, referrer: str = "", utm: Optional[dict] = None) -> bool:
    if kind not in SITE_EVENTS:
        return False
    utm = utm or {}
    with system_session() as s:
        site = s.scalar(select(Site).where(Site.slug == slug, Site.status == "live"))
        if site is None:
            return False
        s.add(Event(owner_id=site.owner_id, site_id=site.id, kind=kind, source=classify_source(referrer, utm.get("source", "")),
                    utm_source=_clip(utm.get("source"), 64), utm_medium=_clip(utm.get("medium"), 64),
                    utm_campaign=_clip(utm.get("campaign"), 64), referrer_host=_clip(urlparse(referrer).hostname if referrer else "", 128),
                    visitor_hash=visitor_hash(get_settings().SECRET_KEY, ip, ua)))
    return True


def platform_event(s: Session, kind: str, owner_id: Optional[uuid.UUID] = None, ip: str = "", ua: str = "",
                   referrer: str = "", utm: Optional[dict] = None) -> None:
    utm = utm or {}
    s.add(Event(owner_id=owner_id, kind=kind, source=classify_source(referrer, utm.get("source", "")),
                utm_source=_clip(utm.get("source"), 64), utm_medium=_clip(utm.get("medium"), 64),
                utm_campaign=_clip(utm.get("campaign"), 64), referrer_host=_clip(urlparse(referrer).hostname if referrer else "", 128),
                visitor_hash=visitor_hash(get_settings().SECRET_KEY, ip, ua) if ip else ""))


def owner_stats(s: Session, site_id: uuid.UUID, days: int = 30) -> dict:
    """s — сессия владельца: RLS вернёт только его события."""
    since = utcnow() - timedelta(days=days)
    rows = s.execute(select(Event.kind, func.count(), func.count(func.distinct(Event.visitor_hash)))
                     .where(Event.site_id == site_id, Event.created_at >= since).group_by(Event.kind)).all()
    by_kind = {k: {"total": t, "unique": u} for k, t, u in rows}
    sources = dict(s.execute(select(Event.source, func.count()).where(Event.site_id == site_id, Event.kind == "page_view",
                                                                     Event.created_at >= since).group_by(Event.source)).all())
    leads = s.scalar(select(func.count()).select_from(Lead).where(Lead.site_id == site_id, Lead.created_at >= since)) or 0
    views = by_kind.get("page_view", {}).get("unique", 0)
    return {"days": days, "visitors": views, "page_views": by_kind.get("page_view", {}).get("total", 0),
            "clicks_phone": by_kind.get("click_phone", {}).get("total", 0),
            "clicks_whatsapp": by_kind.get("click_whatsapp", {}).get("total", 0),
            "clicks_telegram": by_kind.get("click_telegram", {}).get("total", 0),
            "leads": leads, "sources": sources,
            "lead_rate": round(100 * leads / views, 1) if views else 0.0}


def funnel(days: int = 30) -> dict:
    since = utcnow() - timedelta(days=days)
    with system_session() as s:
        def count(kind: str, distinct_visitors: bool = False) -> int:
            col = func.count(func.distinct(Event.visitor_hash)) if distinct_visitors else func.count(func.distinct(Event.owner_id))
            return s.scalar(select(col).where(Event.kind == kind, Event.created_at >= since)) or 0
        steps = [("Посещение", count("platform_visit", True)), ("Регистрация", count("signup")),
                 ("Проект", count("project_created")), ("Генерация", count("generation_done")),
                 ("Оплата", count("order_paid")), ("Публикация", count("published"))]
        visits_by_source = dict(s.execute(select(Event.source, func.count(func.distinct(Event.visitor_hash)))
                                          .where(Event.kind == "platform_visit", Event.created_at >= since).group_by(Event.source)).all())
        signups = s.scalars(select(User.signup_source).where(User.created_at >= since)).all()
    signup_sources: dict[str, int] = {}
    for src in signups:
        key = (src or {}).get("source", "direct")
        signup_sources[key] = signup_sources.get(key, 0) + 1
    return {"days": days, "steps": steps, "visits_by_source": visits_by_source, "signups_by_source": signup_sources}


def purge_old_events() -> int:
    days = get_settings().EVENTS_RETENTION_DAYS
    with system_session() as s:
        res = s.execute(delete(Event).where(Event.created_at < utcnow() - timedelta(days=days)))
        return res.rowcount or 0
