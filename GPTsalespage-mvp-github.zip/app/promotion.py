"""Продвижение сайтов клиентов теми же инструментами, которыми платформа продаёт себя.

1. Ссылки с метками UTM для ВК, Telegram, Авито и печатной рекламы + статистика по источникам.
2. Готовые посты из фактов о магазине (без выдуманных скидок, цен и сроков).
3. Корпоративные клиенты магазина: поиск компаний (офисы, рестораны, гостиницы, свадебные салоны, агентства),
   персональное предложение от магазина, отправка ТОЛЬКО после одобрения владельцем, ссылка отказа, общий стоп-лист.
"""
from __future__ import annotations

import logging
import re
import secrets
import uuid
from datetime import timedelta
from typing import Optional

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.config import get_settings
from app.db import system_session, utcnow
from app.models import ClientOutreach, ClientProspect, Event, FakeEmail, Site
from app.prospecting import Company, env, suppressed, twogis_search, _smtp_send
from app.security import audit
from app.utils import format_phone, normalize_phone

log = logging.getLogger("salespage.promotion")

CHANNELS = [("vk", "social", "ВКонтакте"), ("telegram", "social", "Telegram"), ("avito", "classifieds", "Авито"),
            ("print", "offline", "Визитки и листовки")]
CATEGORIES = {
    "office": ("Офисы", "офис", "букеты для поздравления сотрудников и оформление офиса"),
    "restaurant": ("Рестораны и кафе", "ресторан", "оформление залов и столов"),
    "hotel": ("Гостиницы", "гостиница", "композиции для лобби и номеров"),
    "wedding": ("Свадебные салоны", "свадебный салон", "свадебная флористика для ваших клиентов"),
    "events": ("Ивент-агентства", "организация мероприятий", "оформление мероприятий"),
}
MOCK_B2B = [  # вымышленные компании, домены example.* зарезервированы
    ("b1", "office", "ООО «Северный офис» (тест)", "Санкт-Петербург", "office1@example.com"),
    ("b2", "office", "Бизнес-центр «Пулково» (тест)", "Санкт-Петербург", "bc@example.com"),
    ("b3", "restaurant", "Ресторан «Набережная» (тест)", "Санкт-Петербург", "rest@example.com"),
    ("b4", "hotel", "Отель «Мойка» (тест)", "Санкт-Петербург", "hotel@example.com"),
    ("b5", "wedding", "Свадебный салон «Венец» (тест)", "Санкт-Петербург", ""),
    ("b6", "events", "Агентство «Праздник» (тест)", "Санкт-Петербург", "events@example.com"),
    ("b7", "office", "ООО «Тверской офис» (тест)", "Москва", "office7@example.com"),
]
DAILY_LIMIT_PER_SITE = 10


def tracked_url(site_url: str, source: str, medium: str, campaign: str = "promo") -> str:
    return f"{site_url}/?utm_source={source}&utm_medium={medium}&utm_campaign={campaign}"


def tracked_links(site: Site) -> list[tuple[str, str]]:
    url = get_settings().site_url(site.slug)
    return [(label, tracked_url(url, src, med)) for src, med, label in CHANNELS]


def source_stats(s: Session, site_id: uuid.UUID, days: int = 30) -> list[dict]:
    since = utcnow() - timedelta(days=days)
    rows = s.execute(select(Event.utm_source, Event.kind, func.count()).where(Event.site_id == site_id, Event.created_at >= since)
                     .group_by(Event.utm_source, Event.kind)).all()
    by: dict[str, dict] = {}
    for src, kind, n in rows:
        d = by.setdefault(src or "без метки", {"source": src or "без метки", "views": 0, "clicks": 0, "leads": 0})
        if kind == "page_view":
            d["views"] += n
        elif kind.startswith("click_"):
            d["clicks"] += n
        elif kind == "lead_submit":
            d["leads"] += n
    return sorted(by.values(), key=lambda d: -d["views"])


def posts(facts: dict[str, str], site_url: str) -> list[dict]:
    """Посты строятся только из фактов владельца; чего нет в фактах — того нет в постах."""
    name, city = facts.get("name", "Наш магазин"), facts.get("city", "")
    link = tracked_url(site_url, "vk", "social", "post")
    out = [{"title": "Знакомство", "text": f"«{name}» — {facts.get('about', 'цветочный магазин').lower()}{' в ' + city if city else ''}. "
                                          f"Посмотреть букеты и оставить заявку: {link}"}]
    if facts.get("assortment"):
        items = "\n".join(f"• {x.strip()}" for x in re.split(r"[;,]", facts["assortment"]) if x.strip())
        out.append({"title": "Ассортимент", "text": f"Что можно заказать в «{name}»:\n{items}\n\nПодробнее: {link}"})
    if facts.get("delivery"):
        out.append({"title": "Доставка", "text": f"{facts['delivery'].rstrip('.')}. Оформить заказ: {link}"})
    if facts.get("advantages"):
        adv = "\n".join(f"• {x.strip()}" for x in re.split(r"[;]", facts["advantages"]) if x.strip())
        out.append({"title": "Почему мы", "text": f"{adv}\n\n{link}"})
    if facts.get("prices"):
        out.append({"title": "Цены", "text": f"{facts['prices'].rstrip('.')}. Уточнить и заказать: {link}"})
    out.append({"title": "Заявка", "text": f"Нужен букет? Оставьте заявку на сайте, и «{name}» свяжется с вами: {link}"})
    return out


def _offer(facts: dict[str, str], site: Site, category: str, token: str) -> tuple[str, str]:
    st = get_settings()
    name, city = facts.get("name", ""), facts.get("city", "")
    label, _, need = CATEGORIES[category]
    link = tracked_url(st.site_url(site.slug), "b2b", "email", category)
    lines = [f"Здравствуйте!", "",
             f"Это «{name}»{', ' + facts['about'].lower() if facts.get('about') else ''}{', ' + city if city else ''}. "
             f"Пишем компаниям, которым могут быть полезны цветы: {need}.", ""]
    if facts.get("assortment"):
        lines.append(f"Что у нас есть: {facts['assortment']}.")
    for key in ("delivery", "prices"):
        if facts.get(key):
            lines.append(facts[key].rstrip(".") + ".")
    lines += ["", f"Ассортимент и заявка: {link}"]
    if facts.get("phone"):
        lines.append(f"Телефон: {format_phone(normalize_phone(facts['phone']) or facts['phone'])}")
    lines += ["", f"Если это неинтересно, нажмите {st.PUBLIC_BASE_URL}/u/{token} — больше не напишем.", "",
              f"Письмо отправлено через сервис «Сайт с ИИ» по поручению «{name}»."]
    return f"Цветы для вашей компании от «{name}»", "\n".join(lines)


def search_b2b(s: Session, owner_id: uuid.UUID, site: Site, facts: dict[str, str], category: str) -> dict:
    """s — сессия владельца. Создаёт компании и письма «на одобрение»; ничего не отправляет."""
    if category not in CATEGORIES:
        raise ValueError("неизвестная категория")
    city = facts.get("city", "")
    source = env("PROSPECT_SOURCE", "mock")
    if source == "mock":
        found = [Company(eid, n, cat, c, email=e) for eid, cat, n, c, e in MOCK_B2B if cat == category and c == city]
    else:
        found = twogis_search(city, CATEGORIES[category][1], 30)
    stats = {"found": len(found), "queued": 0, "no_email": 0, "skipped": 0}
    for c in found:
        if s.scalar(select(ClientProspect).where(ClientProspect.site_id == site.id, ClientProspect.source == source,
                                                 ClientProspect.external_id == c.external_id)):
            stats["skipped"] += 1
            continue
        email = c.email.strip().lower() if re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", c.email.strip()) else ""
        p = ClientProspect(owner_id=owner_id, site_id=site.id, source=source, external_id=c.external_id, name=c.name[:160],
                           category=category, city=city, email=email, phone=normalize_phone(c.phone) or "")
        s.add(p)
        s.flush()
        with system_session() as sys_s:
            blocked = suppressed(sys_s, email, p.phone)
        if not email:
            p.status = "no_email"
            stats["no_email"] += 1
        elif blocked:
            p.status = "opted_out"
            stats["skipped"] += 1
        else:
            token = secrets.token_urlsafe(24)
            subject, body = _offer(facts, site, category, token)
            s.add(ClientOutreach(owner_id=owner_id, site_id=site.id, prospect_id=p.id, to_address=email, subject=subject,
                                 body=body, status="pending_review", unsubscribe_token=token))
            p.status = "pending_review"
            stats["queued"] += 1
    audit(s, "promotion.b2b_search", actor_kind="user", actor_id=owner_id, owner_id=owner_id, entity_type="site",
          entity_id=site.id, details={"category": category, **stats})
    return stats


def review(s: Session, owner_id: uuid.UUID, outreach_id: uuid.UUID, approve: bool, body: str = "") -> tuple[bool, str]:
    from app.jobs import enqueue
    m = s.get(ClientOutreach, outreach_id)  # RLS: чужое письмо не найдётся
    if m is None or m.status != "pending_review":
        return False, "Письмо не найдено или уже рассмотрено."
    if body.strip():
        if f"/u/{m.unsubscribe_token}" not in body:
            return False, "В тексте должна остаться ссылка отказа."
        m.body = body.strip()[:5000]
    p = s.get(ClientProspect, m.prospect_id)
    if approve:
        m.status = p.status = "approved"
        enqueue(s, "client_outreach_send", {"outreach_id": str(m.id)}, dedupe_key=f"client-send:{m.id}")
    else:
        m.status = p.status = "rejected"
    audit(s, "promotion.approve" if approve else "promotion.reject", actor_kind="user", actor_id=owner_id, owner_id=owner_id,
          entity_type="client_outreach", entity_id=m.id)
    return True, "Письмо одобрено и поставлено в очередь." if approve else "Письмо отклонено."


def send(outreach_id: uuid.UUID) -> str:
    day = utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
    with system_session() as s:
        m = s.get(ClientOutreach, outreach_id)
        if m is None or m.status != "approved":
            return "skip"
        p = s.get(ClientProspect, m.prospect_id)
        if suppressed(s, m.to_address, p.phone):
            m.status = p.status = "opted_out"
            return "suppressed"
        sent = s.scalar(select(func.count()).select_from(ClientOutreach).where(ClientOutreach.site_id == m.site_id,
                                                                               ClientOutreach.sent_at >= day)) or 0
        if sent >= DAILY_LIMIT_PER_SITE:
            raise RuntimeError("дневной лимит писем сайта исчерпан")  # повторится завтра
        if env("EMAIL_MODE", "mock") == "off":
            m.status = "failed"
            return "email_off"
        if env("EMAIL_MODE", "mock") == "mock":
            s.add(FakeEmail(to_address=m.to_address, subject=m.subject, body=m.body))
            log.info("[MOCK EMAIL] -> %s: %s", m.to_address, m.subject)
        else:
            _smtp_send(m.to_address, m.subject, m.body)
        m.status, m.sent_at, p.status = "sent", utcnow(), "sent"
    return "sent"


def unsubscribe(token: str) -> bool:
    from app.models import SuppressionEntry
    with system_session() as s:
        m = s.scalar(select(ClientOutreach).where(ClientOutreach.unsubscribe_token == token[:48]))
        if m is None:
            return False
        p = s.get(ClientProspect, m.prospect_id)
        for value in {m.to_address.lower(), p.phone} - {""}:
            if s.get(SuppressionEntry, value) is None:
                s.add(SuppressionEntry(value=value, reason="unsubscribe"))
        p.status = "opted_out"
        if m.status in ("pending_review", "approved"):
            m.status = "opted_out"
    return True
