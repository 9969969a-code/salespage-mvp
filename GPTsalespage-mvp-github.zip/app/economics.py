"""Экономика платформы: оборот, расходы, прибыль-оценка, подписки, конверсия, отток, путь к цели.

Оборот — сумма подтверждённых оплат. Прибыль — оценка: оборот минус комиссия провайдера, расходы на ИИ и постоянные
расходы из настроек (PAYMENT_FEE_PERCENT, AI_COST_PER_CALL_RUB, MONTHLY_FIXED_COSTS_RUB). Не заданная настройка = 0,
и это показывается как «не задано», а не как реальный ноль.
"""
from __future__ import annotations

import os
from datetime import timedelta

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.analytics import funnel
from app.db import utcnow
from app.models import AIUsage, Order, Plan, Site

TARGET_RUB = 1_000_000


def _num(name: str) -> tuple[float, bool]:
    raw = os.getenv(name, "").strip().replace(",", ".")
    try:
        return float(raw), True
    except ValueError:
        return 0.0, False


def compute(s: Session, days: int = 30) -> dict:
    since = utcnow() - timedelta(days=days)
    paid = select(Order).where(Order.status == "paid", Order.paid_at >= since)
    orders = s.scalars(paid).all()
    revenue = sum(o.amount_kop for o in orders) / 100
    by_plan: dict[str, dict] = {}
    for o in orders:
        d = by_plan.setdefault(o.plan_code, {"count": 0, "revenue": 0.0})
        d["count"] += 1
        d["revenue"] += o.amount_kop / 100
    avg = revenue / len(orders) if orders else 0.0
    fee_pct, fee_set = _num("PAYMENT_FEE_PERCENT")
    ai_cost, ai_set = _num("AI_COST_PER_CALL_RUB")
    fixed, fixed_set = _num("MONTHLY_FIXED_COSTS_RUB")
    ai_calls = s.scalar(select(func.count()).select_from(AIUsage).where(AIUsage.created_at >= since, AIUsage.status == "ok")) or 0
    fees = revenue * fee_pct / 100
    ai_total = ai_calls * ai_cost
    fixed_period = fixed * days / 30
    live = s.scalar(select(func.count()).select_from(Site).where(Site.status == "live")) or 0
    expired = s.scalar(select(func.count()).select_from(Site).where(Site.status == "expired")) or 0
    monthly_plans = s.scalars(select(Plan).where(Plan.period == "monthly")).all()
    from app.subscriptions import lapsed, mrr
    sub_mrr, sub_active = mrr(s)
    sub_lapsed = lapsed(s, days)
    page = s.get(Plan, "page")
    unit = avg or ((page.price_kop / 100) if page else 0)
    remaining = max(TARGET_RUB - max(revenue, sub_mrr), 0)
    return {
        "days": days, "revenue": revenue, "orders": len(orders), "avg_check": avg, "by_plan": by_plan,
        "fees": fees, "fees_set": fee_set, "ai_calls": ai_calls, "ai_cost": ai_total, "ai_set": ai_set,
        "fixed": fixed_period, "fixed_set": fixed_set, "profit_estimate": revenue - fees - ai_total - fixed_period,
        "mrr": sub_mrr, "active_subscriptions": sub_active, "lapsed_subscriptions": sub_lapsed,
        "subscription_churn_pct": round(100 * sub_lapsed / (sub_active + sub_lapsed), 1) if (sub_active + sub_lapsed) else 0.0,
        "monthly_plans": monthly_plans,
        "live_sites": live, "expired_sites": expired,
        "churn_pct": round(100 * expired / (live + expired), 1) if (live + expired) else 0.0,
        "target": TARGET_RUB, "target_pct": round(100 * revenue / TARGET_RUB, 2),
        "sales_needed": int(-(-remaining // unit)) if unit else None, "unit_for_target": unit,
        "funnel": funnel(days),
    }
