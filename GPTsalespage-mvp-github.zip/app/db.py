"""Подключение к PostgreSQL и сессии с изоляцией по владельцу (RLS).

user_session(user_id)  — транзакция владельца: SET LOCAL app.user_id, политики RLS
                         пропускают только его строки.
system_session()       — транзакция системы (воркер, webhook, публичный приём заявок,
                         админка): SET LOCAL app.bypass = on. Используется только в
                         серверном коде, никогда для запросов владельца.
"""
from __future__ import annotations

import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from typing import Iterator

from sqlalchemy import create_engine, text
from sqlalchemy.engine import Engine
from sqlalchemy.orm import DeclarativeBase, Session

from app.config import get_settings


class Base(DeclarativeBase):
    pass


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def new_id() -> uuid.UUID:
    return uuid.uuid4()


_engine: Engine | None = None


def engine() -> Engine:
    global _engine
    if _engine is None:
        _engine = create_engine(get_settings().DATABASE_URL, pool_pre_ping=True, pool_size=10, max_overflow=10)
    return _engine


def reset_engine(url: str | None = None) -> None:
    """Для тестов: переподключиться к другой базе."""
    global _engine
    if _engine is not None:
        _engine.dispose()
    _engine = create_engine(url, pool_pre_ping=True) if url else None


@contextmanager
def user_session(user_id: uuid.UUID | str) -> Iterator[Session]:
    with Session(engine(), expire_on_commit=False) as s:
        with s.begin():
            s.execute(text("SELECT set_config('app.user_id', :u, true)"), {"u": str(user_id)})
            yield s


@contextmanager
def system_session() -> Iterator[Session]:
    with Session(engine(), expire_on_commit=False) as s:
        with s.begin():
            s.execute(text("SELECT set_config('app.bypass', 'on', true)"))
            yield s


@contextmanager
def anonymous_session() -> Iterator[Session]:
    """Без владельца и без обхода: клиентские таблицы недоступны (RLS вернёт пусто)."""
    with Session(engine(), expire_on_commit=False) as s:
        with s.begin():
            yield s
