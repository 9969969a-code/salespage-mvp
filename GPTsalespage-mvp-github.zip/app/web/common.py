"""Общие помощники веб-слоя: шаблоны, IP клиента, лимиты частоты, проверка CSRF."""
from __future__ import annotations

from typing import Any, Optional

from fastapi import Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

from app.config import BASE_DIR, get_settings
from app.security import Actor, check_csrf
from app.utils import RateLimiter, format_phone

templates = Jinja2Templates(directory=str(BASE_DIR / "templates" / "platform"))
templates.env.globals["format_phone"] = format_phone

STATUS_RU = {
    "draft": "Черновик", "ready": "Готов к оплате", "publishing": "Публикуется", "live": "Опубликован",
    "suspended": "Приостановлен", "expired": "Срок размещения истёк", "archived": "Архив",
}
GEN_RU = {"idle": "не запускалась", "queued": "в очереди", "running": "идёт", "done": "готово", "failed": "ошибка"}
templates.env.globals.update(STATUS_RU=STATUS_RU, GEN_RU=GEN_RU)

lead_limiter = RateLimiter(get_settings().LEAD_RATE_LIMIT_PER_MIN, 60)
login_limiter = RateLimiter(get_settings().LOGIN_RATE_LIMIT_PER_MIN, 60)
event_limiter = RateLimiter(120, 60)
abuse_limiter = RateLimiter(3, 600)
support_limiter = RateLimiter(5, 3600)


def client_ip(request: Request) -> str:
    """За Caddy настоящий адрес приходит в X-Real-IP (Caddy перезаписывает заголовок сам)."""
    import os
    if get_settings().is_production or os.getenv("TRUST_PROXY", "").lower() == "true":  # за Caddy (стенд или боевой)
        real = request.headers.get("x-real-ip")
        if real:
            return real.strip()[:64]
    return request.client.host if request.client else "unknown"


def render(request: Request, name: str, ctx: Optional[dict[str, Any]] = None, actor: Optional[Actor] = None,
           status_code: int = 200) -> HTMLResponse:
    st = get_settings()
    data = {"request": request, "actor": actor, "settings": st, "test_mode": not st.is_production}
    data.update(ctx or {})
    return templates.TemplateResponse(request, name, data, status_code=status_code)


async def form_with_csrf(request: Request, actor: Actor) -> dict[str, Any]:
    """Читает форму и проверяет CSRF (поле csrf или заголовок X-CSRF-Token)."""
    form = await request.form()
    supplied = request.headers.get("x-csrf-token") or form.get("csrf")
    check_csrf(actor, str(supplied) if supplied else None)
    return {k: v for k, v in form.multi_items()}
