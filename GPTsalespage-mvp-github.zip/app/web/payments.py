"""Webhook платёжного провайдера и Telegram, тестовая страница оплаты.

Тестовая страница оплаты существует только в тестовом режиме с PAYMENT_PROVIDER=fake.
Она не списывает деньги: имитирует решение провайдера и отправляет подписанный webhook
по тому же пути, что и настоящий провайдер (проверка подписи, очередь, сверка по API).
"""
from __future__ import annotations

import json

from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse, JSONResponse, PlainTextResponse, RedirectResponse
from sqlalchemy import select

from app.billing import FakePaymentProvider, handle_webhook
from app.config import get_settings
from app.db import system_session
from app.models import FakeProviderPayment, Order, Payment
from app.notify import handle_telegram_update
from app.utils import hmac_hex
from app.web.common import render

router = APIRouter()


def _fake_enabled() -> bool:
    st = get_settings()
    return st.PAYMENT_PROVIDER == "fake" and not st.is_production


@router.get("/test-checkout/{pid}", response_class=HTMLResponse)
def test_checkout(request: Request, pid: str):
    if not _fake_enabled():
        return PlainTextResponse("Not found", status_code=404)
    with system_session() as s:
        p = s.get(FakeProviderPayment, pid[:64])
        if p is None:
            return PlainTextResponse("Not found", status_code=404)
        amount, status = p.amount_kop // 100, p.status
        order_ref = p.order_ref
    return render(request, "checkout_test.html", {"pid": pid, "amount": amount, "status": status, "order_ref": order_ref})


@router.post("/test-checkout/{pid}")
async def test_checkout_submit(request: Request, pid: str):
    if not _fake_enabled():
        return PlainTextResponse("Not found", status_code=404)
    form = await request.form()
    status = "succeeded" if form.get("action") == "pay" else "canceled"
    provider = FakePaymentProvider()
    with system_session() as s:
        p = s.get(FakeProviderPayment, pid[:64])
        if p is None or p.status != "pending":
            return PlainTextResponse("Платёж уже обработан", status_code=409)
        order_ref = p.order_ref
    body = provider.simulate(pid, status)
    sig = hmac_hex(get_settings().PAYMENT_WEBHOOK_SECRET, body)
    handle_webhook("fake", {"x-fake-signature": sig}, body)  # тот же вход, что у настоящего webhook
    return RedirectResponse(f"/cabinet/orders/{order_ref}", status_code=303)


@router.get("/webhooks/payments/{provider}")
def payment_callback_get(request: Request, provider: str):
    """Сбербанк присылает уведомление GET-запросом: параметры передаются как тело для общей проверки."""
    code, text = handle_webhook(provider[:32], dict(request.headers), request.url.query.encode()[:8192])
    return PlainTextResponse(text, status_code=code)


@router.post("/webhooks/payments/{provider}")
async def payment_webhook(request: Request, provider: str):
    body = await request.body()
    if len(body) > 64 * 1024:
        return PlainTextResponse("too large", status_code=413)
    code, text = handle_webhook(provider[:32], dict(request.headers), body)
    return PlainTextResponse(text, status_code=code)


@router.post("/webhooks/telegram")
async def telegram_webhook(request: Request):
    body = await request.body()
    if len(body) > 256 * 1024:
        return PlainTextResponse("too large", status_code=413)
    try:
        data = json.loads(body or b"{}")
    except ValueError:
        return PlainTextResponse("bad json", status_code=400)
    code, text = handle_telegram_update(request.headers.get("x-telegram-bot-api-secret-token", ""), data)
    return PlainTextResponse(text, status_code=code)


@router.get("/cabinet/orders/{order_id}/status")
def order_status(request: Request, order_id: str):
    from app.security import require_user
    from app.db import user_session
    import uuid as _uuid
    actor = require_user(request)
    try:
        oid = _uuid.UUID(order_id)
    except ValueError:
        return JSONResponse({"error": "not found"}, status_code=404)
    with user_session(actor.user_id) as s:
        o = s.get(Order, oid)
        if o is None:
            return JSONResponse({"error": "not found"}, status_code=404)
        pay = s.scalar(select(Payment).where(Payment.order_id == o.id).order_by(Payment.created_at.desc()))
        from app.models import Site
        site = s.get(Site, o.site_id)
        return {"order": o.status, "payment": pay.status if pay else None, "site": site.status}
