"""Вход: VK ID (OAuth 2.1 + PKCE) и тестовый вход для разработки.

ВАЖНО: обмен кода VK ID реализован по документации VK ID, но с реальным приложением
не проверялся (нет ключей). Тестовый вход работает только при APP_ENV != production
и DEV_LOGIN_ENABLED=True; это НЕ настоящая авторизация.
"""
from __future__ import annotations

import base64
import hashlib
import logging
import secrets
from datetime import timedelta
from urllib.parse import urlencode

import httpx
from fastapi import APIRouter, Request
from fastapi.responses import RedirectResponse
from sqlalchemy import delete, select

from app.analytics import platform_event
from app.config import get_settings
from app.db import system_session, utcnow
from app.models import AuthIdentity, OAuthState, User, UserConsent
from app.security import SESSION_COOKIE, audit, create_session, load_actor, revoke, set_session_cookie
from app.web.common import client_ip, form_with_csrf, login_limiter, render

log = logging.getLogger("salespage.auth")
router = APIRouter()
TERMS_VERSION = "draft-2026-10"
VK_AUTHORIZE = "https://id.vk.com/authorize"
VK_TOKEN = "https://id.vk.com/oauth2/auth"
VK_USER_INFO = "https://id.vk.com/oauth2/user_info"


def _login_user(provider: str, provider_user_id: str, display_name: str, request: Request, role: str = "owner") -> RedirectResponse:
    st = get_settings()
    with system_session() as s:
        ident = s.scalar(select(AuthIdentity).where(AuthIdentity.provider == provider,
                                                    AuthIdentity.provider_user_id == provider_user_id))
        if ident is None:
            if provider == "vk" and provider_user_id in st.admin_vk_ids:
                role = "admin"
            source = request.cookies.get("sp_src", "")[:64]
            user = User(display_name=display_name[:80] or "Пользователь", role=role, signup_source={"source": source or "direct"})
            s.add(user)
            s.flush()
            s.add(AuthIdentity(user_id=user.id, provider=provider, provider_user_id=provider_user_id))
            s.add(UserConsent(owner_id=user.id, doc_kind="terms", doc_version=TERMS_VERSION))
            platform_event(s, "signup", owner_id=user.id, ip=client_ip(request), ua=request.headers.get("user-agent", ""),
                           utm={"source": source})
            audit(s, "user.signup", actor_kind="user", actor_id=user.id, owner_id=user.id, entity_type="user",
                  entity_id=user.id, details={"provider": provider})
            from app.prospecting import mark_converted
            mark_converted(s, request.cookies.get("sp_ref", ""), user.id)
            user_id = user.id
        else:
            user = s.get(User, ident.user_id)
            if user.status != "active":
                return RedirectResponse("/login?error=blocked", status_code=303)
            user_id = user.id
        audit(s, "user.login", actor_kind="user", actor_id=user_id, owner_id=user_id, entity_type="user", entity_id=user_id,
              details={"provider": provider})
    raw = create_session(user_id)
    resp = RedirectResponse("/cabinet", status_code=303)
    set_session_cookie(resp, raw)
    return resp


@router.get("/login")
def login_page(request: Request, error: str = ""):
    st = get_settings()
    messages = {"blocked": "Аккаунт заблокирован.", "vk": "Не удалось войти через VK ID. Попробуйте ещё раз.",
                "rate": "Слишком много попыток входа, подождите минуту.", "vk_off": "Вход через VK ID ещё не подключён."}
    return render(request, "login.html", {
        "error": messages.get(error, ""),
        "vk_enabled": bool(st.VK_CLIENT_ID and st.VK_REDIRECT_URI),
        "dev_enabled": st.DEV_LOGIN_ENABLED and not st.is_production,
    }, actor=load_actor(request))


@router.post("/auth/dev")
async def dev_login(request: Request):
    st = get_settings()
    if not st.DEV_LOGIN_ENABLED or st.is_production:
        return RedirectResponse("/login", status_code=303)
    if not login_limiter.allow(client_ip(request)):
        return RedirectResponse("/login?error=rate", status_code=303)
    form = await request.form()
    name = str(form.get("name", "")).strip()[:60] or "Тестовый владелец"
    role = "admin" if form.get("role") == "admin" else "owner"
    return _login_user("dev", f"{role}:{name.lower()}", name, request, role)


def _pkce() -> tuple[str, str]:
    verifier = secrets.token_urlsafe(64)[:96]
    challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).rstrip(b"=").decode()
    return verifier, challenge


@router.get("/auth/vk/start")
def vk_start(request: Request):
    st = get_settings()
    if not (st.VK_CLIENT_ID and st.VK_REDIRECT_URI):
        return RedirectResponse("/login?error=vk_off", status_code=303)
    if not login_limiter.allow(client_ip(request)):
        return RedirectResponse("/login?error=rate", status_code=303)
    state = secrets.token_urlsafe(32)
    verifier, challenge = _pkce()
    with system_session() as s:
        s.execute(delete(OAuthState).where(OAuthState.created_at < utcnow() - timedelta(minutes=15)))
        s.add(OAuthState(state=state, code_verifier=verifier))
    q = urlencode({"response_type": "code", "client_id": st.VK_CLIENT_ID, "redirect_uri": st.VK_REDIRECT_URI,
                   "state": state, "code_challenge": challenge, "code_challenge_method": "S256",
                   "scope": "vkid.personal_info"})
    return RedirectResponse(f"{VK_AUTHORIZE}?{q}", status_code=303)


@router.get("/auth/vk/callback")
def vk_callback(request: Request, code: str = "", state: str = "", device_id: str = ""):
    st = get_settings()
    with system_session() as s:
        row = s.get(OAuthState, state) if state else None
        if row is None or row.created_at < utcnow() - timedelta(minutes=15):
            return RedirectResponse("/login?error=vk", status_code=303)
        verifier = row.code_verifier
        s.delete(row)  # state одноразовый
    try:
        tok = httpx.post(VK_TOKEN, data={"grant_type": "authorization_code", "code": code, "code_verifier": verifier,
                                         "client_id": st.VK_CLIENT_ID, "device_id": device_id,
                                         "redirect_uri": st.VK_REDIRECT_URI, "state": state}, timeout=15).json()
        access, vk_user = tok.get("access_token"), str(tok.get("user_id") or "")
        if not access or not vk_user:
            raise ValueError("нет access_token или user_id")
        info = httpx.post(VK_USER_INFO, data={"client_id": st.VK_CLIENT_ID, "access_token": access}, timeout=15).json()
        user = info.get("user") or {}
        name = " ".join(x for x in (user.get("first_name"), user.get("last_name")) if x) or "Пользователь VK"
    except (httpx.HTTPError, ValueError) as exc:
        log.warning("VK ID: ошибка обмена кода: %s", exc.__class__.__name__)
        return RedirectResponse("/login?error=vk", status_code=303)
    return _login_user("vk", vk_user, name, request)


@router.post("/logout")
async def logout(request: Request):
    actor = load_actor(request)
    if actor is not None:
        await form_with_csrf(request, actor)
        revoke(actor)
    resp = RedirectResponse("/", status_code=303)
    resp.delete_cookie(SESSION_COOKIE, path="/")
    return resp
