"""Личный кабинет владельца. Все запросы к данным идут через user_session (RLS по владельцу)."""
from __future__ import annotations

import uuid
from typing import Optional

from fastapi import APIRouter, Request, UploadFile
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse, Response
from sqlalchemy import func, select

from app import assistant, dialog, sitegen
from app.analytics import owner_stats, platform_event
from app.billing import BillingError, create_order
from app.config import get_settings
from app.content import ILLUSTRATIONS
from app.db import user_session, utcnow
from app.jobs import enqueue
from app.models import (Plan, Asset, Conversation, Lead, Message, NotificationChannel, Order, Payment, Project, Site,
                        SiteVersion, SupportTicket, UpgradeRequest)
from app.notify import create_link, notify_operator
from app.render import render_site, site_pages
from app.security import audit, require_user
from app.uploads import UploadError, read_stored, store_image
from app.web.common import client_ip, form_with_csrf, render, support_limiter

router = APIRouter(prefix="/cabinet")


def _uuid(value: str) -> Optional[uuid.UUID]:
    try:
        return uuid.UUID(str(value))
    except ValueError:
        return None


def _site(s, site_id: str) -> Optional[Site]:
    sid = _uuid(site_id)
    return s.get(Site, sid) if sid else None  # чужой сайт не виден из-за RLS: get вернёт None


def _not_found(request: Request, actor) -> HTMLResponse:
    return render(request, "error.html", {"title": "Не найдено", "text": "Такого объекта нет в вашем аккаунте."},
                  actor=actor, status_code=404)


def _json(ok: bool, message: str, **extra) -> JSONResponse:
    return JSONResponse({"ok": ok, "message": message, **extra}, status_code=200 if ok else 400)


# ------------------------------------------------------------------ главная кабинета
@router.get("", response_class=HTMLResponse)
def dashboard(request: Request):
    actor = require_user(request)
    since = utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
    with user_session(actor.user_id) as s:
        rows = s.execute(select(Site, Project).join(Project, Project.id == Site.project_id)
                         .order_by(Site.created_at.desc())).all()
        leads_new = dict(s.execute(select(Lead.site_id, func.count()).where(Lead.status == "new").group_by(Lead.site_id)).all())
        tg = s.scalar(select(NotificationChannel).where(NotificationChannel.kind == "telegram",
                                                        NotificationChannel.status == "verified"))
    sites = [{"site": site, "project": proj, "new_leads": leads_new.get(site.id, 0),
              "url": get_settings().site_url(site.slug) if site.status == "live" else ""} for site, proj in rows]
    return render(request, "dashboard.html", {"sites": sites, "telegram": tg, "since": since}, actor=actor)


@router.post("/projects")
async def new_project(request: Request):
    actor = require_user(request)
    await form_with_csrf(request, actor)
    with user_session(actor.user_id) as s:
        count = s.scalar(select(func.count()).select_from(Project)) or 0
        if count >= 10:
            return RedirectResponse("/cabinet?error=limit", status_code=303)
        _, _, site = dialog.start_project(s, actor.user_id)
        platform_event(s, "project_created", owner_id=actor.user_id)
        site_id = site.id
    return RedirectResponse(f"/cabinet/sites/{site_id}", status_code=303)


# ------------------------------------------------------------------ редактор
def _editor_state(s, site: Site) -> dict:
    proj = s.get(Project, site.project_id)
    conv = s.scalar(select(Conversation).where(Conversation.project_id == proj.id))
    msgs = s.scalars(select(Message).where(Message.conversation_id == conv.id).order_by(Message.created_at)).all()
    facts = dialog.facts_of(s, proj.business_id)
    versions = s.scalars(select(SiteVersion).where(SiteVersion.site_id == site.id).order_by(SiteVersion.number.desc())).all()
    current = s.get(SiteVersion, site.current_version_id) if site.current_version_id else None
    assets = s.scalars(select(Asset).where(Asset.site_id == site.id).order_by(Asset.created_at)).all()
    order = s.scalar(select(Order).where(Order.site_id == site.id).order_by(Order.created_at.desc()))
    q = dialog.current_question(conv)
    return {"site": site, "project": proj, "conv": conv, "messages": msgs, "facts": facts, "versions": versions,
            "current": current, "assets": assets, "question": q, "order": order,
            "checklist": sitegen.publish_checklist(s, site) if current else [],
            "claims": sitegen.claims_for_review(current.content) if current else [],
            "missing": sitegen.missing_facts(facts), "illustrations": ILLUSTRATIONS,
            "questions": dialog.QUESTIONS, "site_url": get_settings().site_url(site.slug),
            "mode": "dialog" if q else ("edit" if current else "generate"),
            "plan_price": (s.get(Plan, site.plan_code).price_kop // 100) if s.get(Plan, site.plan_code) else None,
            "plans": [p for p in s.scalars(select(Plan).where(Plan.code.in_(("page", "site")))).all() if p.purchasable],
            "pages": site_pages(current.content) if (current and site.plan_code == "site") else []}


@router.get("/sites/{site_id}", response_class=HTMLResponse)
def editor(request: Request, site_id: str):
    actor = require_user(request)
    with user_session(actor.user_id) as s:
        site = _site(s, site_id)
        if site is None:
            return _not_found(request, actor)
        ctx = _editor_state(s, site)
    return render(request, "editor.html", ctx, actor=actor)


@router.get("/sites/{site_id}/state")
def site_state(request: Request, site_id: str):
    actor = require_user(request)
    with user_session(actor.user_id) as s:
        site = _site(s, site_id)
        if site is None:
            return JSONResponse({"error": "not found"}, status_code=404)
        v = s.get(SiteVersion, site.current_version_id) if site.current_version_id else None
        return {"status": site.status, "generation_status": site.generation_status, "generation_error": site.generation_error,
                "version": v.number if v else None, "confirmed": bool(v and v.owner_confirmed_at)}


@router.post("/sites/{site_id}/answer")
async def answer(request: Request, site_id: str):
    actor = require_user(request)
    form = await form_with_csrf(request, actor)
    with user_session(actor.user_id) as s:
        site = _site(s, site_id)
        if site is None:
            return _json(False, "Не найдено")
        conv = s.scalar(select(Conversation).where(Conversation.project_id == site.project_id))
        text = str(form.get("text", ""))
        first = s.scalar(select(func.count()).select_from(Message).where(Message.conversation_id == conv.id,
                                                                         Message.role == "user")) == 0
        # первое длинное сообщение — описание бизнеса целиком; короткое — ответ на вопрос о названии
        if first and len(text.strip()) >= 40:
            reply = dialog.start_from_prompt(s, actor.user_id, conv, text)
        else:
            reply = dialog.answer(s, actor.user_id, conv, text)
        q = reply.question
    return _json(reply.ok, reply.message, done=reply.done,
                 chips=list(q.chips) if q else [], multi=bool(q and q.multi), optional=bool(q and q.optional))


@router.post("/sites/{site_id}/facts")
async def update_facts(request: Request, site_id: str):
    actor = require_user(request)
    form = await form_with_csrf(request, actor)
    values = {k: str(v) for k, v in form.items() if k in dialog.QUESTION_KEYS}
    with user_session(actor.user_id) as s:
        site = _site(s, site_id)
        if site is None:
            return _json(False, "Не найдено")
        errors = dialog.update_facts(s, actor.user_id, s.get(Project, site.project_id).business_id, values)
    return _json(not errors, "Сохранено." if not errors else "; ".join(errors))


@router.post("/sites/{site_id}/generate")
async def generate(request: Request, site_id: str):
    actor = require_user(request)
    await form_with_csrf(request, actor)
    with user_session(actor.user_id) as s:
        site = _site(s, site_id)
        if site is None:
            return _json(False, "Не найдено")
        missing = sitegen.missing_facts(dialog.facts_of(s, s.get(Project, site.project_id).business_id))
        if missing:
            return _json(False, "Сначала ответьте на вопросы: не хватает сведений (" + ", ".join(missing) + ").")
        if site.generation_status in ("queued", "running"):
            return _json(True, "Сайт уже создаётся.")
    try:
        sitegen.check_ai_budget(actor.user_id, "generate")
    except sitegen.LimitReached as exc:
        return _json(False, str(exc))
    with user_session(actor.user_id) as s:
        site = _site(s, site_id)
        site.generation_status, site.generation_error = "queued", ""
        enqueue(s, "generate_site", {"site_id": str(site.id), "owner_id": str(actor.user_id)},
                dedupe_key=f"gen:{site.id}:{utcnow():%Y%m%d%H%M%S}")
    return _json(True, "Создаю сайт. Обычно это занимает до минуты.")


@router.post("/sites/{site_id}/edit")
async def edit(request: Request, site_id: str):
    actor = require_user(request)
    form = await form_with_csrf(request, actor)
    with user_session(actor.user_id) as s:
        site = _site(s, site_id)
        if site is None:
            return _json(False, "Не найдено")
        command = str(form.get("command", ""))[:600]
        kind = assistant.classify(command)
        if kind == "offtopic":  # отказ по теме — штатный ответ, а не ошибка запроса
            return JSONResponse({"ok": False, "message": assistant.OFFTOPIC_REPLY, "kind": "offtopic"})
        if kind == "question" and assistant.is_question(command):
            return _json(True, assistant.answer(command), kind="answer")
        try:
            ok, msg = sitegen.apply_edit(s, site, command)
        except sitegen.LimitReached as exc:
            return _json(False, str(exc))
    return _json(ok, msg, kind="edit")


@router.post("/sites/{site_id}/rollback")
async def rollback(request: Request, site_id: str):
    actor = require_user(request)
    form = await form_with_csrf(request, actor)
    vid = _uuid(str(form.get("version_id", "")))
    with user_session(actor.user_id) as s:
        site = _site(s, site_id)
        if site is None or vid is None:
            return _json(False, "Не найдено")
        ok, msg = sitegen.rollback(s, site, vid)
    return _json(ok, msg)


@router.post("/sites/{site_id}/confirm")
async def confirm(request: Request, site_id: str):
    actor = require_user(request)
    await form_with_csrf(request, actor)
    with user_session(actor.user_id) as s:
        site = _site(s, site_id)
        if site is None:
            return _json(False, "Не найдено")
        ok, msg = sitegen.confirm_version(s, site)
    return _json(ok, msg)


@router.post("/sites/{site_id}/hero")
async def hero(request: Request, site_id: str):
    actor = require_user(request)
    form = await form_with_csrf(request, actor)
    with user_session(actor.user_id) as s:
        site = _site(s, site_id)
        if site is None:
            return _json(False, "Не найдено")
        ok, msg = sitegen.set_hero_image(s, site, str(form.get("ref", "")) or None)
    return _json(ok, msg)


@router.post("/sites/{site_id}/photos")
async def upload_photo(request: Request, site_id: str):
    actor = require_user(request)
    form = await form_with_csrf(request, actor)
    file = form.get("photo")
    if not isinstance(file, UploadFile) and not hasattr(file, "read"):
        return _json(False, "Выберите файл.")
    data = await file.read(8 * 1024 * 1024 + 1)
    with user_session(actor.user_id) as s:
        site = _site(s, site_id)
        if site is None:
            return _json(False, "Не найдено")
        if (s.scalar(select(func.count()).select_from(Asset).where(Asset.site_id == site.id)) or 0) >= 20:
            return _json(False, "Можно загрузить не больше 20 фото на сайт.")
        try:
            path, w, h, size, digest = store_image(actor.user_id, site.id, data)
        except UploadError as exc:
            return _json(False, str(exc))
        asset = Asset(owner_id=actor.user_id, site_id=site.id, storage_path=path, width=w, height=h, bytes=size, sha256=digest)
        s.add(asset)
        s.flush()
        asset_id = asset.id
        if site.current_version_id and str(form.get("as_hero", "")) == "1":
            sitegen.set_hero_image(s, site, f"asset:{asset_id}")
    return _json(True, "Фото загружено.", asset_id=str(asset_id))


@router.get("/assets/{asset_id}")
def asset(request: Request, asset_id: str):
    actor = require_user(request)
    aid = _uuid(asset_id)
    with user_session(actor.user_id) as s:
        a = s.get(Asset, aid) if aid else None
        if a is None:
            return Response(status_code=404)
        path = a.storage_path
    return Response(read_stored(path), media_type="image/webp", headers={"Cache-Control": "private, max-age=3600"})


def _preview(s, site: Site, page: str = "index") -> tuple[str, str]:
    v = s.get(SiteVersion, site.current_version_id)
    facts = dialog.facts_of(s, s.get(Project, site.project_id).business_id)

    def image_url(ref: Optional[str]) -> str:
        if not ref:
            return ""
        kind, _, value = ref.partition(":")
        return f"/cabinet/assets/{value}" if kind == "asset" else f"/static/illustrations/{value}.svg"

    st = get_settings()
    return render_site(v.content, facts, mode="preview", image_url=image_url, base_url=st.site_url(site.slug),
                       asset_prefix="/legal/", css_url=f"/cabinet/sites/{site.id}/preview.css",
                       operator={"name": st.OPERATOR_NAME, "inn": st.OPERATOR_INN, "email": st.OPERATOR_EMAIL},
                       multipage=site.plan_code == "site", page=page,
                       nav_href=lambda key, path: f"/cabinet/sites/{site.id}/preview?page={key}")[:2]


@router.get("/sites/{site_id}/preview", response_class=HTMLResponse)
def preview(request: Request, site_id: str, page: str = "index"):
    actor = require_user(request)
    with user_session(actor.user_id) as s:
        site = _site(s, site_id)
        if site is None or site.current_version_id is None:
            return HTMLResponse("<p style='font-family:system-ui;padding:24px'>Сайт ещё не создан.</p>", status_code=404)
        html, _ = _preview(s, site, page[:16])
    return HTMLResponse(html, headers={"X-Robots-Tag": "noindex, nofollow", "Cache-Control": "no-store"})


@router.get("/sites/{site_id}/preview.css")
def preview_css(request: Request, site_id: str):
    actor = require_user(request)
    with user_session(actor.user_id) as s:
        site = _site(s, site_id)
        if site is None or site.current_version_id is None:
            return Response(status_code=404)
        _, css = _preview(s, site)
    return Response(css, media_type="text/css", headers={"Cache-Control": "no-store"})


@router.post("/sites/{site_id}/plan")
async def choose_plan(request: Request, site_id: str):
    """Выбор тарифа до оплаты: лендинг (page) или многостраничный сайт (site)."""
    actor = require_user(request)
    form = await form_with_csrf(request, actor)
    code = str(form.get("plan_code", ""))
    with user_session(actor.user_id) as s:
        site = _site(s, site_id)
        if site is None:
            return _json(False, "Не найдено")
        p = s.get(Plan, code)
        if p is None or not p.purchasable or code not in ("page", "site"):
            return _json(False, "Такой тариф недоступен.")
        if s.scalar(select(Order).where(Order.site_id == site.id, Order.status == "paid", Order.kind == "initial")):
            return _json(False, "Тариф уже оплачен. Смена тарифа после оплаты — через поддержку.")
        site.plan_code = code
    return _json(True, f"Выбран тариф «{p.name}» за {p.price_kop // 100} ₽.")


@router.post("/sites/{site_id}/republish")
async def republish(request: Request, site_id: str):
    """Публикация правок в оплаченный период: без новой оплаты, только подтверждённая версия."""
    from app.publishing import queue_publication, site_paid
    from app.models import Publication
    actor = require_user(request)
    await form_with_csrf(request, actor)
    with user_session(actor.user_id) as s:
        site = _site(s, site_id)
        if site is None:
            return _json(False, "Не найдено")
        v = s.get(SiteVersion, site.current_version_id) if site.current_version_id else None
        if site.status != "live" or not site_paid(s, site):
            return _json(False, "Сайт не опубликован или срок размещения истёк.")
        if v is None or v.owner_confirmed_at is None:
            return _json(False, "Сначала подтвердите текущую версию.")
        if v.id == site.published_version_id:
            return _json(False, "Эта версия уже опубликована.")
        busy = s.scalar(select(Publication).where(Publication.site_id == site.id,
                                                  Publication.status.in_(("queued", "building"))))
        if busy:
            return _json(True, "Публикация уже идёт.")
        paid = s.scalar(select(Order).where(Order.site_id == site.id, Order.status == "paid").order_by(Order.paid_at.desc()))
        queue_publication(s, site, v.id, paid.id if paid else None)
        audit(s, "site.republish_requested", actor_kind="user", actor_id=actor.user_id, owner_id=actor.user_id,
              entity_type="site", entity_id=site.id, details={"version": v.number})
    return _json(True, "Публикую изменения. Обычно это занимает до минуты.")


# ------------------------------------------------------------------ оплата
@router.post("/sites/{site_id}/pay")
async def pay(request: Request, site_id: str):
    actor = require_user(request)
    form = await form_with_csrf(request, actor)
    kind = "renewal" if form.get("kind") == "renewal" else "initial"
    if form.get("accept_terms") != "yes":
        return RedirectResponse(f"/cabinet/sites/{site_id}?error=terms", status_code=303)
    with user_session(actor.user_id) as s:
        site = _site(s, site_id)
        if site is None:
            return _not_found(request, actor)
        try:
            order, payment = create_order(s, site, kind)
        except BillingError as exc:
            return RedirectResponse(f"/cabinet/sites/{site_id}?error=" + str(exc)[:120], status_code=303)
        url = payment.confirmation_url
    return RedirectResponse(url, status_code=303)


@router.get("/orders/{order_id}", response_class=HTMLResponse)
def order_page(request: Request, order_id: str):
    actor = require_user(request)
    oid = _uuid(order_id)
    with user_session(actor.user_id) as s:
        order = s.get(Order, oid) if oid else None
        if order is None:
            return _not_found(request, actor)
        site = s.get(Site, order.site_id)
        pay = s.scalar(select(Payment).where(Payment.order_id == order.id).order_by(Payment.created_at.desc()))
    return render(request, "order.html", {"order": order, "site": site, "payment": pay,
                                          "site_url": get_settings().site_url(site.slug)}, actor=actor)


@router.get("/billing", response_class=HTMLResponse)
def billing(request: Request):
    actor = require_user(request)
    with user_session(actor.user_id) as s:
        rows = s.execute(select(Order, Site).join(Site, Site.id == Order.site_id).order_by(Order.created_at.desc())).all()
    return render(request, "billing.html", {"orders": rows}, actor=actor)


# ------------------------------------------------------------------ заявки и аналитика
@router.get("/leads", response_class=HTMLResponse)
def leads(request: Request, status: str = ""):
    actor = require_user(request)
    with user_session(actor.user_id) as s:
        q = select(Lead, Site).join(Site, Site.id == Lead.site_id).order_by(Lead.created_at.desc()).limit(500)
        if status in ("new", "in_progress", "done", "spam"):
            q = q.where(Lead.status == status)
        rows = s.execute(q).all()
    return render(request, "leads.html", {"rows": rows, "status": status}, actor=actor)


@router.post("/leads/{lead_id}/status")
async def lead_status(request: Request, lead_id: str):
    actor = require_user(request)
    form = await form_with_csrf(request, actor)
    new = str(form.get("status", ""))
    lid = _uuid(lead_id)
    with user_session(actor.user_id) as s:
        lead = s.get(Lead, lid) if lid else None
        if lead is None or new not in ("new", "in_progress", "done", "spam"):
            return _json(False, "Не найдено")
        lead.status = new
    return RedirectResponse("/cabinet/leads", status_code=303)


@router.get("/analytics", response_class=HTMLResponse)
def analytics(request: Request):
    actor = require_user(request)
    with user_session(actor.user_id) as s:
        sites = s.scalars(select(Site).order_by(Site.created_at.desc())).all()
        stats = [(site, owner_stats(s, site.id)) for site in sites]
    return render(request, "analytics.html", {"stats": stats}, actor=actor)


# ------------------------------------------------------------------ настройки, поддержка, тарифы 2–3
@router.get("/settings", response_class=HTMLResponse)
def settings_page(request: Request, link: str = ""):
    actor = require_user(request)
    with user_session(actor.user_id) as s:
        channels = s.scalars(select(NotificationChannel).where(NotificationChannel.status != "removed")).all()
    return render(request, "settings.html", {"channels": channels, "link": link}, actor=actor)


@router.post("/settings/telegram")
async def telegram_link(request: Request):
    actor = require_user(request)
    await form_with_csrf(request, actor)
    with user_session(actor.user_id) as s:
        link = create_link(s, actor.user_id)
        audit(s, "telegram.link_created", actor_kind="user", actor_id=actor.user_id, owner_id=actor.user_id)
    return render(request, "settings.html", {"channels": [], "link": link, "fresh": True}, actor=actor)


@router.get("/support", response_class=HTMLResponse)
def support(request: Request, sent: str = ""):
    actor = require_user(request)
    with user_session(actor.user_id) as s:
        tickets = s.scalars(select(SupportTicket).order_by(SupportTicket.created_at.desc())).all()
    return render(request, "support.html", {"tickets": tickets, "sent": sent}, actor=actor)


@router.post("/support")
async def support_create(request: Request):
    actor = require_user(request)
    form = await form_with_csrf(request, actor)
    if not support_limiter.allow(str(actor.user_id)):
        return RedirectResponse("/cabinet/support?sent=limit", status_code=303)
    subject, body = str(form.get("subject", "")).strip()[:120], str(form.get("body", "")).strip()[:4000]
    if len(subject) < 3 or len(body) < 10:
        return RedirectResponse("/cabinet/support?sent=short", status_code=303)
    with user_session(actor.user_id) as s:
        t = SupportTicket(owner_id=actor.user_id, subject=subject, body=body)
        s.add(t)
        s.flush()
        notify_operator(s, f"Обращение в поддержку: {subject}", f"ticket:{t.id}")
    return RedirectResponse("/cabinet/support?sent=1", status_code=303)


@router.post("/upgrade")
async def upgrade(request: Request):
    actor = require_user(request)
    form = await form_with_csrf(request, actor)
    plan_code = str(form.get("plan_code", ""))
    if plan_code not in ("site", "growth", "pro"):
        return RedirectResponse("/cabinet", status_code=303)
    with user_session(actor.user_id) as s:
        r = UpgradeRequest(owner_id=actor.user_id, plan_code=plan_code, contact=str(form.get("contact", ""))[:120],
                           comment=str(form.get("comment", ""))[:1000])
        s.add(r)
        s.flush()
        notify_operator(s, f"Заявка на подключение тарифа {plan_code}", f"upgrade:{r.id}")
    return RedirectResponse("/cabinet/support?sent=upgrade", status_code=303)


# ------------------------------------------------------------------ продвижение
@router.get("/promotion", response_class=HTMLResponse)
def promotion_page(request: Request, site: str = "", msg: str = ""):
    from app import promotion
    from app.models import ClientOutreach, ClientProspect
    actor = require_user(request)
    with user_session(actor.user_id) as s:
        live = s.scalars(select(Site).where(Site.status == "live").order_by(Site.created_at.desc())).all()
        current = next((x for x in live if str(x.id) == site), live[0] if live else None)
        from app.subscriptions import is_active
        ctx = {"sites": live, "site": current, "msg": msg, "categories": promotion.CATEGORIES,
               "monthly": s.scalars(select(Plan).where(Plan.period == "monthly", Plan.purchasable.is_(True))
                                    .order_by(Plan.price_kop)).all(),
               "service": {"active": bool(current and is_active(current)),
                           "plan": s.get(Plan, current.service_plan) if current and current.service_plan else None,
                           "until": current.service_paid_until if current else None}}
        if current is not None:
            facts = dialog.facts_of(s, s.get(Project, current.project_id).business_id)
            ctx.update(links=promotion.tracked_links(current), stats=promotion.source_stats(s, current.id),
                       posts=promotion.posts(facts, get_settings().site_url(current.slug)),
                       pending=s.execute(select(ClientOutreach, ClientProspect).join(ClientProspect, ClientProspect.id == ClientOutreach.prospect_id)
                                         .where(ClientOutreach.site_id == current.id, ClientOutreach.status == "pending_review")).all(),
                       companies=s.scalars(select(ClientProspect).where(ClientProspect.site_id == current.id)
                                           .order_by(ClientProspect.created_at.desc()).limit(200)).all())
    return render(request, "promotion.html", ctx, actor=actor)


@router.post("/promotion/{site_id}/b2b")
async def promotion_b2b(request: Request, site_id: str):
    from app import promotion
    actor = require_user(request)
    form = await form_with_csrf(request, actor)
    with user_session(actor.user_id) as s:
        site = _site(s, site_id)
        if site is None or site.status != "live":
            return RedirectResponse("/cabinet/promotion?msg=Продвижение доступно для опубликованного сайта", status_code=303)
        import os
        from app.subscriptions import is_active
        if os.getenv("REQUIRE_SUBSCRIPTION_FOR_PROMOTION", "false").lower() == "true" and not is_active(site):
            return RedirectResponse(f"/cabinet/promotion?site={site.id}&msg=Поиск корпоративных клиентов доступен по подписке", status_code=303)
        facts = dialog.facts_of(s, s.get(Project, site.project_id).business_id)
        try:
            st = promotion.search_b2b(s, actor.user_id, site, facts, str(form.get("category", "")))
        except ValueError:
            return RedirectResponse(f"/cabinet/promotion?site={site.id}&msg=Неизвестная категория", status_code=303)
    m = f"Найдено {st['found']}, писем на одобрение {st['queued']}, без email {st['no_email']}, уже были {st['skipped']}"
    return RedirectResponse(f"/cabinet/promotion?site={site_id}&msg={m}", status_code=303)


@router.post("/promotion/outreach/{outreach_id}")
async def promotion_review(request: Request, outreach_id: str):
    from app import promotion
    from app.models import ClientOutreach
    actor = require_user(request)
    form = await form_with_csrf(request, actor)
    oid = _uuid(outreach_id)
    with user_session(actor.user_id) as s:
        m = s.get(ClientOutreach, oid) if oid else None
        site_id = m.site_id if m else ""
        ok, msg = promotion.review(s, actor.user_id, oid, form.get("decision") == "approve", str(form.get("body", ""))) if m else (False, "Письмо не найдено.")
    return RedirectResponse(f"/cabinet/promotion?site={site_id}&msg={msg}", status_code=303 if ok else 303)


@router.post("/sites/{site_id}/subscribe")
async def subscribe(request: Request, site_id: str):
    """Оформление или продление месячной подписки: заказ на сервере, оплата по ссылке."""
    actor = require_user(request)
    form = await form_with_csrf(request, actor)
    with user_session(actor.user_id) as s:
        site = _site(s, site_id)
        if site is None:
            return _not_found(request, actor)
        try:
            order, payment = create_order(s, site, "subscription", str(form.get("plan_code", "")))
        except BillingError as exc:
            return RedirectResponse(f"/cabinet/promotion?site={site_id}&msg={str(exc)[:120]}", status_code=303)
        url = payment.confirmation_url
    return RedirectResponse(url, status_code=303)
