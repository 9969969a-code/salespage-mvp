"""Отдача клиентских сайтов по адресу <slug>.<SITES_DOMAIN>.

В production статику отдаёт Caddy (deploy/Caddyfile), а /_lead, /_e и /_abuse он передаёт сюда.
В разработке это же приложение отдаёт и статику, поэтому сценарий проверяется целиком.
На домене сайтов не устанавливаются cookie, действует строгая политика CSP.
"""
from __future__ import annotations

import mimetypes
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, Response

from app.analytics import SITE_EVENTS, record_site_event
from app.config import get_settings
from app.leads import create_abuse_report, create_lead
from app.publishing import site_dir
from app.render import ENV
from app.utils import valid_slug
from app.web.common import abuse_limiter, client_ip, event_limiter, lead_limiter

CSP = ("default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; font-src 'self'; "
       "form-action 'self'; frame-ancestors 'none'; base-uri 'none'; object-src 'none'")
SECURITY_HEADERS = {"Content-Security-Policy": CSP, "X-Content-Type-Options": "nosniff",
                    "Referrer-Policy": "strict-origin-when-cross-origin", "X-Frame-Options": "DENY"}
TYPES = {".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8", ".js": "text/javascript; charset=utf-8",
         ".svg": "image/svg+xml", ".webp": "image/webp", ".png": "image/png", ".txt": "text/plain; charset=utf-8",
         ".xml": "application/xml; charset=utf-8", ".woff2": "font/woff2"}

sites_app = FastAPI(docs_url=None, redoc_url=None, openapi_url=None)


def is_sites_host(host: str) -> bool:
    """Любой хост домена клиентских сайтов, включая неверные поддомены."""
    host = (host or "").split(":")[0].lower()
    base = get_settings().sites_host_suffix
    return host.endswith(base) or host == base.lstrip(".")


def slug_from_host(host: str) -> str | None:
    host = (host or "").split(":")[0].lower()
    suffix = get_settings().sites_host_suffix
    if not host.endswith(suffix):
        return None
    slug = host[: -len(suffix)]
    return slug if valid_slug(slug) else None


def _message(title: str, text: str, status: int) -> HTMLResponse:
    html = ENV.get_template("message.html").render(title=title, text=text)
    return HTMLResponse(html, status_code=status, headers=SECURITY_HEADERS)


def _not_found() -> HTMLResponse:
    return _message("Страница не найдена", "Такой страницы нет или сайт ещё не опубликован.", 404)


@sites_app.middleware("http")
async def resolve_site(request: Request, call_next):
    slug = slug_from_host(request.headers.get("host", ""))
    if slug is None:
        return _not_found()
    request.state.slug = slug
    response = await call_next(request)
    for k, v in SECURITY_HEADERS.items():
        response.headers.setdefault(k, v)
    return response


@sites_app.post("/_lead")
async def lead(request: Request):
    if not lead_limiter.allow(client_ip(request)):
        return _message("Слишком много заявок", "Подождите минуту и попробуйте снова.", 429)
    form = {k: str(v) for k, v in (await request.form()).items()}
    form["_referrer"] = request.headers.get("referer", "")
    res = create_lead(request.state.slug, form, client_ip(request), request.headers.get("user-agent", ""))
    if res.ok:
        return _message("Заявка отправлена", res.message, 200)
    return _message("Заявка не отправлена", res.message, 400)


@sites_app.post("/_e")
async def event(request: Request):
    if not event_limiter.allow(client_ip(request)):
        return Response(status_code=204)
    form = await request.form()
    kind = str(form.get("k", ""))[:32]
    if kind in SITE_EVENTS and kind != "lead_submit":  # заявку учитывает только сервер
        record_site_event(request.state.slug, kind, client_ip(request), request.headers.get("user-agent", ""),
                          referrer=str(form.get("r", ""))[:500],
                          utm={"source": str(form.get("us", "")), "medium": str(form.get("um", "")),
                               "campaign": str(form.get("uc", ""))})
    return Response(status_code=204)


@sites_app.get("/_abuse")
def abuse_form():
    return HTMLResponse(ENV.get_template("abuse.html").render(), headers=SECURITY_HEADERS)


@sites_app.post("/_abuse")
async def abuse_submit(request: Request):
    if not abuse_limiter.allow(client_ip(request)):
        return _message("Слишком много обращений", "Попробуйте позже.", 429)
    form = await request.form()
    ok, msg = create_abuse_report(request.state.slug, str(form.get("reason", "")), str(form.get("contact", "")),
                                  str(form.get("website", "")))
    return _message("Жалоба отправлена" if ok else "Жалоба не отправлена", msg, 200 if ok else 400)


@sites_app.get("/{path:path}")
def static_file(request: Request, path: str):
    root = site_dir(request.state.slug) / "current"
    if not root.exists():
        return _not_found()
    base = root.resolve()
    target = (base / (path or "index.html")).resolve()
    if target.is_dir():
        target = target / "index.html"
    if not target.is_relative_to(base) or not target.is_file():
        return _not_found()
    ctype = TYPES.get(target.suffix.lower()) or mimetypes.guess_type(target.name)[0] or "application/octet-stream"
    cache = "no-cache" if target.suffix in (".html", ".xml", ".txt") else "public, max-age=3600"
    return Response(Path(target).read_bytes(), media_type=ctype, headers={"Cache-Control": cache})
