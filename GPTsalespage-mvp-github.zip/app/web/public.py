"""Публичная часть платформы: главная, пример сайта, юридические черновики, health-check."""
from __future__ import annotations

from functools import lru_cache

from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse, JSONResponse, Response
from sqlalchemy import func, select, text

from app.ai import FakeProvider
from app.analytics import platform_event
from app.config import get_settings
from app.content import validate_content
from app.db import engine, system_session, utcnow
from app.models import Job, Plan
from app.render import render_site
from app.security import load_actor
from app.web.common import client_ip, render

router = APIRouter()

# Пример построен на вымышленном магазине и помечен как пример на самой странице.
EXAMPLE_FACTS = {
    "name": "Пример: Цветочная лавка", "about": "Авторские букеты и доставка цветов", "city": "Санкт-Петербург",
    "assortment": "Авторские букеты; Розы; Композиции в коробках", "prices": "", "delivery": "",
    "payment": "Карта при получении; Перевод по СБП", "advantages": "Собираем букет под ваш повод; Фото букета перед отправкой",
    "audience": "Дарят цветы близким", "goal": "Оставить заявку", "phone": "79000000000", "whatsapp": "", "telegram": "",
    "address": "", "hours": "", "reviews": "", "style": "Нежный",
}


@lru_cache(maxsize=1)
def _example() -> tuple[str, str]:
    content, _ = validate_content(FakeProvider().generate(EXAMPLE_FACTS, "illustration:bouquet"))
    html, css, _ = render_site(content, EXAMPLE_FACTS, mode="preview",
                               image_url=lambda ref: f"/static/illustrations/{ref.split(':', 1)[1]}.svg" if ref else "",
                               base_url=get_settings().PUBLIC_BASE_URL + "/example", asset_prefix="/legal/",
                               css_url="/example/site.css", operator={})
    banner = ('<div style="position:sticky;top:0;z-index:9;background:#111827;color:#fff;font:600 14px/1.4 system-ui;'
              'padding:10px 16px;text-align:center">Пример сайта вымышленного магазина. Контакты и данные не настоящие.</div>')
    import re
    return re.sub(r"(<body[^>]*>)", lambda m: m.group(1) + banner, html, count=1), css


@router.get("/", response_class=HTMLResponse)
def landing(request: Request, utm_source: str = "", utm_medium: str = "", utm_campaign: str = "", ref: str = ""):
    with system_session() as s:
        plans = {p.code: p for p in s.scalars(select(Plan)).all()}
        platform_event(s, "platform_visit", ip=client_ip(request), ua=request.headers.get("user-agent", ""),
                       referrer=request.headers.get("referer", ""),
                       utm={"source": utm_source, "medium": utm_medium, "campaign": utm_campaign})
    resp = render(request, "landing.html", {"plans": plans, "hosting_months": get_settings().HOSTING_MONTHS},
                  actor=load_actor(request))
    if ref and not utm_source:
        utm_source = "outreach"
    if utm_source:  # источник прихода нужен для воронки регистраций; cookie только на домене платформы
        resp.set_cookie("sp_src", utm_source[:64], max_age=30 * 86400, httponly=True, samesite="lax")
    if ref:  # переход из письма: регистрация засчитается этому потенциальному клиенту
        resp.set_cookie("sp_ref", ref[:32], max_age=30 * 86400, httponly=True, samesite="lax")
    return resp


@router.get("/example", response_class=HTMLResponse)
def example():
    return HTMLResponse(_example()[0], headers={"X-Robots-Tag": "noindex"})


@router.get("/example/site.css")
def example_css():
    return Response(_example()[1], media_type="text/css")


@router.get("/legal/{doc}", response_class=HTMLResponse)
def legal(request: Request, doc: str):
    if doc not in ("terms", "privacy", "privacy.html"):
        return render(request, "error.html", {"title": "Не найдено", "text": "Документ не найден."}, status_code=404)
    return render(request, "legal.html", {"doc": "privacy" if doc.startswith("privacy") else "terms"},
                  actor=load_actor(request))


@router.get("/internal/tls-allowed")
def tls_allowed(request: Request, domain: str = ""):
    """Caddy спрашивает перед выпуском сертификата поддомена: выпускаем только для существующих сайтов."""
    from app.models import Site
    from app.web.sites_host import slug_from_host
    if (request.client.host if request.client else "") not in ("127.0.0.1", "::1"):
        return JSONResponse({"allowed": False}, status_code=403)
    slug = slug_from_host(domain)
    with system_session() as s:
        ok = slug is not None and s.scalar(select(Site.id).where(Site.slug == slug, Site.status.in_(("live", "suspended", "expired")))) is not None
    return JSONResponse({"allowed": ok}, status_code=200 if ok else 404)


@router.get("/u/{token}", response_class=HTMLResponse)
def unsubscribe(request: Request, token: str):
    from app.promotion import unsubscribe as client_unsubscribe
    from app.prospecting import unsubscribe as do_unsubscribe
    ok = do_unsubscribe(token) or client_unsubscribe(token)
    return render(request, "error.html", {"title": "Вы отписаны" if ok else "Ссылка недействительна",
                                          "text": "Больше не будем писать вам. Адрес внесён в стоп-лист." if ok
                                          else "Возможно, вы уже отписались."}, status_code=200 if ok else 404)


@router.get("/health")
def health():
    return {"status": "ok"}


@router.get("/ready")
def ready():
    try:
        with engine().connect() as c:
            c.execute(text("SELECT 1"))
        with system_session() as s:
            oldest = s.scalar(select(func.min(Job.run_at)).where(Job.status == "queued", Job.run_at <= utcnow()))
        lag = (utcnow() - oldest).total_seconds() if oldest else 0
        status = "ok" if lag < 600 else "degraded"
        return JSONResponse({"status": status, "queue_lag_seconds": int(lag)}, status_code=200 if status == "ok" else 503)
    except Exception as exc:  # noqa: BLE001
        return JSONResponse({"status": "error", "error": exc.__class__.__name__}, status_code=503)
