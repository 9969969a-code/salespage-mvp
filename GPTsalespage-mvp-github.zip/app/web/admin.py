"""Минимальная админка оператора. Каждое действие требует причины и пишется в журнал."""
from __future__ import annotations

import uuid
from datetime import timedelta

from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy import func, select

from app.analytics import funnel
from app.db import system_session, utcnow
from app.jobs import enqueue
from app.models import (AbuseReport, AIUsage, AuditLog, Job, Order, Publication, Site, SupportTicket, SystemFlag,
                        UpgradeRequest, User)
from app.publishing import restore_site, suspend_site
from app.security import audit, require_admin
from app.web.common import form_with_csrf, render

router = APIRouter(prefix="/admin")
SECTIONS = ("overview", "economics", "plans", "agents", "prospects", "sites", "orders", "publications", "tickets", "abuse", "upgrades", "users", "audit")


def _uuid(v: str):
    try:
        return uuid.UUID(str(v))
    except ValueError:
        return None


@router.get("", response_class=HTMLResponse)
def admin(request: Request, section: str = "overview", msg: str = ""):
    actor = require_admin(request)
    section = section if section in SECTIONS else "overview"
    ctx: dict = {"section": section, "sections": SECTIONS, "msg": msg}
    day = utcnow() - timedelta(days=1)
    with system_session() as s:
        if section == "overview":
            ctx["funnel"] = funnel(30)
            ctx["ai_today"] = s.execute(select(AIUsage.kind, AIUsage.status, func.count()).where(AIUsage.created_at >= day)
                                        .group_by(AIUsage.kind, AIUsage.status)).all()
            ctx["flags"] = {f.key: f.value for f in s.scalars(select(SystemFlag)).all()}
            ctx["dead_jobs"] = s.scalar(select(func.count()).select_from(Job).where(Job.status == "dead")) or 0
            ctx["queued_jobs"] = s.scalar(select(func.count()).select_from(Job).where(Job.status == "queued")) or 0
        elif section == "economics":
            from app.economics import compute
            ctx["eco"] = compute(s, 30)
        elif section == "plans":
            from app.models import Plan
            ctx["rows"] = s.scalars(select(Plan).order_by(Plan.period, Plan.price_kop)).all()
        elif section == "agents":
            from app.agents import status
            ctx["rows"] = status(s, 7)
        elif section == "prospects":
            from app.models import OutreachMessage, Prospect
            ctx["pending"] = s.execute(select(OutreachMessage, Prospect).join(Prospect, Prospect.id == OutreachMessage.prospect_id)
                                       .where(OutreachMessage.status == "pending_review").order_by(Prospect.score.desc())).all()
            ctx["rows"] = s.scalars(select(Prospect).order_by(Prospect.created_at.desc()).limit(300)).all()
            ctx["flags"] = {f.key: f.value for f in s.scalars(select(SystemFlag)).all()}
            from app.prospecting import STATUS_RU as PS
            ctx["pstatus"] = PS
        elif section == "sites":
            ctx["rows"] = s.execute(select(Site, User).join(User, User.id == Site.owner_id).order_by(Site.created_at.desc()).limit(300)).all()
        elif section == "orders":
            ctx["rows"] = s.scalars(select(Order).order_by(Order.created_at.desc()).limit(300)).all()
        elif section == "publications":
            ctx["rows"] = s.scalars(select(Publication).order_by(Publication.created_at.desc()).limit(300)).all()
        elif section == "tickets":
            ctx["rows"] = s.scalars(select(SupportTicket).order_by(SupportTicket.created_at.desc()).limit(300)).all()
        elif section == "abuse":
            ctx["rows"] = s.execute(select(AbuseReport, Site).join(Site, Site.id == AbuseReport.site_id)
                                    .order_by(AbuseReport.created_at.desc()).limit(300)).all()
        elif section == "upgrades":
            ctx["rows"] = s.scalars(select(UpgradeRequest).order_by(UpgradeRequest.created_at.desc()).limit(300)).all()
        elif section == "users":
            ctx["rows"] = s.scalars(select(User).order_by(User.created_at.desc()).limit(300)).all()
        elif section == "audit":
            ctx["rows"] = s.scalars(select(AuditLog).order_by(AuditLog.created_at.desc()).limit(300)).all()
    return render(request, "admin.html", ctx, actor=actor)


@router.post("/prospects/search")
async def prospects_search(request: Request):
    actor = require_admin(request)
    form = await form_with_csrf(request, actor)
    city = str(form.get("city", "")).strip()[:80] or "Санкт-Петербург"
    with system_session() as s:
        enqueue(s, "prospect_search", {"city": city}, dedupe_key=f"prospects-manual:{city}:{utcnow():%Y%m%d%H%M%S}")
        audit(s, "admin.prospect_search", actor_kind="admin", actor_id=actor.user_id, details={"city": city})
    return _back("prospects", f"Поиск по городу «{city}» поставлен в очередь")


@router.post("/outreach/{message_id}")
async def outreach_review(request: Request, message_id: str):
    from app.prospecting import review
    actor = require_admin(request)
    form = await form_with_csrf(request, actor)
    mid = _uuid(message_id)
    if mid is None:
        return _back("prospects", "Не найдено")
    msg = review(mid, actor.user_id, form.get("decision") == "approve", str(form.get("subject", "")), str(form.get("body", "")))
    return _back("prospects", msg)


def _back(section: str, msg: str) -> RedirectResponse:
    return RedirectResponse(f"/admin?section={section}&msg={msg}", status_code=303)


@router.post("/action")
async def action(request: Request):
    actor = require_admin(request)
    form = await form_with_csrf(request, actor)
    act, target, reason = str(form.get("action", "")), _uuid(str(form.get("id", ""))), str(form.get("reason", "")).strip()[:500]
    if act != "flag" and len(reason) < 3:
        return _back(str(form.get("section", "overview")), "Укажите причину действия")
    with system_session() as s:
        if act == "flag":
            key, value = str(form.get("key", "")), "on" if form.get("value") == "on" else "off"
            if key not in ("pause_ai", "pause_publishing", "prospecting"):
                return _back("overview", "Неизвестный флаг")
            row = s.get(SystemFlag, key) or SystemFlag(key=key, value="off")
            row.value = value
            s.add(row)
            audit(s, "admin.flag", actor_kind="admin", actor_id=actor.user_id, entity_type="flag", entity_id=key,
                  details={"value": value})
            return _back("overview", "Флаг изменён")
        if target is None:
            return _back("overview", "Не найдено")
        if act == "plan_update":
            from app.models import Plan
            plan = s.get(Plan, str(form.get("code", "")))
            try:
                price = int(str(form.get("price_rub", "")).replace(" ", ""))
            except ValueError:
                return _back("plans", "Цена должна быть целым числом рублей")
            if plan is None or not 1 <= price <= 1_000_000:
                return _back("plans", "Тариф не найден или цена вне диапазона")
            want = form.get("purchasable") == "on"
            old = plan.price_kop // 100
            plan.price_kop, plan.purchasable = price * 100, want
            if str(form.get("name", "")).strip():
                plan.name = str(form.get("name")).strip()[:80]
            audit(s, "admin.plan_update", actor_kind="admin", actor_id=actor.user_id, entity_type="plan", entity_id=plan.code,
                  details={"old_price": old, "new_price": price, "purchasable": want, "reason": reason})
            return _back("plans", f"Тариф «{plan.name}»: {price} ₽")
        if act in ("suspend", "restore"):
            site = s.get(Site, target)
            if site is None:
                return _back("sites", "Сайт не найден")
            if act == "suspend":
                suspend_site(s, site, reason, actor.user_id)
            else:
                restore_site(s, site, reason, actor.user_id)
            return _back("sites", "Готово")
        if act == "retry_publication":
            pub = s.get(Publication, target)
            if pub is None or pub.status == "live":
                return _back("publications", "Нечего повторять")
            pub.status, pub.error = "queued", ""
            enqueue(s, "publish", {"publication_id": str(pub.id)}, dedupe_key=f"publish-retry:{pub.id}:{utcnow():%Y%m%d%H%M%S}")
            audit(s, "admin.publication_retry", actor_kind="admin", actor_id=actor.user_id, owner_id=pub.owner_id,
                  entity_type="publication", entity_id=pub.id, details={"reason": reason})
            return _back("publications", "Публикация поставлена в очередь")
        if act == "ticket_reply":
            t = s.get(SupportTicket, target)
            if t is None:
                return _back("tickets", "Не найдено")
            t.admin_reply, t.status = reason, "closed" if form.get("close") == "1" else "in_progress"
            audit(s, "admin.ticket_reply", actor_kind="admin", actor_id=actor.user_id, owner_id=t.owner_id,
                  entity_type="ticket", entity_id=t.id)
            return _back("tickets", "Ответ сохранён")
        if act in ("abuse_action", "abuse_reject"):
            r = s.get(AbuseReport, target)
            if r is None:
                return _back("abuse", "Не найдено")
            r.status, r.admin_note = ("actioned" if act == "abuse_action" else "rejected"), reason
            if act == "abuse_action":
                site = s.get(Site, r.site_id)
                if site and site.status == "live":
                    suspend_site(s, site, f"жалоба {r.id}: {reason}", actor.user_id)
            audit(s, f"admin.{act}", actor_kind="admin", actor_id=actor.user_id, entity_type="abuse", entity_id=r.id,
                  details={"reason": reason})
            return _back("abuse", "Жалоба рассмотрена")
        if act == "upgrade_status":
            r = s.get(UpgradeRequest, target)
            new = str(form.get("status", ""))
            if r is None or new not in ("new", "in_progress", "done", "rejected"):
                return _back("upgrades", "Не найдено")
            r.status = new
            audit(s, "admin.upgrade_status", actor_kind="admin", actor_id=actor.user_id, owner_id=r.owner_id,
                  entity_type="upgrade", entity_id=r.id, details={"status": new, "reason": reason})
            return _back("upgrades", "Статус изменён")
        if act in ("block_user", "unblock_user"):
            u = s.get(User, target)
            if u is None or u.id == actor.user_id:
                return _back("users", "Нельзя")
            u.status = "blocked" if act == "block_user" else "active"
            audit(s, f"admin.{act}", actor_kind="admin", actor_id=actor.user_id, owner_id=u.id, entity_type="user",
                  entity_id=u.id, details={"reason": reason})
            return _back("users", "Готово")
    return _back("overview", "Неизвестное действие")
