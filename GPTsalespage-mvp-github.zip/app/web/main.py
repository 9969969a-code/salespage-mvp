"""Точка входа веб-приложения: uvicorn app.web.main:app

Запросы на <slug>.<SITES_DOMAIN> уходят в sites_app (клиентские сайты), остальные в платформу.
"""
from __future__ import annotations

import logging

from fastapi import FastAPI, Request
from fastapi.responses import RedirectResponse
from fastapi.staticfiles import StaticFiles

from app.config import BASE_DIR, get_settings
from app.security import CsrfFailed, Forbidden, LoginRequired
from app.utils import setup_logging
from app.web import admin, auth, cabinet, payments, public
from app.web.common import render
from app.web.sites_host import is_sites_host, sites_app

log = logging.getLogger("salespage")
PLATFORM_HEADERS = {
    "X-Content-Type-Options": "nosniff",
    "Referrer-Policy": "strict-origin-when-cross-origin",
    "X-Frame-Options": "SAMEORIGIN",
    "Content-Security-Policy": ("default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; "
                                "script-src 'self'; font-src 'self'; frame-src 'self'; form-action 'self'; "
                                "frame-ancestors 'self'; base-uri 'none'; object-src 'none'"),
}


def create_app() -> FastAPI:
    st = get_settings()
    problems = st.production_problems()
    if problems:
        raise RuntimeError("Запуск в production невозможен, не настроено: " + ", ".join(problems))
    setup_logging()
    app = FastAPI(title="Платформа сайтов", docs_url=None, redoc_url=None, openapi_url=None)
    app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")
    for r in (public.router, auth.router, cabinet.router, payments.router, admin.router):
        app.include_router(r)

    @app.middleware("http")
    async def host_router(request: Request, call_next):
        if is_sites_host(request.headers.get("host", "")):
            # клиентский сайт: отдельное приложение, без cookie платформы
            return await _call_asgi(sites_app, request)
        response = await call_next(request)
        for k, v in PLATFORM_HEADERS.items():
            response.headers.setdefault(k, v)
        return response

    @app.exception_handler(LoginRequired)
    async def _login(request: Request, exc: LoginRequired):
        if request.url.path.startswith("/cabinet") and request.method == "GET":
            return RedirectResponse("/login", status_code=303)
        return render(request, "error.html", {"title": "Нужен вход", "text": "Войдите в аккаунт."}, status_code=401)

    @app.exception_handler(Forbidden)
    async def _forbidden(request: Request, exc: Forbidden):
        return render(request, "error.html", {"title": "Нет доступа", "text": "Раздел доступен только оператору."},
                      status_code=403)

    @app.exception_handler(CsrfFailed)
    async def _csrf(request: Request, exc: CsrfFailed):
        return render(request, "error.html", {"title": "Сессия устарела",
                                              "text": "Обновите страницу и повторите действие."}, status_code=403)

    return app


async def _call_asgi(asgi_app, request: Request):
    """Передаёт запрос во вложенное ASGI-приложение и возвращает его ответ."""
    from starlette.responses import Response
    chunks: list[bytes] = []
    started: dict = {}

    async def send(message):
        if message["type"] == "http.response.start":
            started.update(message)
        elif message["type"] == "http.response.body":
            chunks.append(message.get("body", b""))

    body = await request.body()
    sent = False

    async def receive():
        nonlocal sent
        if not sent:
            sent = True
            return {"type": "http.request", "body": body, "more_body": False}
        return {"type": "http.disconnect"}

    await asgi_app(request.scope, receive, send)
    headers = {k.decode(): v.decode() for k, v in started.get("headers", [])}
    headers.pop("content-length", None)
    return Response(b"".join(chunks), status_code=started.get("status", 500), headers=headers)


app = create_app()
