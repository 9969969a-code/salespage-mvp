"""Безопасная загрузка фото: тип по содержимому, лимиты, перекодирование без EXIF и координат."""
from __future__ import annotations

import hashlib
import io
import uuid
from pathlib import Path

from PIL import Image, ImageOps

from app.config import get_settings

MAX_BYTES = 8 * 1024 * 1024
MAX_PIXELS = 40_000_000
MAX_SIDE = 1600
MAX_PER_SITE = 20
ALLOWED_FORMATS = {"JPEG", "PNG", "WEBP"}


class UploadError(Exception):
    pass


def process_image(data: bytes) -> tuple[bytes, int, int]:
    if not data:
        raise UploadError("Файл пустой.")
    if len(data) > MAX_BYTES:
        raise UploadError("Файл больше 8 МБ.")
    Image.MAX_IMAGE_PIXELS = MAX_PIXELS
    try:
        with Image.open(io.BytesIO(data)) as probe:
            fmt = probe.format
            w, h = probe.size
            probe.verify()
    except Image.DecompressionBombError as exc:
        raise UploadError("Изображение слишком большое по разрешению.") from exc
    except Exception as exc:  # noqa: BLE001 — любой нераспознанный файл отклоняем
        raise UploadError("Это не изображение JPEG, PNG или WebP.") from exc
    if fmt not in ALLOWED_FORMATS:
        raise UploadError("Допустимы только JPEG, PNG и WebP.")
    if w * h > MAX_PIXELS or w < 200 or h < 200:
        raise UploadError("Нужно изображение от 200×200 пикселей и не больше 40 мегапикселей.")
    with Image.open(io.BytesIO(data)) as im:
        im = ImageOps.exif_transpose(im)
        im = im.convert("RGB")
        im.thumbnail((MAX_SIDE, MAX_SIDE))
        out = io.BytesIO()
        im.save(out, "WEBP", quality=82, method=4)  # метаданные не копируются
        return out.getvalue(), im.width, im.height


def store_image(owner_id: uuid.UUID, site_id: uuid.UUID, data: bytes) -> tuple[str, int, int, int, str]:
    webp, w, h = process_image(data)
    rel = Path("uploads") / str(owner_id) / str(site_id) / f"{uuid.uuid4().hex}.webp"
    full = get_settings().storage / rel
    full.parent.mkdir(parents=True, exist_ok=True)
    tmp = full.with_suffix(".tmp")
    tmp.write_bytes(webp)
    tmp.replace(full)
    return str(rel), w, h, len(webp), hashlib.sha256(webp).hexdigest()


def read_stored(rel: str) -> bytes:
    root = get_settings().storage.resolve()
    full = (root / rel).resolve()
    if root not in full.parents:
        raise UploadError("Недопустимый путь.")
    return full.read_bytes()
