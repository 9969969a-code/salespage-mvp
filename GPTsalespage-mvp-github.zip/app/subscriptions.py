"""Подписки на обслуживание: ежемесячная оплата по ссылке, напоминание за 3 дня, MRR и отток.

Автоплатежей (привязки карты) нет: для них нужен отдельный договор с банком. Подписка оплачивается
тем же проверенным путём, что и сайт: заказ на сервере → платёж → уведомление → сверка у провайдера.
"""
from __future__ import annotations

from datetime import timedelta

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.db import system_session, utcnow
from app.models import Plan, Site
from app.notify import notify_owner

PERIOD_DAYS = 30
REMIND_DAYS = 3


def extend_service(site: Site, plan_code: str) -> None:
    now = utcnow()
    base = site.service_paid_until if site.service_paid_until and site.service_paid_until > now else now
    site.service_plan, site.service_paid_until = plan_code, base + timedelta(days=PERIOD_DAYS)


def is_active(site: Site) -> bool:
    return bool(site.service_paid_until and site.service_paid_until > utcnow())


def mrr(s: Session) -> tuple[float, int]:
    rows = s.execute(select(Plan.price_kop).join(Site, Site.service_plan == Plan.code)
                     .where(Site.service_paid_until > utcnow())).all()
    return sum(r[0] for r in rows) / 100, len(rows)


def lapsed(s: Session, days: int = 30) -> int:
    now = utcnow()
    return s.scalar(select(func.count()).select_from(Site).where(Site.service_paid_until <= now,
                                                                 Site.service_paid_until > now - timedelta(days=days))) or 0


def remind_expiring() -> int:
    """Один раз на каждый срок: «подписка заканчивается через N дней»."""
    now, count = utcnow(), 0
    with system_session() as s:
        sites = s.scalars(select(Site).where(Site.service_paid_until > now,
                                             Site.service_paid_until <= now + timedelta(days=REMIND_DAYS))).all()
        for site in sites:
            if site.service_reminded_for == site.service_paid_until:
                continue
            plan = s.get(Plan, site.service_plan)
            notify_owner(s, site.owner_id, "subscription_reminder",
                         {"site": site.slug, "plan": plan.name if plan else "", "until": f"{site.service_paid_until:%d.%m.%Y}",
                          "price": plan.price_kop // 100 if plan else 0}, f"subrem:{site.id}:{site.service_paid_until:%Y%m%d}")
            site.service_reminded_for = site.service_paid_until
            count += 1
    return count
