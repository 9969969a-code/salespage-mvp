"""Генерация, правки, версии, откат и проверки перед публикацией."""
from __future__ import annotations

import logging
import uuid
from datetime import timedelta
from typing import Optional

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.ai import AIError, FakeProvider, get_provider
from app.config import get_settings
from app.content import check_facts, validate_content
from app.db import system_session, utcnow
from app.dialog import QUESTION_KEYS, facts_of
from app.models import AIUsage, Asset, Project, Site, SiteVersion, SystemFlag
from app.security import audit

log = logging.getLogger("sitegen")
REQUIRED_FACTS = ("name", "about", "city", "phone")


class LimitReached(Exception):
    pass


def flag_on(s: Session, key: str) -> bool:
    row = s.get(SystemFlag, key)
    return bool(row and row.value == "on")


def check_ai_budget(owner_id: uuid.UUID, kind: str) -> None:
    st = get_settings()
    since = utcnow() - timedelta(days=1)
    with system_session() as s:
        if flag_on(s, "pause_ai"):
            raise LimitReached("ИИ временно приостановлен администратором. Попробуйте позже.")
        mine = s.scalar(select(func.count()).select_from(AIUsage).where(
            AIUsage.owner_id == owner_id, AIUsage.kind == kind, AIUsage.created_at >= since, AIUsage.status != "blocked")) or 0
        total = s.scalar(select(func.count()).select_from(AIUsage).where(AIUsage.created_at >= since, AIUsage.status != "blocked")) or 0
        limit = st.AI_LIMIT_GENERATIONS_PER_DAY if kind == "generate" else st.AI_LIMIT_EDITS_PER_DAY
        if mine >= limit or total >= st.AI_LIMIT_TOTAL_CALLS_PER_DAY:
            s.add(AIUsage(owner_id=owner_id, kind=kind, provider="-", status="blocked"))
            raise LimitReached("Достигнут дневной лимит обращений к ИИ. Лимит обновится в течение суток.")


def record_ai(owner_id: uuid.UUID, kind: str, provider: str, status: str) -> None:
    with system_session() as s:
        s.add(AIUsage(owner_id=owner_id, kind=kind, provider=provider, status=status, units=1))


def next_version_number(s: Session, site_id: uuid.UUID) -> int:
    return (s.scalar(select(func.max(SiteVersion.number)).where(SiteVersion.site_id == site_id)) or 0) + 1


def save_version(s: Session, site: Site, content: dict, source: str, note: str, violations: list[str]) -> SiteVersion:
    v = SiteVersion(owner_id=site.owner_id, site_id=site.id, number=next_version_number(s, site.id), content=content,
                    source=source, note=note[:500], validation={"violations": violations})
    s.add(v)
    s.flush()
    site.current_version_id = v.id
    if site.status == "ready":
        site.status = "draft"  # новая версия требует нового подтверждения
    return v


def missing_facts(facts: dict[str, str]) -> list[str]:
    return [k for k in REQUIRED_FACTS if not facts.get(k)]


def run_generation(site_id: uuid.UUID) -> str:
    """Задача воркера. Возвращает итог для журнала. Без ключа ИИ работает тестовый генератор."""
    st = get_settings()
    with system_session() as s:
        site = s.get(Site, site_id)
        if site is None:
            return "site not found"
        proj = s.get(Project, site.project_id)
        facts = facts_of(s, proj.business_id)
        first_asset = s.scalar(select(Asset.id).where(Asset.site_id == site.id).order_by(Asset.created_at))
        site.generation_status = "running"
        owner_id = site.owner_id
    hero_image = f"asset:{first_asset}" if first_asset else None
    provider = get_provider(st)
    content, violations, source, note = None, [], "generation", ""
    for attempt in range(2):
        try:
            raw = provider.generate(facts, hero_image)
            record_ai(owner_id, "generate", provider.name, "ok")
        except AIError as exc:
            record_ai(owner_id, "generate", provider.name, "error")
            note = str(exc)
            continue
        content, errors = validate_content(raw)
        if errors:
            note = "; ".join(errors)
            content = None
            continue
        violations = check_facts(content, facts)
        if not violations:
            break
        note = "; ".join(violations)
        content = None
    if content is None:  # запасной вариант: детерминированный текст только из фактов
        content, _ = validate_content(FakeProvider().generate(facts, hero_image))
        violations = check_facts(content, facts) if content else ["fallback failed"]
        source = "fallback"
    with system_session() as s:
        site = s.get(Site, site_id)
        if content is None:
            site.generation_status, site.generation_error = "failed", note[:500]
            return "failed"
        v = save_version(s, site, content, source, note if source == "fallback" else "Первая версия", violations)
        site.generation_status, site.generation_error = "done", ""
        audit(s, "site.generated", actor_kind="system", owner_id=site.owner_id, entity_type="site", entity_id=site.id,
              details={"version": v.number, "source": source})
    return source


def apply_edit(s: Session, site: Site, command: str) -> tuple[bool, str]:
    """Правка обычным сообщением; s — сессия владельца (RLS)."""
    command = command.strip()[:300]
    if not command:
        return False, "Напишите, что изменить."
    if site.current_version_id is None:
        return False, "Сначала создайте первую версию сайта."
    proj = s.get(Project, site.project_id)
    facts = facts_of(s, proj.business_id)
    current = s.get(SiteVersion, site.current_version_id)
    check_ai_budget(site.owner_id, "edit")
    provider = get_provider(get_settings())
    try:
        new_content, message = provider.edit(current.content, command, facts)
        record_ai(site.owner_id, "edit", provider.name, "ok")
    except AIError as exc:
        record_ai(site.owner_id, "edit", provider.name, "error")
        return False, f"Не удалось выполнить правку: {exc}. Попробуйте ещё раз."
    if new_content is None:
        return False, message
    content, errors = validate_content(new_content)
    if errors:
        return False, "Правка отклонена проверкой структуры: " + "; ".join(errors[:3])
    violations = check_facts(content, facts)
    if violations:
        return False, "Правка отклонена: " + "; ".join(violations[:3])
    v = save_version(s, site, content, "edit", command, [])
    audit(s, "site.edited", actor_kind="user", actor_id=site.owner_id, owner_id=site.owner_id, entity_type="site",
          entity_id=site.id, details={"version": v.number, "command": command})
    return True, f"{message} Сохранено как версия {v.number}."


def rollback(s: Session, site: Site, version_id: uuid.UUID) -> tuple[bool, str]:
    old = s.scalar(select(SiteVersion).where(SiteVersion.id == version_id, SiteVersion.site_id == site.id))
    if old is None:
        return False, "Версия не найдена."
    v = save_version(s, site, old.content, "rollback", f"Возврат к версии {old.number}", [])
    audit(s, "site.rollback", actor_kind="user", actor_id=site.owner_id, owner_id=site.owner_id, entity_type="site",
          entity_id=site.id, details={"from": old.number, "to": v.number})
    return True, f"Восстановлена версия {old.number}; это новая версия {v.number}."


def publish_checklist(s: Session, site: Site) -> list[str]:
    """Что мешает публикации. Пустой список = можно подтверждать и оплачивать."""
    problems = []
    if site.current_version_id is None:
        return ["Нет версии сайта."]
    v = s.get(SiteVersion, site.current_version_id)
    proj = s.get(Project, site.project_id)
    facts = facts_of(s, proj.business_id)
    missing = missing_facts(facts)
    if missing:
        problems.append("Не заполнены обязательные сведения: " + ", ".join(missing))
    _, errors = validate_content(v.content)
    problems += errors
    problems += check_facts(v.content, facts)
    hero = next(b for b in v.content["blocks"] if b["type"] == "hero")
    image = hero["data"].get("image")
    if not image:
        problems.append("Главному блоку нужно изображение: загрузите фото магазина или выберите иллюстрацию.")
    elif image.startswith("asset:"):
        try:
            aid = uuid.UUID(image.split(":", 1)[1])
        except ValueError:
            aid = None
        if aid is None or s.get(Asset, aid) is None:
            problems.append("Фото главного блока не найдено, загрузите его заново.")
    for b in v.content["blocks"]:
        for item in b["data"].get("items", []) if isinstance(b["data"].get("items"), list) else []:
            img = item.get("image") if isinstance(item, dict) else None
            if img and img.startswith("asset:"):
                try:
                    ok = s.get(Asset, uuid.UUID(img.split(":", 1)[1])) is not None
                except ValueError:
                    ok = False
                if not ok:
                    problems.append(f"{b['id']}: изображение не найдено")
    return problems


def claims_for_review(content: dict) -> list[str]:
    """Утверждения, которые будут написаны от имени владельца."""
    from app.content import content_texts
    return [t for p, t in content_texts(content) if t and not p.endswith(("cta_text", "button_text"))][:40]


def confirm_version(s: Session, site: Site) -> tuple[bool, str]:
    problems = publish_checklist(s, site)
    if problems:
        return False, "Сначала исправьте: " + "; ".join(problems[:5])
    v = s.get(SiteVersion, site.current_version_id)
    v.owner_confirmed_at = utcnow()
    if site.status == "draft":
        site.status = "ready"
    audit(s, "site.confirmed", actor_kind="user", actor_id=site.owner_id, owner_id=site.owner_id, entity_type="site",
          entity_id=site.id, details={"version": v.number})
    return True, "Содержимое подтверждено."


def set_hero_image(s: Session, site: Site, ref: Optional[str]) -> tuple[bool, str]:
    from app.content import ILLUSTRATIONS
    if site.current_version_id is None:
        return False, "Сначала создайте сайт."
    if ref and ref.startswith("illustration:") and ref.split(":", 1)[1] not in ILLUSTRATIONS:
        return False, "Неизвестная иллюстрация."
    if ref and ref.startswith("asset:"):
        try:
            if s.get(Asset, uuid.UUID(ref.split(":", 1)[1])) is None:
                return False, "Фото не найдено."
        except ValueError:
            return False, "Фото не найдено."
    v = s.get(SiteVersion, site.current_version_id)
    content = {**v.content, "blocks": [dict(b) for b in v.content["blocks"]]}
    for b in content["blocks"]:
        if b["type"] == "hero":
            b["data"] = {**b["data"], "image": ref}
    save_version(s, site, content, "edit", "Изображение главного блока", [])
    return True, "Изображение главного блока обновлено."


__all__ = ["QUESTION_KEYS", "run_generation", "apply_edit", "rollback", "publish_checklist", "confirm_version",
           "claims_for_review", "check_ai_budget", "LimitReached", "set_hero_image", "flag_on"]
