"""Публикация: сборка релиза во временный каталог, проверка, атомарное переключение ссылки
current, проверка фактической доступности, откат при неудаче. Каталог сайта: sites/<slug>/."""
from __future__ import annotations

import logging
import os
import shutil
import uuid
from datetime import timedelta
from pathlib import Path
from typing import Callable, Optional

import httpx
from sqlalchemy import select, update

from app.config import get_settings
from app.db import system_session, utcnow
from app.dialog import facts_of
from app.models import Asset, Order, Project, Publication, Site, SiteVersion
from app.render import (favicon_svg, illustration_path, og_image, render_site, robots_txt, sitemap_xml, stub_html,
                        tracker_js)
from app.security import audit
from app.uploads import read_stored

log = logging.getLogger("publishing")


class PublishError(Exception):
    pass


class RetryLater(Exception):
    pass


def site_dir(slug: str) -> Path:
    return get_settings().sites_root / slug


def current_target(slug: str) -> Optional[Path]:
    link = site_dir(slug) / "current"
    return Path(os.readlink(link)) if link.is_symlink() else None


def switch_current(slug: str, release: Path) -> None:
    """Атомарно: новая ссылка создаётся рядом и заменяет старую одной операцией rename."""
    root = site_dir(slug)
    tmp = root / f".current-{uuid.uuid4().hex}"
    os.symlink(release.resolve(), tmp)
    os.replace(tmp, root / "current")


def _write(path: Path, data: bytes | str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data.encode() if isinstance(data, str) else data)


def build_release(s, site: Site, version: SiteVersion, release_id: str) -> Path:
    st = get_settings()
    proj = s.get(Project, site.project_id)
    facts = facts_of(s, proj.business_id)
    releases = site_dir(site.slug) / "releases"
    tmp = releases / f".tmp-{release_id}"
    final = releases / release_id
    shutil.rmtree(tmp, ignore_errors=True)
    tmp.mkdir(parents=True)
    copied: dict[str, str] = {}

    def image_url(ref: Optional[str]) -> str:
        if not ref:
            return ""
        if ref in copied:
            return copied[ref]
        kind, _, value = ref.partition(":")
        if kind == "asset":
            asset = s.get(Asset, uuid.UUID(value))
            if asset is None or asset.site_id != site.id:
                raise PublishError(f"изображение {value} не найдено")
            _write(tmp / "img" / f"{asset.id}.webp", read_stored(asset.storage_path))
            copied[ref] = f"/img/{asset.id}.webp"
        elif kind == "illustration":
            src = illustration_path(value)
            if not src.is_file():
                raise PublishError(f"иллюстрация {value} не найдена")
            _write(tmp / "img" / f"{value}.svg", src.read_bytes())
            copied[ref] = f"/img/{value}.svg"
        else:
            raise PublishError("неизвестная ссылка на изображение")
        return copied[ref]

    base_url = st.site_url(site.slug)
    operator = {"name": st.OPERATOR_NAME, "inn": st.OPERATOR_INN, "email": st.OPERATOR_EMAIL}
    multi = site.plan_code == "site"
    html, css, privacy = render_site(version.content, facts, mode="publish", image_url=image_url, base_url=base_url,
                                     asset_prefix="/", css_url="/assets/site.css", operator=operator, multipage=multi)
    page_paths = ["/"]
    if multi:  # многостраничный тариф: отдельный index.html в каталоге каждой страницы
        from app.render import site_pages
        for key, _, path in site_pages(version.content)[1:]:
            sub = render_site(version.content, facts, mode="publish", image_url=image_url, base_url=base_url,
                              asset_prefix="/", css_url="/assets/site.css", operator=operator, multipage=True, page=key)[0]
            _write(tmp / key / "index.html", sub)
            page_paths.append(path)
    hero = next(b for b in version.content["blocks"] if b["type"] == "hero")
    photo = None
    if (hero["data"].get("image") or "").startswith("asset:"):
        photo = (tmp / copied[hero["data"]["image"]].lstrip("/")).read_bytes()
    _write(tmp / "index.html", html.replace("<html lang=\"ru\">", f"<html lang=\"ru\" data-release=\"{release_id}\">", 1))
    _write(tmp / "privacy.html", privacy)
    _write(tmp / "assets" / "site.css", css)
    _write(tmp / "assets" / "stub.css", (Path(__file__).parent.parent / "static" / "stub.css").read_bytes())
    _write(tmp / "favicon.svg", favicon_svg(facts.get("name", ""), version.content["theme"].get("button_color") or "#B4385A"))
    _write(tmp / "og.png", og_image(facts.get("name", ""), facts.get("city", ""), version.content["theme"]["palette"], photo))
    _write(tmp / "robots.txt", robots_txt(base_url, indexable=True))
    _write(tmp / "sitemap.xml", sitemap_xml(base_url, utcnow().date().isoformat(), tuple(page_paths)))
    _write(tmp / "_assets" / "t.js", tracker_js())
    # проверки до переключения: все ссылки на картинки ведут на существующие файлы
    for ref, url in copied.items():
        if not (tmp / url.lstrip("/")).is_file():
            raise PublishError(f"битое изображение {url}")
    if b"<h1>" not in (tmp / "index.html").read_bytes():
        raise PublishError("в странице нет заголовка")
    shutil.rmtree(final, ignore_errors=True)
    os.replace(tmp, final)
    return final


def write_stub(slug: str, kind: str) -> Path:
    texts = {"suspended": ("Сайт временно недоступен", "Работа сайта приостановлена. Попробуйте зайти позже."),
             "expired": ("Сайт временно недоступен", "Срок размещения сайта закончился.")}
    title, text = texts[kind]
    rel = site_dir(slug) / "releases" / f"stub-{kind}"
    _write(rel / "index.html", stub_html(title, text))
    _write(rel / "assets" / "stub.css", (Path(__file__).parent.parent / "static" / "stub.css").read_bytes())
    _write(rel / "robots.txt", robots_txt("", indexable=False))
    return rel


# ------------------------------------------------------------------ проверка доступности
def default_verifier(slug: str, release_id: str) -> tuple[bool, str]:
    st = get_settings()
    url = st.site_url(slug) + "/"
    try:
        if st.SITE_CHECK_VIA_LOOPBACK:
            r = httpx.get(f"http://127.0.0.1:{st.LOCAL_PORT}/", headers={"Host": f"{slug}.{st.SITES_DOMAIN}"}, timeout=10)
        else:
            r = httpx.get(url, timeout=15, follow_redirects=True)
    except httpx.HTTPError as exc:
        return False, f"сайт не открылся: {exc.__class__.__name__}"
    if r.status_code != 200 or f'data-release="{release_id}"' not in r.text:
        return False, f"сайт ответил {r.status_code} или отдал не ту версию"
    return True, url


VERIFIER: Callable[[str, str], tuple[bool, str]] = default_verifier


def site_paid(s, site: Site) -> bool:
    paid = s.scalar(select(Order).where(Order.site_id == site.id, Order.status == "paid").limit(1))
    return paid is not None and site.hosting_paid_until is not None and site.hosting_paid_until > utcnow()


def run_publication(publication_id: uuid.UUID) -> str:
    from app.notify import notify_owner
    from app.sitegen import flag_on

    with system_session() as s:
        pub = s.get(Publication, publication_id)
        if pub is None or pub.status in ("live", "superseded"):
            return "nothing to do"
        if flag_on(s, "pause_publishing"):
            raise RetryLater("публикация приостановлена администратором")
        site = s.get(Site, pub.site_id)
        if site.status in ("suspended", "archived"):
            pub.status, pub.error = "failed", f"сайт в статусе {site.status}"
            return "blocked"
        if not site_paid(s, site):
            pub.status, pub.error = "failed", "нет подтверждённой оплаты"
            audit(s, "publication.refused_unpaid", actor_kind="system", owner_id=site.owner_id, entity_type="site", entity_id=site.id)
            return "unpaid"
        version = s.get(SiteVersion, pub.version_id)
        if version is None or version.owner_confirmed_at is None:
            pub.status, pub.error = "failed", "версия не подтверждена владельцем"
            return "unconfirmed"
        pub.status, pub.attempts = "building", pub.attempts + 1
        slug, release_id = site.slug, str(pub.id)
        previous = current_target(slug)
        build_error = ""
        try:
            release = build_release(s, site, version, release_id)
        except (PublishError, OSError, ValueError) as exc:
            pub.status, pub.error = "failed", str(exc)[:500]
            build_error = str(exc)
    if build_error:  # статус «failed» уже сохранён; задача будет повторена
        raise PublishError(build_error)
    switch_current(slug, release)
    ok, detail = VERIFIER(slug, release_id)
    if not ok:
        if previous is not None:
            switch_current(slug, previous)  # откат: посетители продолжают видеть прежнюю версию
        with system_session() as s:
            pub = s.get(Publication, publication_id)
            pub.status, pub.error = "failed", detail
        raise PublishError(detail)
    with system_session() as s:
        pub = s.get(Publication, publication_id)
        site = s.get(Site, pub.site_id)
        s.execute(update(Publication).where(Publication.site_id == site.id, Publication.status == "live",
                                            Publication.id != pub.id).values(status="superseded"))
        pub.status, pub.verified_at, pub.finished_at, pub.release_dir, pub.error = "live", utcnow(), utcnow(), str(release), ""
        site.status, site.published_version_id = "live", pub.version_id
        audit(s, "site.published", actor_kind="system", owner_id=site.owner_id, entity_type="site", entity_id=site.id,
              details={"publication": str(pub.id), "url": detail})
        notify_owner(s, site.owner_id, "published", {"site": site.slug, "url": detail}, f"published:{pub.id}")
    return "live"


def on_publication_dead(publication_id: uuid.UUID, error: str) -> None:
    from app.notify import notify_owner, notify_operator
    with system_session() as s:
        pub = s.get(Publication, publication_id)
        if pub is None:
            return
        pub.status, pub.error = "failed", error[:500]
        site = s.get(Site, pub.site_id)
        notify_owner(s, site.owner_id, "publish_failed", {"site": site.slug}, f"publish_failed:{pub.id}")
        notify_operator(s, f"Публикация {site.slug} не удалась: {error[:200]}", f"op_publish_failed:{pub.id}")


def queue_publication(s, site: Site, version_id: uuid.UUID, order_id: Optional[uuid.UUID]) -> Publication:
    from app.jobs import enqueue
    pub = Publication(owner_id=site.owner_id, site_id=site.id, version_id=version_id, order_id=order_id)
    s.add(pub)
    s.flush()
    if site.status in ("draft", "ready"):
        site.status = "publishing"
    enqueue(s, "publish", {"publication_id": str(pub.id)}, dedupe_key=f"publish:{pub.id}")
    return pub


def suspend_site(s, site: Site, reason: str, admin_id: uuid.UUID) -> None:
    switch_current(site.slug, write_stub(site.slug, "suspended"))
    site.status = "suspended"
    audit(s, "site.suspended", actor_kind="admin", actor_id=admin_id, owner_id=site.owner_id, entity_type="site",
          entity_id=site.id, details={"reason": reason})


def restore_site(s, site: Site, reason: str, admin_id: uuid.UUID) -> bool:
    live = s.scalar(select(Publication).where(Publication.site_id == site.id, Publication.status == "live"))
    if live is None or not Path(live.release_dir).is_dir():
        return False
    switch_current(site.slug, Path(live.release_dir))
    site.status = "live" if site.hosting_paid_until and site.hosting_paid_until > utcnow() else "expired"
    audit(s, "site.restored", actor_kind="admin", actor_id=admin_id, owner_id=site.owner_id, entity_type="site",
          entity_id=site.id, details={"reason": reason})
    return True


def expire_sites() -> list[str]:
    """Сайты с истёкшим сроком размещения получают заглушку; данные и релизы сохраняются."""
    from app.notify import notify_owner
    done = []
    with system_session() as s:
        sites = s.scalars(select(Site).where(Site.status == "live", Site.hosting_paid_until < utcnow())).all()
        for site in sites:
            switch_current(site.slug, write_stub(site.slug, "expired"))
            site.status = "expired"
            audit(s, "site.expired", actor_kind="system", owner_id=site.owner_id, entity_type="site", entity_id=site.id)
            notify_owner(s, site.owner_id, "status", {"site": site.slug, "text": "Срок размещения закончился, сайт скрыт."},
                         f"expired:{site.id}:{site.hosting_paid_until:%Y%m%d}")
            done.append(site.slug)
    return done


def extend_hosting(site: Site, months: int) -> None:
    base = site.hosting_paid_until if site.hosting_paid_until and site.hosting_paid_until > utcnow() else utcnow()
    site.hosting_paid_until = base + timedelta(days=30 * months)
