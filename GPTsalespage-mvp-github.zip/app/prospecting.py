"""Поиск клиентов для самой платформы.

Конвейер: источник компаний → проверка сайта → ниша → оценка → персональное предложение → очередь «на одобрение».
Письмо уходит ТОЛЬКО после одобрения оператором в админке: рекламная рассылка без согласия адресата
рискует нарушить ст. 18 ФЗ «О рекламе». Каждое письмо содержит причину обращения и ссылку отказа;
отказавшиеся попадают в стоп-лист навсегда.

Режимы: PROSPECT_SOURCE=mock (тестовые компании [MOCK]) | 2gis (официальный API, нужен TWO_GIS_API_KEY, не проверен);
EMAIL_MODE=mock (письма в таблицу fake_emails [MOCK]) | smtp (SMTP_*, не проверен).
"""
from __future__ import annotations

import logging
import os
import re
import secrets
import smtplib
import uuid
from dataclasses import dataclass, field
from email.message import EmailMessage
from typing import Optional

import httpx
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.config import get_settings
from app.db import system_session, utcnow
from app.models import FakeEmail, OutreachMessage, Plan, Prospect, SuppressionEntry
from app.notify import notify_operator
from app.security import audit
from app.utils import normalize_phone

log = logging.getLogger("salespage.prospecting")

FLOWER_WORDS = ("цвет", "флор", "букет", "роз", "пион", "тюльпан")
SITE_REASON = {
    "none": "у компании нет сайта в справочнике",
    "unreachable": "указанный сайт не открывается",
    "no_https": "сайт открывается без защищённого соединения (HTTPS), браузеры помечают такие сайты как небезопасные",
    "no_mobile": "сайт не адаптирован для телефонов",
}
STATUS_RU = {"new": "новый", "disqualified": "не подходит", "pending_review": "ждёт одобрения", "call_list": "только телефон",
             "approved": "одобрен", "sent": "письмо отправлено", "rejected": "отклонён", "opted_out": "отказался",
             "converted": "зарегистрировался", "has_site": "сайт в порядке"}


def env(name: str, default: str) -> str:
    return os.getenv(name, default).strip()


# ------------------------------------------------------------------ источники
@dataclass
class Company:
    external_id: str
    name: str
    rubric: str
    city: str
    address: str = ""
    phone: str = ""
    email: str = ""
    website: str = ""
    mock_site: Optional[str] = None  # для тестового источника: заранее известный статус сайта
    extra: dict = field(default_factory=dict)


MOCK_COMPANIES = [  # вымышленные компании, домены example.* зарезервированы и не принадлежат никому
    Company("m1", "Цветочная лавка «Незабудка» (тест)", "Цветы", "Санкт-Петербург", "Садовая ул., 12", "+7 900 100-00-01", "nezabudka@example.com", "", "none"),
    Company("m2", "Флора-Студия (тест)", "Цветы, флористика", "Санкт-Петербург", "Невский пр., 40", "+7 900 100-00-02", "flora@example.com", "http://flora.example.com", "no_https"),
    Company("m3", "Букетная «Пион» (тест)", "Доставка цветов", "Санкт-Петербург", "Лиговский пр., 5", "+7 900 100-00-03", "pion@example.com", "https://pion.example.com", "no_mobile"),
    Company("m4", "Розы и Ко (тест)", "Цветы", "Санкт-Петербург", "", "+7 900 100-00-04", "roses@example.com", "https://roses.example.com", "ok"),
    Company("m5", "Тюльпан-маркет (тест)", "Цветы", "Санкт-Петербург", "", "+7 900 100-00-05", "", "", "none"),
    Company("m6", "Химчистка «Блеск» (тест)", "Химчистка", "Санкт-Петербург", "", "+7 900 100-00-06", "blesk@example.com", "", "none"),
    Company("m7", "Мастерская букетов «Сирень» (тест)", "Цветы", "Москва", "Тверская ул., 7", "+7 900 100-00-07", "siren@example.com", "http://siren.example.com", "unreachable"),
    Company("m8", "Цветы у метро (тест)", "Цветы", "Москва", "", "+7 900 100-00-08", "metro@example.com", "", "none"),
]


def mock_search(city: str, limit: int) -> list[Company]:
    return [c for c in MOCK_COMPANIES if not city or c.city == city][:limit]


def twogis_search(city: str, query: str, limit: int) -> list[Company]:
    """Официальный Catalog API 2GIS. НЕ ПРОВЕРЕН с реальным ключом: поля сверить с документацией."""
    key = env("TWO_GIS_API_KEY", "")
    if not key:
        raise RuntimeError("TWO_GIS_API_KEY не задан")
    r = httpx.get("https://catalog.api.2gis.com/3.0/items", timeout=15, params={
        "q": f"{query} {city}", "type": "branch", "page_size": min(limit, 50), "key": key,
        "fields": "items.contact_groups,items.rubrics,items.address_name"})
    r.raise_for_status()
    out = []
    for it in (r.json().get("result") or {}).get("items", []):
        contacts = [c for g in it.get("contact_groups") or [] for c in g.get("contacts") or []]
        get = lambda kind: next((str(c.get("value", "")) for c in contacts if c.get("type") == kind), "")  # noqa: E731
        out.append(Company(str(it.get("id")), it.get("name", "")[:160], ", ".join(x.get("name", "") for x in it.get("rubrics") or []),
                           city, it.get("address_name", "") or "", get("phone"), get("email"), get("website")))
    return out


# ------------------------------------------------------------------ анализ
def check_site(c: Company) -> str:
    if c.mock_site is not None:
        return c.mock_site
    if not c.website:
        return "none"
    url = c.website if c.website.startswith("http") else "http://" + c.website
    try:
        r = httpx.get(url, timeout=8, follow_redirects=True, headers={"User-Agent": "Mozilla/5.0 (site check)"})
    except httpx.HTTPError:
        return "unreachable"
    if r.status_code >= 400:
        return "unreachable"
    if r.url.scheme != "https":
        return "no_https"
    if 'name="viewport"' not in r.text[:200_000].lower():
        return "no_mobile"
    return "ok"


def classify(c: Company) -> str:
    text = f"{c.name} {c.rubric}".lower()
    return "flowers" if any(w in text for w in FLOWER_WORDS) else "other"


def score(site_status: str, email: str, phone: str) -> int:
    base = {"none": 60, "unreachable": 55, "no_https": 45, "no_mobile": 40}.get(site_status, 0)
    return base + (20 if email else 0) + (10 if phone else 0) if base else 0


def suppressed(s: Session, email: str, phone: str) -> bool:
    keys = [k for k in (email.lower(), phone) if k]
    return bool(keys) and s.scalar(select(func.count()).select_from(SuppressionEntry).where(SuppressionEntry.value.in_(keys))) > 0


# ------------------------------------------------------------------ предложение
def build_offer(s: Session, p: Prospect) -> tuple[str, str, str]:
    st = get_settings()
    plan = s.get(Plan, "page")
    price = plan.price_kop // 100 if plan else 1990
    token = secrets.token_urlsafe(24)
    sender = st.OPERATOR_NAME or "команда сервиса «Сайт с ИИ»"
    subject = f"{p.name}: сайт для заявок за {price} ₽"
    body = (f"Здравствуйте!\n\nПишет {sender}. Мы нашли «{p.name}» в открытом справочнике компаний ({p.city}) и заметили, "
            f"что {SITE_REASON.get(p.site_status, 'сайт можно улучшить')}.\n\n"
            f"Мы делаем сайты для цветочных магазинов: вы описываете магазин одним сообщением, ИИ собирает страницу "
            f"с ассортиментом, доставкой и формой заявки. Предпросмотр бесплатный, публикация {price} ₽ единоразово. "
            f"Заявки приходят в кабинет и Telegram.\n\n"
            f"Посмотреть и попробовать: {st.PUBLIC_BASE_URL}/?ref={p.ref_token}\n\n"
            f"Если это неинтересно, нажмите {st.PUBLIC_BASE_URL}/u/{token} — больше не напишем.\n")
    return subject, body, token


# ------------------------------------------------------------------ конвейер
def run_search(city: str, query: str = "цветы", limit: int = 50) -> dict:
    source = env("PROSPECT_SOURCE", "mock")
    if source == "off":
        log.info("поиск клиентов выключен (PROSPECT_SOURCE=off)")
        return {"found": 0, "new": 0, "qualified": 0, "queued": 0, "call_list": 0, "skipped": 0}
    companies = mock_search(city, limit) if source == "mock" else twogis_search(city, query, limit)
    stats = {"found": len(companies), "new": 0, "qualified": 0, "queued": 0, "call_list": 0, "skipped": 0}
    with system_session() as s:
        for c in companies:
            if s.scalar(select(Prospect).where(Prospect.source == source, Prospect.external_id == c.external_id)):
                stats["skipped"] += 1  # уже в базе: повторный поиск не дублирует компании и письма
                continue
            phone = normalize_phone(c.phone) or ""
            email = c.email.strip().lower() if re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", c.email.strip()) else ""
            p = Prospect(source=source, external_id=c.external_id, name=c.name, city=c.city, address=c.address, phone=phone,
                         email=email, website=c.website, niche=classify(c), ref_token=secrets.token_hex(12))
            p.site_status = check_site(c)
            p.score = score(p.site_status, email, phone) if p.niche == "flowers" else 0
            s.add(p)
            s.flush()
            stats["new"] += 1
            if p.niche != "flowers":
                p.status = "disqualified"
            elif p.site_status == "ok":
                p.status = "has_site"
            elif suppressed(s, email, phone):
                p.status = "opted_out"
            elif email:
                subject, body, token = build_offer(s, p)
                s.add(OutreachMessage(prospect_id=p.id, to_address=email, subject=subject, body=body, unsubscribe_token=token,
                                      is_test=env("EMAIL_MODE", "mock") == "mock"))
                p.status = "pending_review"
                stats["qualified"] += 1
                stats["queued"] += 1
            else:
                p.status = "call_list"  # без email — только в список для звонка оператором
                stats["qualified"] += 1
                stats["call_list"] += 1
        if stats["queued"]:
            notify_operator(s, f"Поиск клиентов ({city}): {stats['queued']} предложений ждут одобрения в админке.",
                            f"prospects:{city}:{utcnow():%Y%m%d%H%M%S}")
        audit(s, "prospecting.search", actor_kind="system", details={"city": city, "source": source, **stats})
    return stats


def review(message_id: uuid.UUID, admin_id: uuid.UUID, approve: bool, subject: str = "", body: str = "") -> str:
    from app.jobs import enqueue
    with system_session() as s:
        m = s.get(OutreachMessage, message_id)
        if m is None or m.status != "pending_review":
            return "Сообщение уже рассмотрено."
        p = s.get(Prospect, m.prospect_id)
        if subject.strip():
            m.subject = subject.strip()[:200]
        if body.strip():
            if f"/u/{m.unsubscribe_token}" not in body:
                return "В тексте должна остаться ссылка отказа."
            m.body = body.strip()[:5000]
        m.reviewed_by, m.reviewed_at = admin_id, utcnow()
        if approve:
            m.status, p.status = "approved", "approved"
            enqueue(s, "prospect_send", {"message_id": str(m.id)}, dedupe_key=f"send:{m.id}")
        else:
            m.status, p.status = "rejected", "rejected"
        audit(s, "prospecting.approve" if approve else "prospecting.reject", actor_kind="admin", actor_id=admin_id,
              entity_type="outreach", entity_id=m.id)
    return "Одобрено, письмо поставлено в очередь." if approve else "Отклонено."


def send_message(message_id: uuid.UUID) -> str:
    limit = int(env("OUTREACH_DAILY_LIMIT", "30"))
    day = utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
    with system_session() as s:
        m = s.get(OutreachMessage, message_id)
        if m is None or m.status != "approved":
            return "skip"
        p = s.get(Prospect, m.prospect_id)
        if suppressed(s, m.to_address, p.phone):
            m.status, p.status = "blocked", "opted_out"
            return "suppressed"
        sent_today = s.scalar(select(func.count()).select_from(OutreachMessage).where(OutreachMessage.sent_at >= day)) or 0
        if sent_today >= limit:
            raise RuntimeError(f"дневной лимит писем {limit} исчерпан")  # задача повторится позже
        mode = env("EMAIL_MODE", "mock")
        if mode == "off":
            m.status, m.error = "failed", "отправка почты выключена (EMAIL_MODE=off)"
            return "email_off"
        if mode == "mock":
            s.add(FakeEmail(to_address=m.to_address, subject=m.subject, body=m.body))
            log.info("[MOCK EMAIL] -> %s: %s", m.to_address, m.subject)
        else:
            _smtp_send(m.to_address, m.subject, m.body)
        m.status, m.sent_at, p.status = "sent", utcnow(), "sent"
        audit(s, "prospecting.sent", actor_kind="system", entity_type="outreach", entity_id=m.id, details={"mode": mode})
    return "sent"


def _smtp_send(to: str, subject: str, body: str) -> None:
    """Реальная отправка через SMTP. НЕ ПРОВЕРЕНА: нужны SMTP_HOST, SMTP_USER, SMTP_PASSWORD, SMTP_FROM и настройка SPF/DKIM домена."""
    msg = EmailMessage()
    msg["From"], msg["To"], msg["Subject"] = env("SMTP_FROM", ""), to, subject
    msg["List-Unsubscribe"] = "<" + body.split("нажмите ", 1)[-1].split(" ", 1)[0] + ">"
    msg.set_content(body)
    with smtplib.SMTP_SSL(env("SMTP_HOST", ""), int(env("SMTP_PORT", "465")), timeout=20) as smtp:
        smtp.login(env("SMTP_USER", ""), env("SMTP_PASSWORD", ""))
        smtp.send_message(msg)


def unsubscribe(token: str) -> bool:
    with system_session() as s:
        m = s.scalar(select(OutreachMessage).where(OutreachMessage.unsubscribe_token == token[:48]))
        if m is None:
            return False
        p = s.get(Prospect, m.prospect_id)
        for value in {m.to_address.lower(), p.phone} - {""}:
            if s.get(SuppressionEntry, value) is None:
                s.add(SuppressionEntry(value=value, reason="unsubscribe"))
        p.status = "opted_out"
        if m.status in ("pending_review", "approved"):
            m.status = "blocked"
        audit(s, "prospecting.unsubscribe", actor_kind="visitor", entity_type="outreach", entity_id=m.id)
    return True


def mark_converted(s: Session, ref: str, user_id: uuid.UUID) -> None:
    if not ref:
        return
    p = s.scalar(select(Prospect).where(Prospect.ref_token == ref[:32]))
    if p is not None and p.status != "opted_out":
        p.status = "converted"
        audit(s, "prospecting.converted", actor_kind="user", actor_id=user_id, entity_type="prospect", entity_id=p.id)
