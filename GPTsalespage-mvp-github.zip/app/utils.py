"""Утилиты: транслит и адреса, телефоны, хеши, ограничитель частоты, JSON-журнал без ПДн."""
from __future__ import annotations

import hashlib
import hmac
import json
import logging
import re
import secrets
import time
from collections import deque
from datetime import date

_TR = {"а": "a", "б": "b", "в": "v", "г": "g", "д": "d", "е": "e", "ё": "e", "ж": "zh", "з": "z", "и": "i",
       "й": "y", "к": "k", "л": "l", "м": "m", "н": "n", "о": "o", "п": "p", "р": "r", "с": "s", "т": "t",
       "у": "u", "ф": "f", "х": "h", "ц": "ts", "ч": "ch", "ш": "sh", "щ": "shch", "ъ": "", "ы": "y",
       "ь": "", "э": "e", "ю": "yu", "я": "ya"}
RESERVED_SLUGS = {"www", "admin", "api", "app", "mail", "support", "help", "static", "assets", "login", "test"}
SLUG_RE = re.compile(r"^[a-z0-9](?:[a-z0-9-]{1,38}[a-z0-9])$")


def slugify(text: str) -> str:
    s = "".join(_TR.get(c, c) for c in text.lower()).replace(" ", "-")
    s = re.sub(r"[^a-z0-9-]", "", s)
    s = re.sub(r"-{2,}", "-", s).strip("-")
    return s[:36].strip("-") or "site"


def valid_slug(slug: str) -> bool:
    return bool(SLUG_RE.match(slug)) and slug not in RESERVED_SLUGS


def normalize_phone(raw: str | None) -> str | None:
    if not raw:
        return None
    d = re.sub(r"\D", "", raw)
    if len(d) == 11 and d[0] in "78":
        d = "7" + d[1:]
    elif len(d) == 10:
        d = "7" + d
    return d if len(d) == 11 and d[0] == "7" else None


def format_phone(p: str) -> str:
    return f"+7 {p[1:4]} {p[4:7]}-{p[7:9]}-{p[9:11]}"


def mask_phone(p: str | None) -> str:
    return f"{p[:4]}***{p[-2:]}" if p and len(p) > 6 else "-"


def token() -> str:
    return secrets.token_urlsafe(32)


def sha256(value: str) -> str:
    return hashlib.sha256(value.encode()).hexdigest()


def hmac_hex(secret: str, body: bytes) -> str:
    return hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()


def visitor_hash(secret: str, ip: str, ua: str) -> str:
    """Соль меняется каждый день: посетителя нельзя отследить дольше суток, сырой IP не хранится."""
    return hashlib.sha256(f"{secret}|{date.today().isoformat()}|{ip}|{ua}".encode()).hexdigest()[:24]


class RateLimiter:
    def __init__(self, limit: int, window: float = 60.0) -> None:
        self.limit, self.window = limit, window
        self.hits: dict[str, deque[float]] = {}

    def allow(self, key: str) -> bool:
        now = time.monotonic()
        q = self.hits.setdefault(key, deque())
        while q and now - q[0] >= self.window:
            q.popleft()
        if len(q) >= self.limit:
            return False
        q.append(now)
        if len(self.hits) > 50_000:  # защита памяти
            self.hits = {k: v for k, v in self.hits.items() if v}
        return True


_PHONE_RE = re.compile(r"(?:\+?7|8)\d{10}")
_SECRET_RE = re.compile(r"(token|secret|password|key)=([^&\s]+)", re.I)


class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        msg = record.getMessage()
        msg = _PHONE_RE.sub(lambda m: mask_phone(m.group(0)), msg)
        msg = _SECRET_RE.sub(r"\1=***", msg)
        data = {"ts": self.formatTime(record), "level": record.levelname, "logger": record.name, "msg": msg}
        if record.exc_info:
            data["exc"] = self.formatException(record.exc_info)[-2000:]
        return json.dumps(data, ensure_ascii=False)


def setup_logging(level: int = logging.INFO) -> None:
    root = logging.getLogger()
    if any(getattr(h, "_sp", False) for h in root.handlers):
        return
    h = logging.StreamHandler()
    h.setFormatter(JsonFormatter())
    h._sp = True  # type: ignore[attr-defined]
    root.addHandler(h)
    root.setLevel(level)
    for noisy in ("httpx", "httpcore", "sqlalchemy.engine"):
        logging.getLogger(noisy).setLevel(logging.WARNING)
