"""Диалог сбора сведений о бизнесе (первая ниша: цветочные магазины).

Каждый ответ сохраняется сообщением и фактом. Факты из ответов владельца считаются
подтверждёнными им самим; на сайт попадают только они. Проверки ниши и безопасности
выполняются на сервере.
"""
from __future__ import annotations

import re
import secrets
import uuid
from dataclasses import dataclass, field
from typing import Optional

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.content import is_flower_business, unsafe_reason
from app.db import system_session, utcnow
from app.models import Business, BusinessFact, Conversation, Message, Project, Site
from app.utils import normalize_phone, slugify, valid_slug

SKIP_WORDS = {"нет", "-", "—", "пропустить", "не нужно", "не хочу"}


@dataclass(frozen=True)
class Question:
    key: str
    text: str
    chips: tuple[str, ...] = ()
    optional: bool = False
    multi: bool = False


QUESTIONS: list[Question] = [
    Question("name", "Как называется ваш магазин?"),
    Question("about", "Расскажите в одном-двух предложениях, чем вы занимаетесь. Например: «авторские букеты и доставка цветов»."),
    Question("city", "В каком городе вы работаете?"),
    Question("assortment", "Что вы продаёте? Выберите варианты или напишите своё.",
             ("Авторские букеты", "Розы", "Композиции в коробках", "Свадебная флористика", "Цветы в горшках", "Подписка на цветы"), multi=True),
    Question("prices", "Какие цены можно показать на сайте? Например: «букеты от 2500 ₽». Напишите «нет», если цены показывать не нужно.", optional=True),
    Question("delivery", "Как устроена доставка: районы, сроки, стоимость? Только то, что готовы показать покупателям. Напишите «нет», если доставки нет.", optional=True),
    Question("payment", "Какие способы оплаты вы принимаете?",
             ("Наличные", "Карта при получении", "Перевод по СБП", "Онлайн-оплата"), multi=True),
    Question("advantages", "Чем вы отличаетесь от других? Перечислите 2–4 преимущества своими словами, через точку с запятой."),
    Question("audience", "Кто ваши основные покупатели?",
             ("Дарят цветы близким", "Компании и офисы", "Свадьбы и мероприятия", "Покупают для себя"), multi=True),
    Question("goal", "Какое действие посетителя для вас главное?", ("Оставить заявку", "Позвонить", "Написать в мессенджер")),
    Question("phone", "Телефон для покупателей."),
    Question("messengers", "Номер WhatsApp и/или ник Telegram (например, @flowers_shop). Напишите «нет», если не нужно.", optional=True),
    Question("address", "Адрес магазина или точки самовывоза. Напишите «нет», если его нет.", optional=True),
    Question("hours", "Часы работы, например «ежедневно 9:00–21:00». Или «нет».", optional=True),
    Question("reviews", "Есть ли реальные отзывы покупателей, которые можно показать? Вставьте 1–3 отзыва в формате «Имя: текст», каждый с новой строки. Или «нет».", optional=True),
    Question("style", "Какой стиль сайта вам ближе?", ("Нежный", "Природный", "Яркий", "Премиальный")),
]
QUESTION_KEYS = [q.key for q in QUESTIONS]


@dataclass
class Reply:
    ok: bool
    message: str
    question: Optional[Question] = None
    done: bool = False
    facts: dict = field(default_factory=dict)


def facts_of(s: Session, business_id: uuid.UUID) -> dict[str, str]:
    rows = s.scalars(select(BusinessFact).where(BusinessFact.business_id == business_id)).all()
    return {f.key: f.value for f in rows}


def _set_fact(s: Session, owner_id: uuid.UUID, business_id: uuid.UUID, key: str, value: str) -> None:
    row = s.scalar(select(BusinessFact).where(BusinessFact.business_id == business_id, BusinessFact.key == key))
    if row is None:
        s.add(BusinessFact(owner_id=owner_id, business_id=business_id, key=key, value=value, confirmed_at=utcnow()))
    else:
        row.value, row.confirmed_at = value, utcnow()


def unique_slug(base: str) -> str:
    """Проверка по всем сайтам платформы (RLS скрыл бы чужие адреса, поэтому системная сессия)."""
    base = slugify(base)
    if not valid_slug(base):
        base = f"shop-{base}"[:36].strip("-")
    with system_session() as s:
        taken = set(s.scalars(select(Site.slug).where(Site.slug.like(f"{base}%"))).all())
    if base not in taken and valid_slug(base):
        return base
    for _ in range(50):
        cand = f"{base[:30]}-{secrets.token_hex(2)}"
        if cand not in taken:
            return cand
    raise RuntimeError("не удалось подобрать адрес")


def start_project(s: Session, owner_id: uuid.UUID, title: str = "Мой сайт") -> tuple[Project, Conversation, Site]:
    biz = Business(owner_id=owner_id, name="", niche="flowers")
    s.add(biz)
    s.flush()
    proj = Project(owner_id=owner_id, business_id=biz.id, title=title[:120] or "Мой сайт")
    s.add(proj)
    s.flush()
    conv = Conversation(owner_id=owner_id, project_id=proj.id)
    site = Site(owner_id=owner_id, project_id=proj.id, slug=f"draft-{secrets.token_hex(5)}")
    s.add_all([conv, site])
    s.flush()
    s.add(Message(owner_id=owner_id, conversation_id=conv.id, role="assistant", content=INTRO))
    return proj, conv, site


INTRO = ("Опишите бизнес одним сообщением: название, город, что продаёте, цены, доставку и телефон. Например: "
         "«Цветочная лавка «Ромашка», Санкт-Петербург. Авторские букеты и розы, букеты от 2500 ₽, доставка по городу. "
         "Оплата картой и по СБП. Телефон +7 921 000-00-00». Недостающее я уточню. "
         "Можно и по шагам: тогда начните с названия магазина.")


def current_question(conv: Conversation) -> Optional[Question]:
    return QUESTIONS[conv.step] if conv.step < len(QUESTIONS) else None


def normalize_answer(q: Question, raw: str) -> tuple[Optional[dict[str, str]], Optional[str]]:
    """(факты, ошибка). Возвращает словарь фактов, потому что один ответ может дать несколько."""
    text = re.sub(r"[\x00-\x08\x0b-\x1f\x7f]", " ", raw).strip()
    if not text:
        return None, "Напишите ответ или нажмите один из вариантов."
    if len(text) > 600:
        return None, "Ответ слишком длинный: до 600 символов."
    if q.optional and text.lower() in SKIP_WORDS:
        return {q.key: ""}, None
    if q.key == "phone":
        phone = normalize_phone(text)
        return ({"phone": phone}, None) if phone else (None, "Укажите российский номер, например +7 912 345-67-89.")
    if q.key == "messengers":
        out = {"whatsapp": "", "telegram": ""}
        tg = re.search(r"@([A-Za-z0-9_]{5,32})", text)
        if tg:
            out["telegram"] = tg.group(1)
        wa = normalize_phone(re.sub(r"@[A-Za-z0-9_]+", "", text))
        if wa:
            out["whatsapp"] = wa
        if not tg and not wa:
            return None, "Не нашёл номер WhatsApp или ник Telegram. Пример: «+7 912 345-67-89, @flowers_shop» или «нет»."
        return out, None
    reason = unsafe_reason(text)
    if reason:
        return None, f"Так написать нельзя: {reason}."
    if q.key == "name" and not (2 <= len(text) <= 60):
        return None, "Название должно быть от 2 до 60 символов."
    if q.key == "about" and not is_flower_business(text):
        return None, "Сейчас платформа работает только для цветочных магазинов и флористов. Опишите, какие цветы или букеты вы продаёте."
    if q.key == "style" and text not in q.chips:
        return None, "Выберите один из вариантов стиля."
    return {q.key: text}, None


def answer(s: Session, owner_id: uuid.UUID, conv: Conversation, text: str) -> Reply:
    q = current_question(conv)
    if q is None:
        return Reply(ok=True, message="Все сведения собраны. Можно создавать сайт.", done=True)
    s.add(Message(owner_id=owner_id, conversation_id=conv.id, role="user", content=text[:600]))
    facts, error = normalize_answer(q, text)
    if error:
        s.add(Message(owner_id=owner_id, conversation_id=conv.id, role="assistant", content=error))
        return Reply(ok=False, message=error, question=q)
    proj = s.get(Project, conv.project_id)
    assert proj is not None
    for k, v in (facts or {}).items():
        _set_fact(s, owner_id, proj.business_id, k, v)
    if q.key == "name":
        biz = s.get(Business, proj.business_id)
        biz.name = facts["name"]
        proj.title = facts["name"]
        site = s.scalar(select(Site).where(Site.project_id == proj.id))
        if site and site.status == "draft" and site.slug.startswith("draft-"):
            site.slug = unique_slug(facts["name"])
    conv.step += 1
    _skip_known(conv, facts_of(s, proj.business_id))
    nxt = current_question(conv)
    if nxt is None:
        conv.status = "completed"
        msg = "Спасибо, сведений достаточно. Нажмите «Создать сайт», и я соберу первую версию."
        s.add(Message(owner_id=owner_id, conversation_id=conv.id, role="assistant", content=msg))
        return Reply(ok=True, message=msg, done=True, facts=facts or {})
    s.add(Message(owner_id=owner_id, conversation_id=conv.id, role="assistant", content=nxt.text))
    return Reply(ok=True, message=nxt.text, question=nxt, facts=facts or {})


def update_facts(s: Session, owner_id: uuid.UUID, business_id: uuid.UUID, values: dict[str, str]) -> list[str]:
    """Правка сведений из формы. Те же проверки, что и в диалоге."""
    errors = []
    by_key = {q.key: q for q in QUESTIONS}
    for key, raw in values.items():
        q = by_key.get(key)
        if q is None or key == "messengers":
            continue
        facts, err = normalize_answer(Question(q.key, q.text, q.chips, True, q.multi), raw)
        if err:
            errors.append(f"{key}: {err}")
            continue
        for k, v in (facts or {}).items():
            _set_fact(s, owner_id, business_id, k, v)
    return errors


# ------------------------------------------------------------------ короткий промт
def _answered(q: Question, facts: dict[str, str]) -> bool:
    if q.key == "messengers":
        return "whatsapp" in facts or "telegram" in facts or "messengers" in facts
    return q.key in facts


def _skip_known(conv: Conversation, facts: dict[str, str]) -> None:
    """Пропускает вопросы, ответ на которые уже известен (например, из промта)."""
    while conv.step < len(QUESTIONS) and _answered(QUESTIONS[conv.step], facts):
        conv.step += 1


def start_from_prompt(s: Session, owner_id: uuid.UUID, conv: Conversation, text: str) -> Reply:
    """Описание бизнеса одним сообщением. В факты попадает только найденное в тексте и прошедшее проверку."""
    from app.content import unsafe_reason
    from app.intake import extract_facts
    text = (text or "").strip()[:2000]
    s.add(Message(owner_id=owner_id, conversation_id=conv.id, role="user", content=text))
    if len(text) < 20:
        msg = "Опишите бизнес чуть подробнее: название, город, что продаёте, телефон."
        s.add(Message(owner_id=owner_id, conversation_id=conv.id, role="assistant", content=msg))
        return Reply(ok=False, message=msg, question=current_question(conv))
    reason = unsafe_reason(text)
    if reason:
        msg = f"Не могу принять описание: {reason}."
        s.add(Message(owner_id=owner_id, conversation_id=conv.id, role="assistant", content=msg))
        return Reply(ok=False, message=msg, question=current_question(conv))
    proj = s.get(Project, conv.project_id)
    raw = extract_facts(text)
    if "telegram" in raw:
        raw["messengers"] = raw.pop("telegram")
    found: dict[str, str] = {}
    for q in QUESTIONS:
        if q.key not in raw:
            continue
        values, error = normalize_answer(q, raw[q.key])
        if error or not values:
            continue  # неподходящее значение не сохраняем, спросим в диалоге
        for k, v in values.items():
            _set_fact(s, owner_id, proj.business_id, k, v)
            found[k] = v
        if q.key == "name":
            biz = s.get(Business, proj.business_id)
            biz.name = proj.title = values["name"]
            site = s.scalar(select(Site).where(Site.project_id == proj.id))
            if site and site.status == "draft" and site.slug.startswith("draft-"):
                site.slug = unique_slug(values["name"])
    for q in QUESTIONS:  # необязательное, чего нет в тексте, не спрашиваем: можно дополнить в «Сведениях»
        if q.optional and not _answered(q, found):
            _set_fact(s, owner_id, proj.business_id, q.key, "")
    facts = facts_of(s, proj.business_id)
    _skip_known(conv, facts)
    labels = {"name": "название", "city": "город", "phone": "телефон", "assortment": "ассортимент", "payment": "оплата",
              "prices": "цены", "delivery": "доставка", "hours": "часы работы", "address": "адрес", "about": "описание",
              "whatsapp": "WhatsApp", "telegram": "Telegram"}
    got = ", ".join(labels.get(k, k) for k in found) or "ничего конкретного"
    nxt = current_question(conv)
    if nxt is None:
        conv.status = "completed"
        msg = f"Понял: {got}. Сведений достаточно, нажмите «Создать сайт»."
        s.add(Message(owner_id=owner_id, conversation_id=conv.id, role="assistant", content=msg))
        return Reply(ok=True, message=msg, done=True, facts=found)
    msg = f"Понял: {got}. Уточню недостающее.\n\n{nxt.text}"
    s.add(Message(owner_id=owner_id, conversation_id=conv.id, role="assistant", content=msg))
    return Reply(ok=True, message=msg, question=nxt, facts=found)
