"""Схема блоков сайта, темы, ограничение ниши, безопасность содержимого и проверка фактов.

ИИ (или запасной генератор) возвращает JSON по этой схеме; сервер валидирует его и только
потом сохраняет версию. HTML модель не пишет: страницу собирает шаблон с экранированием.
"""
from __future__ import annotations

import re
from typing import Any, Literal, Optional

from pydantic import BaseModel, Field, ValidationError, field_validator, model_validator

# ------------------------------------------------------------------ темы
PALETTES: dict[str, dict[str, str]] = {
    "rose":     {"bg": "#FFF8F7", "surface": "#FFFFFF", "text": "#2B1B1F", "muted": "#7A5C63", "accent": "#B4385A", "on_accent": "#FFFFFF", "soft": "#FBE7EC"},
    "sage":     {"bg": "#F6F8F4", "surface": "#FFFFFF", "text": "#1F2A1F", "muted": "#5E6B5C", "accent": "#4E7A4C", "on_accent": "#FFFFFF", "soft": "#E5EEE2"},
    "peony":    {"bg": "#FFF7FB", "surface": "#FFFFFF", "text": "#2A1730", "muted": "#74607A", "accent": "#C04A8E", "on_accent": "#FFFFFF", "soft": "#F9E3F0"},
    "noir":     {"bg": "#111111", "surface": "#1B1B1B", "text": "#F4EFE8", "muted": "#B7AEA3", "accent": "#C9A46A", "on_accent": "#111111", "soft": "#262320"},
    "sunny":    {"bg": "#FFFBF2", "surface": "#FFFFFF", "text": "#2B2312", "muted": "#7A6A45", "accent": "#C77A12", "on_accent": "#FFFFFF", "soft": "#FDF0D5"},
    "lavender": {"bg": "#F8F7FF", "surface": "#FFFFFF", "text": "#1E1B33", "muted": "#615C80", "accent": "#6A5ACD", "on_accent": "#FFFFFF", "soft": "#ECE9FF"},
}
PREMIUM_PALETTE = "noir"
LAYOUTS = ("classic", "split", "minimal")
FONTS = ("sans", "serif", "rounded")
BUTTONS = ("rounded", "pill", "square")
BLOCK_TYPES = ("hero", "catalog", "benefits", "delivery", "payment", "reviews", "faq", "contacts", "lead_form")
FORM_FIELDS = ("name", "phone", "comment", "date")
ILLUSTRATIONS = ("bouquet", "tulips", "petals")  # собственные SVG платформы, не фото магазина


class Theme(BaseModel):
    palette: Literal["rose", "sage", "peony", "noir", "sunny", "lavender"] = "rose"
    layout: Literal["classic", "split", "minimal"] = "classic"
    font: Literal["sans", "serif", "rounded"] = "sans"
    buttons: Literal["rounded", "pill", "square"] = "rounded"
    button_color: Optional[str] = None  # #RRGGBB, если владелец попросил свой цвет кнопок

    @field_validator("button_color")
    @classmethod
    def _hex(cls, v: Optional[str]) -> Optional[str]:
        if v is not None and not re.fullmatch(r"#[0-9A-Fa-f]{6}", v):
            raise ValueError("цвет должен быть в формате #RRGGBB")
        return v


def _t(max_len: int, min_len: int = 0) -> Any:
    return Field(default="", max_length=max_len, min_length=min_len)


class HeroData(BaseModel):
    title: str = Field(min_length=3, max_length=90)
    subtitle: str = _t(240)
    cta_text: str = Field(default="Оставить заявку", min_length=2, max_length=32)
    image: Optional[str] = None  # asset:<uuid> | illustration:<name>


class CatalogItem(BaseModel):
    name: str = Field(min_length=2, max_length=60)
    price_text: str = _t(40)
    description: str = _t(160)
    image: Optional[str] = None


class CatalogData(BaseModel):
    title: str = Field(default="Каталог", max_length=60)
    items: list[CatalogItem] = Field(default_factory=list, max_length=12)


class Benefit(BaseModel):
    title: str = Field(min_length=2, max_length=60)
    text: str = _t(200)


class BenefitsData(BaseModel):
    title: str = Field(default="Почему мы", max_length=60)
    items: list[Benefit] = Field(default_factory=list, max_length=6)


class TextData(BaseModel):
    title: str = Field(max_length=60)
    text: str = _t(500)


class PaymentData(BaseModel):
    title: str = Field(default="Оплата", max_length=60)
    methods: list[str] = Field(default_factory=list, max_length=8)


class Review(BaseModel):
    author: str = Field(min_length=1, max_length=40)
    text: str = Field(min_length=2, max_length=300)


class ReviewsData(BaseModel):
    title: str = Field(default="Отзывы", max_length=60)
    items: list[Review] = Field(default_factory=list, max_length=6)


class FaqItem(BaseModel):
    q: str = Field(min_length=3, max_length=120)
    a: str = Field(min_length=2, max_length=400)


class FaqData(BaseModel):
    title: str = Field(default="Вопросы и ответы", max_length=60)
    items: list[FaqItem] = Field(default_factory=list, max_length=8)


class ContactsData(BaseModel):
    title: str = Field(default="Контакты", max_length=60)  # сами контакты берутся из фактов, не из ИИ


class LeadFormData(BaseModel):
    title: str = Field(default="Оформить заказ", max_length=60)
    button_text: str = Field(default="Отправить заявку", min_length=2, max_length=32)
    fields: list[str] = Field(default_factory=lambda: list(FORM_FIELDS))

    @field_validator("fields")
    @classmethod
    def _fields(cls, v: list[str]) -> list[str]:
        v = [f for f in dict.fromkeys(v) if f in FORM_FIELDS]
        if "phone" not in v:
            v.insert(0, "phone")  # телефон обязателен: без него заявка бесполезна
        return v


DATA_MODELS: dict[str, type[BaseModel]] = {
    "hero": HeroData, "catalog": CatalogData, "benefits": BenefitsData, "delivery": TextData,
    "payment": PaymentData, "reviews": ReviewsData, "faq": FaqData, "contacts": ContactsData,
    "lead_form": LeadFormData,
}


class Block(BaseModel):
    id: str = Field(pattern=r"^[a-z0-9_]{2,32}$")
    type: Literal["hero", "catalog", "benefits", "delivery", "payment", "reviews", "faq", "contacts", "lead_form"]
    visible: bool = True
    data: dict

    @model_validator(mode="after")
    def _data(self) -> "Block":
        self.data = DATA_MODELS[self.type].model_validate(self.data).model_dump()
        return self


class Seo(BaseModel):
    title: str = Field(min_length=5, max_length=70)
    description: str = Field(min_length=10, max_length=180)


class SiteContent(BaseModel):
    schema_version: int = 1
    theme: Theme = Field(default_factory=Theme)
    seo: Seo
    blocks: list[Block] = Field(min_length=3, max_length=14)

    @model_validator(mode="after")
    def _rules(self) -> "SiteContent":
        types = [b.type for b in self.blocks]
        for required in ("hero", "lead_form", "contacts"):
            if required not in types:
                raise ValueError(f"обязательный блок отсутствует: {required}")
        ids = [b.id for b in self.blocks]
        if len(ids) != len(set(ids)):
            raise ValueError("идентификаторы блоков повторяются")
        if types[0] != "hero":
            raise ValueError("первым должен идти главный блок")
        return self


def validate_content(raw: Any) -> tuple[Optional[dict], list[str]]:
    try:
        return SiteContent.model_validate(raw).model_dump(), []
    except ValidationError as exc:
        return None, [f"{'.'.join(str(p) for p in e['loc'])}: {e['msg']}" for e in exc.errors()[:10]]


# ------------------------------------------------------------------ ниша и безопасность
FLOWER_TERMS = ("цвет", "букет", "флор", "роз", "тюльпан", "пион", "хризантем", "композици", "растени", "гортенз")
BANNED_TERMS = ("казино", "ставк", "букмекер", "наркот", "закладк", "оружи", "боеприпас", "криптовалют",
                "инвестиц", "заработок без", "порно", "эскорт", "интим", "кредит без", "микрозайм", "займ",
                "пароль", "cvv", "код из смс", "данные карты", "вейп", "табак", "алкогол")
# Совпадение только с начала слова: иначе «ставк» срабатывает на «доставка», «займ» на «займёмся».
# «Перевод на карту» не запрещён: это обычный способ оплаты в цветочных магазинах.
_BANNED_RE = [(t, re.compile(r"(?<![а-яёa-z0-9])" + (r"займ(?:ы|а|ов)?\b" if t == "займ" else re.escape(t))))
              for t in BANNED_TERMS]
_LINK_RE = re.compile(r"(https?://|www\.|javascript:|<|>|\.ru/|\.com/)", re.I)


def is_flower_business(text: str) -> bool:
    t = text.lower()
    return any(term in t for term in FLOWER_TERMS)


def unsafe_reason(text: str) -> Optional[str]:
    t = text.lower()
    for term, rx in _BANNED_RE:
        if rx.search(t):
            return f"запрещённая тематика или фишинговый признак: «{term}»"
    if _LINK_RE.search(text):
        return "ссылки и HTML в тексте не допускаются"
    return None


# ------------------------------------------------------------------ проверка фактов
_CLAIM_RULES = [
    (re.compile(r"гарант", re.I), "гарантии"),
    (re.compile(r"(лучш|№\s*1|номер один|самы[ейх] (свеж|низк|дешёв|дешев|быстр))", re.I), "превосходная степень без подтверждения"),
    (re.compile(r"(лет на рынке|лет опыта|тысяч[и]? (клиентов|заказов)|довольных клиентов)", re.I), "неподтверждённые показатели"),
]
_CONDITIONAL = {"бесплатн": "бесплатные условия", "скидк": "скидки", "акци": "акции", "круглосуточ": "круглосуточная работа"}


def _numbers(text: str) -> set[str]:
    compact = re.sub(r"(?<=\d)[\s\u00a0](?=\d{3}\b)", "", text)
    return set(re.findall(r"\d+", compact))


def content_texts(content: dict) -> list[tuple[str, str]]:
    out: list[tuple[str, str]] = [("seo.title", content["seo"]["title"]), ("seo.description", content["seo"]["description"])]

    def walk(prefix: str, value: Any) -> None:
        if isinstance(value, str):
            if prefix.endswith((".image", ".fields")) or ".fields." in prefix:
                return
            out.append((prefix, value))
        elif isinstance(value, dict):
            for k, v in value.items():
                walk(f"{prefix}.{k}", v)
        elif isinstance(value, list):
            for i, v in enumerate(value):
                walk(f"{prefix}.{i}", v)

    for b in content["blocks"]:
        if b.get("visible", True):
            walk(f"{b['id']}", b["data"])
    return out


def check_facts(content: dict, facts: dict[str, str]) -> list[str]:
    """Нарушения: числа, которых нет в фактах, обещания без подтверждения, выдуманные отзывы."""
    facts_text = " ".join(facts.values()).lower()
    allowed_numbers = _numbers(facts_text)
    reviews_fact = facts.get("reviews", "").strip()
    problems: list[str] = []
    for path, text in content_texts(content):
        if not text:
            continue
        reason = unsafe_reason(text)
        if reason:
            problems.append(f"{path}: {reason}")
        extra = _numbers(text) - allowed_numbers
        if extra:
            problems.append(f"{path}: число {', '.join(sorted(extra))} не подтверждено вашими ответами")
        low = text.lower()
        for rx, label in _CLAIM_RULES:
            if rx.search(low) and not rx.search(facts_text):
                problems.append(f"{path}: {label}")
        for stem, label in _CONDITIONAL.items():
            if stem in low and stem not in facts_text:
                problems.append(f"{path}: {label} не подтверждены")
        if ".reviews" in path or path.startswith("reviews"):
            pass
    for b in content["blocks"]:
        if b["type"] == "reviews" and b.get("visible", True):
            if not reviews_fact:
                problems.append("reviews: отзывов нет в ваших ответах, блок отзывов нельзя показывать")
            else:
                for item in b["data"]["items"]:
                    if item["text"].strip().lower() not in reviews_fact.lower():
                        problems.append("reviews: текст отзыва не совпадает с отзывами, которые вы прислали")
    return sorted(set(problems))
