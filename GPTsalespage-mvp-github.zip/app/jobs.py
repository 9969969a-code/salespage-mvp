"""Очередь фоновых задач в PostgreSQL: выборка FOR UPDATE SKIP LOCKED, повторы с экспоненциальной
задержкой, защита от дублей по dedupe_key, обработчики «задача умерла», периодические задачи."""
from __future__ import annotations

import logging
import random
import threading
import time
import uuid
from datetime import timedelta
from typing import Any, Callable, Optional

from sqlalchemy import text
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.orm import Session

from app.db import system_session, utcnow
from app.models import Job

log = logging.getLogger("jobs")


def enqueue(s: Session, kind: str, payload: dict, dedupe_key: Optional[str] = None, delay_s: int = 0,
            max_attempts: int = 6) -> None:
    stmt = insert(Job).values(id=uuid.uuid4(), kind=kind, payload=payload, dedupe_key=dedupe_key, status="queued",
                              run_at=utcnow() + timedelta(seconds=delay_s), attempts=0, max_attempts=max_attempts,
                              last_error="", created_at=utcnow())
    s.execute(stmt.on_conflict_do_nothing(index_elements=["dedupe_key"]) if dedupe_key else stmt)


def _prospect_handlers() -> dict[str, Callable[[dict], Any]]:
    from app import prospecting
    return {
        "prospect_search": lambda p: str(prospecting.run_search(p.get("city", ""), p.get("query", "цветы"), int(p.get("limit", 50)))),
        "prospect_send": lambda p: prospecting.send_message(uuid.UUID(p["message_id"])),
        "subscription_reminders": lambda p: str(__import__("app.subscriptions", fromlist=["x"]).remind_expiring()),
        "client_outreach_send": lambda p: __import__("app.promotion", fromlist=["send"]).send(uuid.UUID(p["outreach_id"])),
    }


def _handlers() -> dict[str, Callable[[dict], Any]]:
    from app import analytics, billing, notify, publishing, sitegen

    def generate(p: dict) -> str:
        res = sitegen.run_generation(uuid.UUID(p["site_id"]))
        if res in ("generation", "fallback"):
            with system_session() as s:
                analytics.platform_event(s, "generation_done", owner_id=uuid.UUID(p["owner_id"]))
        return res

    def publish(p: dict) -> str:
        res = publishing.run_publication(uuid.UUID(p["publication_id"]))
        if res == "live":
            with system_session() as s:
                from app.models import Publication
                pub = s.get(Publication, uuid.UUID(p["publication_id"]))
                analytics.platform_event(s, "published", owner_id=pub.owner_id)
        return res

    def reconcile_stale(_: dict) -> str:
        pend = billing.stale_pending_payments()
        with system_session() as s:
            for provider, pid in pend:
                enqueue(s, "reconcile_payment", {"provider": provider, "payment_id": pid},
                        dedupe_key=f"reconcile-stale:{pid}:{utcnow():%Y%m%d%H%M}")
        return f"{len(pend)} pending"

    return {
        "generate_site": generate,
        **_prospect_handlers(),
        "publish": publish,
        "send_notification": lambda p: notify.send_notification(uuid.UUID(p["notification_id"])),
        "operator_alert": lambda p: notify.operator_alert(p["text"]),
        "reconcile_payment": lambda p: billing.reconcile_payment(p["provider"], p["payment_id"]),
        "expire_sites": lambda p: ",".join(publishing.expire_sites()) or "none",
        "reconcile_stale": reconcile_stale,
        "purge_events": lambda p: str(analytics.purge_old_events()),
    }


def _dead_hooks() -> dict[str, Callable[[dict, str], None]]:
    from app import notify, publishing
    return {
        "publish": lambda p, e: publishing.on_publication_dead(uuid.UUID(p["publication_id"]), e),
        "send_notification": lambda p, e: notify.on_notification_dead(uuid.UUID(p["notification_id"]), e),
        "generate_site": lambda p, e: _generation_dead(uuid.UUID(p["site_id"]), e),
    }


def _generation_dead(site_id: uuid.UUID, error: str) -> None:
    from app.models import Site
    with system_session() as s:
        site = s.get(Site, site_id)
        if site:
            site.generation_status, site.generation_error = "failed", error[:300]


CLAIM_SQL = text("""
UPDATE jobs SET status='running', attempts=attempts+1, locked_until=now() + interval '5 minutes'
WHERE id = (
  SELECT id FROM jobs
  WHERE (status='queued' AND run_at <= now()) OR (status='running' AND locked_until < now())
  ORDER BY run_at LIMIT 1 FOR UPDATE SKIP LOCKED)
RETURNING id, kind, payload, attempts, max_attempts
""")


def run_one() -> Optional[str]:
    with system_session() as s:
        row = s.execute(CLAIM_SQL).first()
    if row is None:
        return None
    job_id, kind, payload, attempts, max_attempts = row
    handler = _handlers().get(kind)
    try:
        if handler is None:
            raise RuntimeError(f"нет обработчика для {kind}")
        result = handler(payload)
        with system_session() as s:
            s.execute(text("UPDATE jobs SET status='done', finished_at=now(), last_error='' WHERE id=:i"), {"i": job_id})
        log.info("job %s %s: %s", kind, job_id, result)
        return f"{kind}:{result}"
    except Exception as exc:  # noqa: BLE001 — любая ошибка задачи ведёт к повтору или «смерти»
        err = f"{exc.__class__.__name__}: {exc}"[:500]
        retry_after = getattr(exc, "retry_after", None)
        if attempts >= max_attempts:
            with system_session() as s:
                s.execute(text("UPDATE jobs SET status='dead', last_error=:e, finished_at=now() WHERE id=:i"), {"e": err, "i": job_id})
            hook = _dead_hooks().get(kind)
            if hook:
                hook(payload, err)
            log.error("job %s %s dead: %s", kind, job_id, err)
            return f"{kind}:dead"
        delay = retry_after or min(3600, int(10 * 2 ** (attempts - 1) + random.uniform(0, 5)))
        with system_session() as s:
            s.execute(text("UPDATE jobs SET status='queued', last_error=:e, run_at=now() + make_interval(secs => :d) WHERE id=:i"),
                      {"e": err, "d": delay, "i": job_id})
        log.warning("job %s %s retry in %ss: %s", kind, job_id, delay, err)
        return f"{kind}:retry"


def run_pending(limit: int = 200) -> list[str]:
    """Выполнить все готовые задачи (для тестов и ручного запуска)."""
    done = []
    for _ in range(limit):
        r = run_one()
        if r is None:
            break
        done.append(r)
    return done


def schedule_periodic() -> None:
    now = utcnow()
    with system_session() as s:
        enqueue(s, "expire_sites", {}, dedupe_key=f"expire:{now:%Y%m%d%H}")
        enqueue(s, "reconcile_stale", {}, dedupe_key=f"stale:{now:%Y%m%d%H}{now.minute // 5}")
        enqueue(s, "purge_events", {}, dedupe_key=f"purge:{now:%Y%m%d}")
        enqueue(s, "subscription_reminders", {}, dedupe_key=f"subrem:{now:%Y%m%d}")
        from app.models import SystemFlag
        flag = s.get(SystemFlag, "prospecting")
        if flag is not None and flag.value == "on":  # ежедневный поиск включает оператор в админке
            import os
            for city in [c.strip() for c in os.getenv("PROSPECT_CITIES", "Санкт-Петербург").split(",") if c.strip()]:
                enqueue(s, "prospect_search", {"city": city}, dedupe_key=f"prospects:{city}:{now:%Y%m%d}")


def worker_loop(stop: threading.Event, idle_sleep: float = 1.0) -> None:
    last_sched = 0.0
    while not stop.is_set():
        if time.monotonic() - last_sched > 60:
            try:
                schedule_periodic()
            except Exception:  # noqa: BLE001
                log.exception("ошибка планировщика")
            last_sched = time.monotonic()
        try:
            if run_one() is None:
                stop.wait(idle_sleep)
        except Exception:  # noqa: BLE001
            log.exception("ошибка воркера")
            stop.wait(5)
