"""Уведомления владельцу: outbox в базе, отправка воркером с повторами, Telegram как первый канал.

Привязка Telegram: одноразовый токен (в базе хеш, 15 минут) → ссылка t.me/<бот>?start=<токен> →
webhook Telegram с секретным заголовком → канал владельца. Ввод chat_id вручную не предусмотрен.
TELEGRAM_MODE=fake: сообщения пишутся в таблицу fake_telegram_messages, в Telegram ничего не уходит.
"""
from __future__ import annotations

import hmac
import logging
import uuid
from dataclasses import dataclass
from datetime import timedelta
from typing import Optional

import httpx
from sqlalchemy import select, update
from sqlalchemy.orm import Session

from app.config import get_settings
from app.db import system_session, utcnow
from app.models import FakeTelegramMessage, Notification, NotificationChannel, TelegramLinkToken
from app.security import audit
from app.utils import format_phone, sha256, token

log = logging.getLogger("notify")


@dataclass
class SendResult:
    ok: bool
    retry_after: Optional[int] = None
    permanent: bool = False
    error: str = ""


class TemporaryFailure(Exception):
    def __init__(self, msg: str, retry_after: Optional[int] = None) -> None:
        super().__init__(msg)
        self.retry_after = retry_after


def telegram_send(chat_id: str, text: str) -> SendResult:
    st = get_settings()
    if st.TELEGRAM_MODE != "live":
        with system_session() as s:
            s.add(FakeTelegramMessage(chat_id=chat_id, text=text))
        return SendResult(ok=True)
    try:
        r = httpx.post(f"https://api.telegram.org/bot{st.TELEGRAM_BOT_TOKEN}/sendMessage", timeout=15,
                       json={"chat_id": chat_id, "text": text[:3900], "disable_web_page_preview": True})
    except httpx.HTTPError as exc:
        return SendResult(ok=False, error=exc.__class__.__name__)
    if r.status_code == 200:
        return SendResult(ok=True)
    if r.status_code == 429:
        try:
            ra = int(r.json().get("parameters", {}).get("retry_after", 30))
        except ValueError:
            ra = 30
        return SendResult(ok=False, retry_after=ra, error="429")
    if r.status_code in (400, 403):
        return SendResult(ok=False, permanent=True, error=f"HTTP {r.status_code}")
    return SendResult(ok=False, error=f"HTTP {r.status_code}")


def render_text(kind: str, p: dict) -> str:
    st = get_settings()
    if kind == "lead":
        lines = [f"Новая заявка с сайта {p.get('site', '')}", f"Имя: {p.get('name') or '—'}",
                 f"Телефон: {format_phone(p['phone']) if p.get('phone') else '—'}"]
        if p.get("wanted_date"):
            lines.append(f"Когда: {p['wanted_date']}")
        if p.get("comment"):
            lines.append(f"Комментарий: {p['comment']}")
        lines.append(f"Все заявки: {st.PUBLIC_BASE_URL}/cabinet/leads")
        return "\n".join(lines)
    if kind == "payment":
        return f"Оплата {p.get('amount')} ₽ подтверждена{' (ТЕСТОВЫЙ платёж)' if p.get('test') else ''}. Публикуем сайт."
    if kind == "subscription":
        return (f"Подписка оплачена: {p.get('amount')} ₽{' (ТЕСТОВЫЙ платёж)' if p.get('test') else ''}. "
                f"Обслуживание до {p.get('until')}.")
    if kind == "subscription_reminder":
        return (f"Подписка «{p.get('plan')}» для сайта {p.get('site')} заканчивается {p.get('until')}. "
                f"Продлить за {p.get('price')} ₽ можно в кабинете, раздел «Продвижение».")
    if kind == "published":
        return f"Сайт опубликован: {p.get('url')}"
    if kind == "publish_failed":
        return f"Публикация сайта {p.get('site')} не удалась. Мы уже получили сигнал и разбираемся."
    return str(p.get("text", ""))[:1000]


def notify_owner(s: Session, owner_id: uuid.UUID, kind: str, payload: dict, dedupe: str) -> None:
    """Создаёт уведомления в той же транзакции, что и событие (outbox)."""
    from app.jobs import enqueue
    channels = s.scalars(select(NotificationChannel).where(NotificationChannel.owner_id == owner_id,
                                                           NotificationChannel.status == "verified")).all()
    if not channels:
        s.add(Notification(owner_id=owner_id, kind=kind, payload=payload, status="skipped",
                           last_error="Telegram не подключён", dedupe_key=f"{dedupe}:none"))
        return
    for ch in channels:
        n = Notification(owner_id=owner_id, kind=kind, channel_id=ch.id, payload=payload, dedupe_key=f"{dedupe}:{ch.id}")
        s.add(n)
        s.flush()
        enqueue(s, "send_notification", {"notification_id": str(n.id)}, dedupe_key=f"notify:{n.id}", max_attempts=8)


def notify_operator(s: Session, text: str, dedupe: str) -> None:
    from app.jobs import enqueue
    enqueue(s, "operator_alert", {"text": text[:1000]}, dedupe_key=f"op:{dedupe}", max_attempts=5)


def send_notification(notification_id: uuid.UUID) -> str:
    with system_session() as s:
        n = s.get(Notification, notification_id)
        if n is None or n.status in ("sent", "dead"):
            return "nothing"
        ch = s.get(NotificationChannel, n.channel_id) if n.channel_id else None
        if ch is None or ch.status != "verified":
            n.status, n.last_error = "dead", "канал недоступен"
            return "no channel"
        n.attempts += 1
        chat_id, text = ch.address, render_text(n.kind, n.payload)
    res = telegram_send(chat_id, text)
    with system_session() as s:
        n = s.get(Notification, notification_id)
        if res.ok:
            n.status, n.sent_at, n.last_error = "sent", utcnow(), ""
            return "sent"
        n.last_error = res.error
        if res.permanent:
            n.status = "dead"
            s.execute(update(NotificationChannel).where(NotificationChannel.id == n.channel_id).values(status="unreachable"))
            audit(s, "telegram.unreachable", actor_kind="system", owner_id=n.owner_id, entity_type="channel", entity_id=n.channel_id)
            return "unreachable"
    raise TemporaryFailure(f"Telegram: {res.error}", res.retry_after)


def on_notification_dead(notification_id: uuid.UUID, error: str) -> None:
    with system_session() as s:
        n = s.get(Notification, notification_id)
        if n and n.status != "sent":
            n.status, n.last_error = "dead", error[:300]
            notify_operator(s, f"Уведомление {n.kind} не доставлено: {error[:150]}", f"dead:{n.id}")


def operator_alert(text: str) -> str:
    chat = get_settings().OPERATOR_TELEGRAM_CHAT_ID
    if not chat:
        log.warning("ОПОВЕЩЕНИЕ ОПЕРАТОРУ (чат не настроен): %s", text)
        return "logged"
    res = telegram_send(chat, f"[оператор] {text}")
    if not res.ok and not res.permanent:
        raise TemporaryFailure(res.error, res.retry_after)
    return "sent" if res.ok else "failed"


# ------------------------------------------------------------------ привязка Telegram
def create_link(s: Session, owner_id: uuid.UUID) -> str:
    raw = token()[:32]
    s.add(TelegramLinkToken(owner_id=owner_id, token_hash=sha256(raw), expires_at=utcnow() + timedelta(minutes=15)))
    return f"https://t.me/{get_settings().TELEGRAM_BOT_USERNAME}?start={raw}"


def handle_telegram_update(secret_header: str, update_data: dict) -> tuple[int, str]:
    if not hmac.compare_digest(secret_header or "", get_settings().TELEGRAM_WEBHOOK_SECRET):
        return 401, "bad secret"
    msg = update_data.get("message") or {}
    text = str(msg.get("text", ""))
    chat_id = str((msg.get("chat") or {}).get("id", ""))
    if not text.startswith("/start ") or not chat_id:
        return 200, "ignored"
    raw = text.split(" ", 1)[1].strip()[:64]
    with system_session() as s:
        t = s.scalar(select(TelegramLinkToken).where(TelegramLinkToken.token_hash == sha256(raw)).with_for_update())
        if t is None or t.used_at is not None or t.expires_at < utcnow():
            return 200, "invalid token"
        t.used_at = utcnow()
        s.execute(update(NotificationChannel).where(NotificationChannel.owner_id == t.owner_id,
                                                    NotificationChannel.kind == "telegram").values(status="removed"))
        s.add(NotificationChannel(owner_id=t.owner_id, kind="telegram", address=chat_id))
        audit(s, "telegram.linked", actor_kind="webhook", owner_id=t.owner_id, entity_type="channel", entity_id=chat_id)
    telegram_send(chat_id, "Готово: уведомления о заявках будут приходить сюда.")
    return 200, "linked"
