#!/usr/bin/env bash
# Установка платформы на чистый VPS Ubuntu 24.04 одной командой (тестовый стенд: оплата, вход, ИИ, Telegram — тестовые).
#
#   1. Загрузите архив на сервер:  scp salespage_mvp.zip root@IP:/root/
#   2. На сервере:                  apt-get install -y unzip && unzip salespage_mvp.zip && bash salespage/deploy/install.sh
#   Свой домен:                     DOMAIN=platform.example.ru SITES_DOMAIN=sites.example.ru bash salespage/deploy/install.sh
#
# Без DOMAIN используется бесплатный адрес <IP>.sslip.io (сайты: <slug>.sites.<IP>.sslip.io).
# Платформа закрывается паролем: свой можно задать STAND_PASSWORD=..., иначе случайный (выводится в конце).
# Сайты клиентов и вебхуки открыты. Демо-проект «Ромашка» создаётся автоматически (DEMO=0 — без него).
# Повторный запуск безопасен: обновляет код, применяет миграции, перезапускает службы, данные и пароли сохраняет.
set -euo pipefail
[ "$(id -u)" = 0 ] || { echo "Запустите от root: sudo bash $0"; exit 1; }
SRC="$(cd "$(dirname "$0")/.." && pwd)"
APP=/opt/salespage
ENVF="$APP/.env"
MODE="${MODE:-stand}"             # stand — тестовый стенд; production — боевой (ключи вписываются в .env)
SKIP_SYSTEMD="${SKIP_SYSTEMD:-0}"   # 1 — только для проверки установки в среде без systemd
export DEBIAN_FRONTEND=noninteractive

log() { printf '\n== %s\n' "$*"; }
rand() { python3 -c "import secrets; print(secrets.token_urlsafe($1))"; }

log "1/8 Пакеты"
apt-get update -q >/dev/null
apt-get install -y -q postgresql python3-venv python3-pip caddy curl rsync >/dev/null

log "2/8 Адрес"
if [ -z "${DOMAIN:-}" ]; then
  IP="$(curl -fsS --max-time 5 https://api.ipify.org 2>/dev/null || hostname -I | awk '{print $1}')"
  DOMAIN="${IP//./-}.sslip.io"
fi
SITES_DOMAIN="${SITES_DOMAIN:-sites.$DOMAIN}"
echo "платформа: https://$DOMAIN   сайты клиентов: https://<адрес>.$SITES_DOMAIN"

log "3/8 Код в $APP"
id salespage >/dev/null 2>&1 || useradd --system --home "$APP" --shell /usr/sbin/nologin salespage
mkdir -p "$APP" "$APP/storage" "$APP/backups"
rsync -a --delete --exclude .git --exclude storage --exclude backups --exclude .env --exclude venv --exclude '__pycache__' "$SRC/" "$APP/"

log "4/8 База данных"
if [ -f "$ENVF" ]; then OWNER_PW="$(grep -oP '(?<=sp_owner:)[^@]+' "$ENVF" | head -1)"; APP_PW="$(grep -oP '(?<=sp_app:)[^@]+' "$ENVF" | head -1)"; fi
OWNER_PW="${OWNER_PW:-$(rand 24)}"; APP_PW="${APP_PW:-$(rand 24)}"
pg_isready -q || service postgresql start >/dev/null 2>&1 || pg_ctlcluster 16 main start
runuser -u postgres -- psql -q -v ON_ERROR_STOP=1 <<SQL
DO \$\$ BEGIN
  IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname='sp_owner') THEN CREATE ROLE sp_owner LOGIN; END IF;
  IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname='sp_app') THEN CREATE ROLE sp_app LOGIN NOBYPASSRLS; END IF;
END \$\$;
ALTER ROLE sp_owner PASSWORD '$OWNER_PW';
ALTER ROLE sp_app PASSWORD '$APP_PW';
SELECT 'CREATE DATABASE salespage OWNER sp_owner' WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname='salespage')\gexec
SQL

log "5/8 Python-окружение"
[ -d "$APP/venv" ] || python3 -m venv "$APP/venv"
"$APP/venv/bin/pip" install -q --upgrade pip >/dev/null
"$APP/venv/bin/pip" install -q -r "$APP/requirements.txt"

log "6/8 Настройки (.env)"
if [ ! -f "$ENVF" ] && [ "$MODE" = production ]; then
  WEB_PASS=""
  cat > "$ENVF" <<ENV
APP_ENV=production
SECRET_KEY=$(rand 48)
DATABASE_URL=postgresql+psycopg://sp_app:$APP_PW@127.0.0.1:5432/salespage
MIGRATIONS_DATABASE_URL=postgresql+psycopg://sp_owner:$OWNER_PW@127.0.0.1:5432/salespage
DATABASE_BACKUP_URL=postgresql://sp_owner:$OWNER_PW@127.0.0.1:5432/salespage
PUBLIC_BASE_URL=https://$DOMAIN
SITES_DOMAIN=$SITES_DOMAIN
SITES_SCHEME=https
SITE_CHECK_VIA_LOOPBACK=True
TRUST_PROXY=true
STORAGE_DIR=$APP/storage
BACKUP_DIR=$APP/backups
DEV_LOGIN_ENABLED=False
# --- заполните ключи (их выдаёте вы, в чат не присылать) ---
VK_CLIENT_ID=
VK_REDIRECT_URI=https://$DOMAIN/auth/vk/callback
ADMIN_VK_IDS=
AI_PROVIDER=anthropic
AI_API_KEY=
AI_MODEL=
PAYMENT_PROVIDER=sber
SBER_API_URL=https://ecomtest.sberbank.ru/ecomm/gw/partner/api/v1/
SBER_USERNAME=
SBER_PASSWORD=
SBER_CALLBACK_TOKEN=
TELEGRAM_MODE=live
TELEGRAM_BOT_TOKEN=
TELEGRAM_BOT_USERNAME=
TELEGRAM_WEBHOOK_SECRET=$(rand 24)
OPERATOR_TELEGRAM_CHAT_ID=
EMAIL_MODE=off
PROSPECT_SOURCE=off
OPERATOR_NAME=
OPERATOR_INN=
OPERATOR_EMAIL=
ENV
elif [ ! -f "$ENVF" ]; then
  WEB_PASS="${STAND_PASSWORD:-$(rand 12)}"
  cat > "$ENVF" <<ENV
APP_ENV=test
SECRET_KEY=$(rand 48)
DATABASE_URL=postgresql+psycopg://sp_app:$APP_PW@127.0.0.1:5432/salespage
MIGRATIONS_DATABASE_URL=postgresql+psycopg://sp_owner:$OWNER_PW@127.0.0.1:5432/salespage
DATABASE_BACKUP_URL=postgresql://sp_owner:$OWNER_PW@127.0.0.1:5432/salespage
PUBLIC_BASE_URL=https://$DOMAIN
SITES_DOMAIN=$SITES_DOMAIN
SITES_SCHEME=https
SITE_CHECK_VIA_LOOPBACK=True
TRUST_PROXY=true
STORAGE_DIR=$APP/storage
BACKUP_DIR=$APP/backups
DEV_LOGIN_ENABLED=True
AI_PROVIDER=fake
PAYMENT_PROVIDER=fake
PAYMENT_WEBHOOK_SECRET=$(rand 24)
TELEGRAM_MODE=fake
TELEGRAM_WEBHOOK_SECRET=$(rand 24)
PROSPECT_SOURCE=mock
EMAIL_MODE=mock
# Пароль на платформу (Caddy). Логин: pilot
STAND_PASSWORD=$WEB_PASS
ENV
fi
chmod 600 "$ENVF"
chown -R salespage:salespage "$APP"
WEB_PASS="$(grep -oP '(?<=^STAND_PASSWORD=).*' "$ENVF" || true)"

log "7/8 Миграции"
( cd "$APP" && set -a && . "$ENVF" && set +a && MIGRATIONS_DATABASE_URL_OVERRIDE="$MIGRATIONS_DATABASE_URL" runuser -u salespage -- "$APP/venv/bin/alembic" upgrade head )

log "8/8 Веб-сервер и службы"
if [ -n "$WEB_PASS" ]; then
  HASH="$(caddy hash-password --plaintext "$WEB_PASS")"
  AUTH="	@protected not path /webhooks/* /u/* /health
	basicauth @protected {
		pilot $HASH
	}"
else
  AUTH=""  # боевой режим: вход через VK ID, пароль стенда не нужен
fi
cat > /etc/caddy/Caddyfile <<CADDY
{
	on_demand_tls {
		ask http://127.0.0.1:8000/internal/tls-allowed
	}
}

$DOMAIN {
	encode gzip
$AUTH
	reverse_proxy 127.0.0.1:8000 {
		header_up X-Real-IP {remote_host}
	}
}

*.$SITES_DOMAIN {
	tls {
		on_demand
	}
	encode gzip
	reverse_proxy 127.0.0.1:8000 {
		header_up X-Real-IP {remote_host}
	}
}
CADDY
caddy validate --config /etc/caddy/Caddyfile --adapter caddyfile >/dev/null
for u in salespage-web.service salespage-worker.service salespage-backup.service salespage-backup.timer; do
  sed -e "s#/opt/salespage#$APP#g" "$APP/deploy/systemd/$u" > "/etc/systemd/system/$u"
done

if [ "$MODE" = production ]; then
  PROBLEMS="$(cd "$APP" && set -a && . "$ENVF" && set +a && "$APP/venv/bin/python" -c 'from app.config import get_settings; print("; ".join(get_settings().production_problems()))')"
fi
if [ "$MODE" = production ] && [ -n "$PROBLEMS" ]; then
  [ "$SKIP_SYSTEMD" = 1 ] || { systemctl daemon-reload; systemctl enable salespage-web salespage-worker salespage-backup.timer >/dev/null; systemctl restart caddy; }
  echo "Боевой режим: службы не запущены, пока в $ENVF не заполнено: $PROBLEMS"
  echo "Заполните ключи и выполните: systemctl restart salespage-web salespage-worker"
  exit 0
fi
if [ "$SKIP_SYSTEMD" = 1 ]; then
  echo "SKIP_SYSTEMD=1: службы не запускаются (проверочный режим)"
else
  systemctl daemon-reload
  systemctl enable --now salespage-web salespage-worker salespage-backup.timer >/dev/null
  systemctl restart salespage-web salespage-worker caddy
  for i in $(seq 1 30); do curl -fsS http://127.0.0.1:8000/health >/dev/null 2>&1 && break; sleep 1; done
  curl -fsS http://127.0.0.1:8000/ready >/dev/null && echo "приложение отвечает"
  if [ "${DEMO:-1}" = 1 ] && [ "$MODE" != production ]; then  # демо-проект «Ромашка» с заявками (повторно не создаётся)
    ( cd "$APP" && set -a && . "$ENVF" && set +a && runuser -u salespage -- "$APP/venv/bin/python" scripts/seed_demo.py ) || echo "демо-данные не созданы, платформа работает"
  fi
fi

cat <<DONE

Готово.
  Платформа:   https://$DOMAIN   (логин pilot, пароль $WEB_PASS; затем «Тестовый вход», имя «Демо»)
  Сайты:       https://<адрес>.$SITES_DOMAIN  (открыты для всех)
  Режим:       тестовый — оплата, вход, ИИ, Telegram и почта работают через тестовые адаптеры, деньги не списываются.
  Журналы:     journalctl -u salespage-web -u salespage-worker -f
  Обновление:  загрузите новый архив и запустите этот скрипт ещё раз.
Первый вход по https может занять до минуты: Caddy получает сертификат.
DONE
